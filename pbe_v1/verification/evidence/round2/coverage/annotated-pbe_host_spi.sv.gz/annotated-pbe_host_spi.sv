//      // verilator_coverage annotation
        // Host register port: an SPI peripheral, mode 0 (sample on SCK rising, shift on falling), MSB first.
        //
        // Transaction: CS_n low, command byte, then any number of data bytes.
        //   command[7]   1 = write, 0 = read
        //   command[6:0] register address
        // The address auto-increments after every data byte, except for the streaming registers
        // (program memory data and the engine FIFOs), so a burst can stream many bytes into one.
        //
        // SCK, CS_n and MOSI arrive already synchronized to clk, so SCK must be at most clk/8.
        // Cycle contract (round-2 clarification): byte completion registers wr_en/rd_done;
        // the top-level bus consumes the pulse on the following clk edge. Read data stages into
        // MISO two clk edges after command/read-byte completion, after a FIFO pop has landed.
        // The first following SCK falling edge (bit count 0) does not shift this fresh byte.
        // Stream addresses are exactly 0x07, 0x16, 0x26; other addresses wrap modulo 128.
        // CS_n high abandons any partial byte, clears command framing, read-load pipeline and
        // transmit shifter/MISO, but preserves address/receive shifter and commits any previously
        // issued bus pulse. Reset zeros all host state. Write transactions have no promised MISO
        // payload; read prefetch may expose unspecified head data if an empty FIFO is selected.
        module pbe_host_spi (
 12582243     input  logic       clk,
~000002     input  logic       rst_n,
 692048     input  logic       sck,
 042234     input  logic       cs_n,
 052965     input  logic       mosi,
 118719     output logic       miso,
            // register bus
~033003     output logic [6:0] addr,     // current address; rd_data must be the register at addr
 030970     input  logic [7:0] rd_data,
 004483     output logic       wr_en,    // 1-cycle pulse
~000433     output logic [6:0] wr_addr,
 000743     output logic [7:0] wr_data,
 039790     output logic       rd_done,  // 1-cycle pulse: the byte read from rd_addr has been sent
~006829     output logic [6:0] rd_addr
        );
 692048   logic       sck_d;
 346024   logic [2:0] bitcnt;
 120920   logic [7:0] rx_sh, tx_sh;
 042233   logic       have_cmd, is_write;
 079580   logic [1:0] load_dly;  // load tx_sh two cycles after a byte so a FIFO pop has landed
        
 7045860   wire        sck_rise = sck & ~sck_d;
 7045860   wire        sck_fall = ~sck & sck_d;
 052965   wire  [7:0] rx_byte = {rx_sh[6:0], mosi};
~11094268   wire        no_incr = (addr == 7'h07) || (addr == 7'h16) || (addr == 7'h26);  // streaming registers
        
          assign miso = tx_sh[7];
          wire   _unused = rx_sh[7];  // the 8th bit of a byte comes straight from mosi
        
 12582243   always_ff @(posedge clk or negedge rst_n) begin
 12582239     if (!rst_n) begin
 000007       sck_d    <= 1'b0;
 000007       bitcnt   <= '0;
 000007       rx_sh    <= '0;
 000007       tx_sh    <= '0;
 000007       have_cmd <= 1'b0;
 000007       is_write <= 1'b0;
 000007       load_dly <= '0;
 000007       addr     <= '0;
 000007       wr_en    <= 1'b0;
 000007       wr_addr  <= '0;
 000007       wr_data  <= '0;
 000007       rd_done  <= 1'b0;
 000007       rd_addr  <= '0;
 12582239     end else begin
 12582239       sck_d   <= sck;
 12582239       wr_en   <= 1'b0;
 12582239       rd_done <= 1'b0;
        
 11748496       if (cs_n) begin
 833743         bitcnt   <= '0;
 833743         have_cmd <= 1'b0;
 833743         load_dly <= '0;
 833743         tx_sh    <= '0;
 11748496       end else begin
 11748496         load_dly <= {load_dly[0], 1'b0};
 11668916         if (load_dly[1]) tx_sh <= rd_data;
        
 11056448         if (sck_rise) begin
 692048           rx_sh  <= rx_byte;
 692048           bitcnt <= bitcnt + 1'b1;
 605542           if (bitcnt == 3'd7) begin
 044273             if (!have_cmd) begin
 042233               have_cmd <= 1'b1;
 042233               is_write <= rx_byte[7];
 042233               addr     <= rx_byte[6:0];
 039790               if (!rx_byte[7]) load_dly <= 2'b01;
 039790             end else if (is_write) begin
 004483               wr_en   <= 1'b1;
 004483               wr_addr <= addr;
 004483               wr_data <= rx_byte;
 003908               if (!no_incr) addr <= addr + 1'b1;
 039790             end else begin
 039790               rd_done  <= 1'b1;
 039790               rd_addr  <= addr;
 039790               load_dly <= 2'b01;
 037824               if (!no_incr) addr <= addr + 1'b1;
                    end
                  end
                end
        
                // The first bit of a freshly loaded byte is already on MISO, so skip the
                // falling edge that follows the last bit of the previous byte.
 11142954         if (sck_fall && bitcnt != 3'd0) tx_sh <= {tx_sh[6:0], 1'b0};
              end
            end
          end
        
 000001   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
