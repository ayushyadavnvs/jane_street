//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // End-to-end tests of the debug-port hosts, through the chip's pins only (D75, D76).
        //
        //   engine 0: jtag.pbe (word 0), pins 0..3 = TCK, TMS, TDI, TDO, against IEEE 1149.1 TAPs
        //             (jtag_tap.sv): one TAP, or a chain of two (TDI -> TAP A -> TAP B -> TDO)
        //   engine 1: swd.pbe (word 64), pins 4..5 = SWCLK, SWDIO, against an ADIv5 SW-DP (swd_dp.sv)
        //
        // The target models are written from the standards, not from the programs. SWDIO, TMS, TDI
        // and TDO have pull-ups (SWDIO needs one, ADIv5 B4.1.1; TDO is high-impedance outside
        // Shift-xR); TCK and SWCLK have pull-downs.
        // Phases: each protocol alone at CLKDIV = 0 (the fastest setting), then both concurrently at
        // CLKDIV = 0, then both concurrently at CLKDIV = 0xFFFF (the slowest) with the short scenarios.
        // +ONLY=jtag|swd|both|slow runs one phase.
        module tb_debug;
          localparam real CLK_NS = 20.8333;  // 48 MHz
          localparam int HOST_HALF = 8;      // host SCK = clk / 16
        
~17641153   logic clk = 0, rst_n = 0;
 35282306   always #(CLK_NS / 2) clk = ~clk;
        
~016344   logic [7:0] ui_in = 8'b0000_0010;  // CS_n high
~003240   wire  [7:0] uo_out, uio_out, uio_oe;
~000236   logic [7:0] ext_drive, ext_val;
        
          // Released pins are pulled up, except TCK (pin 0) and SWCLK (pin 4), which are pulled down,
          // as debug connectors usually do: a restart releases the engine's pins for a few clocks, and
          // a clock line pulled up would rise then, an edge the target would act on (BUG-095).
          localparam logic [7:0] PULL_UP = 8'b1110_1110;
~003240   wire  [7:0] chip_lvl = (~uio_oe & PULL_UP) | (uio_oe & uio_out);
~000236   wire  [7:0] ext_lvl  = ~ext_drive | ext_val;
~003240   wire  [7:0] bus      = chip_lvl & ext_lvl;
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in(bus), .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
        
          // ---------------- JTAG targets ----------------
          // The targets drive TDO and SWDIO TCO ns after their clock edge: 50 ns, a slow target. At
          // CLKDIV = 0 the programs read a target's bit 3 clocks (62.5 ns) after the edge that launched
          // it (D75, D76); measured: TCO = 60 ns passes, 66 ns fails (BUG-096: 42 ns before).
          // PBE_TCO overrides it (make sigrok-debug, D77).
        `ifdef PBE_TCO
          localparam real TCO = `PBE_TCO;
        `else
          localparam real TCO = 50.0;
        `endif
          localparam logic [31:0] IDCODE_A = 32'h4BA00477, IDCODE_B = 32'h06413041;
 000002   bit chain = 0;  // 0: TAP A alone on TDO; 1: TAP A's TDO feeds TAP B, whose TDO is the chip's
 000120   wire tdo_a, tdo_a_en, tdo_b, tdo_b_en;
          jtag_tap #(.IDCODE(IDCODE_A), .TCO(TCO)) u_tap_a (.tck(bus[0]), .tms(bus[1]), .tdi(bus[2]), .tdo(tdo_a), .tdo_en(tdo_a_en));
          // TAP B's TDI sees TAP A's TDO line (pulled up while A does not drive it)
          jtag_tap #(.IDCODE(IDCODE_B), .USER0(32'hB0B0B0B0), .TCO(TCO)) u_tap_b (
              .tck(bus[0]), .tms(bus[1]), .tdi(tdo_a_en ? tdo_a : 1'b1), .tdo(tdo_b), .tdo_en(tdo_b_en));
        
          // ---------------- SWD target ----------------
          localparam logic [31:0] DPIDR = 32'h2BA01477, AP_IDR = 32'h24770011;
 000236   wire swd_drive, swd_dout;
          swd_dp #(.DPIDR(DPIDR), .AP_IDR(AP_IDR), .TCO(TCO)) u_dp (.swclk(bus[4]), .swdio(bus[5]), .drive(swd_drive), .dout(swd_dout));
        
 70570973   always_comb begin
 70570973     ext_drive = '0;
 70570973     ext_val = '0;
 70570973     ext_drive[3] = chain ? tdo_b_en : tdo_a_en;
 70570973     ext_val[3]   = chain ? tdo_b : tdo_a;
 70570973     ext_drive[5] = swd_drive;
 70570973     ext_val[5]   = swd_dout;
          end
        
        `ifdef PBE_SIGROK
          integer sigrok_phase = 0;
          wire p0 = bus[0], p1 = bus[1], p2 = bus[2], p3 = bus[3];
          wire p4 = bus[4], p5 = bus[5];
          initial begin
            $dumpfile("tb_debug_pins.vcd");
            $dumpvars(0, p0, p1, p2, p3, p4, p5, sigrok_phase);
          end
        `endif
        
          `include "tb_host.svh"
        
          // ---------------- host side ----------------
          logic [7:0] q0[$], q1[$];  // bytes queued for engine 0's and engine 1's TX FIFO
          // Burst engine e's queue into its TX FIFO in one SPI transaction, pausing while TX is full
          // (uo_out[6 + e]), as a host with flow control would.
 000107   task automatic flush(input int e);
 000107     logic [7:0] d;
 000107     cs(0);
 000107     spi_byte({1'b1, e ? 7'h26 : 7'h16}, d);
 000841     while (e ? q1.size() : q0.size()) begin
 2814752       while (uo_out[6+e]) @(posedge clk);
 000841       d = e ? q1.pop_front() : q0.pop_front();  // (a pop passed as an argument crashes Icarus 12)
 000841       spi_byte(d, d);
            end
 000107     cs(1);
          endtask
          // one RX byte: wait on the RX-not-empty pin (uo_out[4 + e]) without using the SPI port
 000001   longint rx_wait = 2_000_000;  // clocks
 000326   task automatic rx(input int e, output logic [7:0] d);
 000326     longint n = 0;
~31390574     while (!uo_out[4+e] && n < rx_wait) begin
 31390574       @(posedge clk);
 31390574       n++;
            end
 000326     check(uo_out[4+e], $sformatf("engine %0d: no RX byte", e));
 000326     reg_read(e ? 7'h26 : 7'h16, d);
          endtask
        
          // ---------------- timing checks on the pins ----------------
          // JTAG (1149.1): TMS and TDI change only while TCK is low, and are set up before it rises.
          // SWD (ADIv5): the host changes SWDIO only while SWCLK is low; the host and the target never
          // drive SWDIO at once.
~000001   bit jt_on = 0, sw_on = 0;
 000001   realtime jt_chg = 0, jt_rise = 0, jt_fall = 0, sw_chg = 0, sw_rise = 0, sw_fall = 0;
 000001   real jt_hi = 1e9, jt_lo = 1e9, jt_per = 1e9, jt_setup = 1e9;
 000001   real sw_hi = 1e9, sw_lo = 1e9, sw_per = 1e9, sw_setup = 1e9;
 000001   int jt_bad = 0, sw_bad = 0, sw_fight = 0;
 000341   always @(bus[1] or bus[2]) if (jt_on) begin
~000340     if (bus[0]) begin
%000000       jt_bad++;
%000000       if (jt_bad < 4) $display("  JTAG: TMS/TDI changed while TCK was high at %0t", $time);
            end
 000340     jt_chg = $realtime;
          end
~000883   always @(posedge bus[0]) if (jt_on) begin
 000872     if ($realtime - jt_chg < jt_setup) jt_setup = $realtime - jt_chg;
 000874     if (jt_fall > 0 && $realtime - jt_fall < jt_lo) jt_lo = $realtime - jt_fall;
 000874     if (jt_rise > 0 && $realtime - jt_rise < jt_per) jt_per = $realtime - jt_rise;
 000883     jt_rise = $realtime;
          end
~000883   always @(negedge bus[0]) if (jt_on) begin
 000874     if (jt_rise > 0 && $realtime - jt_rise < jt_hi) jt_hi = $realtime - jt_rise;
 000883     jt_fall = $realtime;
          end
 000503   always @(chip_lvl[5]) if (sw_on && uio_oe[5]) begin
~000502     if (bus[4]) begin
%000000       sw_bad++;
%000000       if (sw_bad < 4) $display("  SWD: the host changed SWDIO while SWCLK was high at %0t", $time);
            end
 000502     sw_chg = $realtime;
          end
~003240   always @(posedge bus[4]) if (sw_on) begin
 003232     if (uio_oe[5] && $realtime - sw_chg < sw_setup) sw_setup = $realtime - sw_chg;
 003231     if (sw_fall > 0 && $realtime - sw_fall < sw_lo) sw_lo = $realtime - sw_fall;
 003231     if (sw_rise > 0 && $realtime - sw_rise < sw_per) sw_per = $realtime - sw_rise;
 003240     sw_rise = $realtime;
          end
~003240   always @(negedge bus[4]) if (sw_on) begin
 003232     if (sw_rise > 0 && $realtime - sw_rise < sw_hi) sw_hi = $realtime - sw_rise;
 003240     sw_fall = $realtime;
          end
~17641153   always @(posedge clk) if (sw_on && uio_oe[5] && swd_drive) sw_fight++;
        
          // ================= JTAG host (engine 0) =================
          // records: [0][n-1][tms], [1][n-1][tdi], [2][n-1][tdi] (see jtag.pbe)
 000065   task automatic jt_tms(input int n, input logic [7:0] bits);
 000065     q0.push_back(8'h00);
 000065     q0.push_back(8'(n - 1));
 000065     q0.push_back(bits);
          endtask
          // From Run-Test/Idle: an IR or DR scan of n bits (n <= 64), back to Run-Test/Idle.
 000029   task automatic jt_scan(input bit ir, input int n, input logic [63:0] tdi, output logic [63:0] tdo);
 000029     int chunks, left, k;
 000029     logic [7:0] b;
 000023     if (ir) jt_tms(4, 8'b0011);   // Select-DR, Select-IR, Capture-IR, Shift-IR
 000023     else    jt_tms(3, 8'b001);    // Select-DR, Capture-DR, Shift-DR
 000029     chunks = (n + 7) / 8;
 000094     for (int c = 0; c < chunks; c++) begin
 000094       k = (c == chunks - 1) ? n - 8 * c : 8;
 000094       q0.push_back((c == chunks - 1) ? 8'h02 : 8'h01);
 000094       q0.push_back(8'(k - 1));
 000094       q0.push_back(8'(tdi >> (8 * c)));
            end
 000029     jt_tms(2, 8'b01);             // Update-xR, Run-Test/Idle
 000029     flush(0);
 000029     tdo = '0;
 000094     for (int c = 0; c < chunks; c++) begin
 000094       k = (c == chunks - 1) ? n - 8 * c : 8;
 000094       rx(0, b);
 000094       tdo |= 64'(b >> (8 - k)) << (8 * c);
            end
        `ifdef PBE_SIGROK
            $display("SIGROK_JTAG %s %0d %0x %0x", ir ? "IR" : "DR", n, tdi & ((64'd1 << n) - 1), tdo);
        `endif
          endtask
 000007   task automatic jt_reset;  // Test-Logic-Reset from any state, then Run-Test/Idle
 000007     jt_tms(6, 8'b011111);
 000007     flush(0);
          endtask
        
 000001   int jt_pass = 0;
 000011   task automatic jt_result(input string name, input bit ok);
 000011     check(ok, name);
~000011     if (ok) jt_pass++;
~000011     $display("  JTAG %-40s %s", name, ok ? "PASS" : "FAIL");
          endtask
        
          // the JTAG scenarios; `full` adds the chain (the slow phase runs only the IDCODE read)
 000003   task automatic jtag_scenarios(input bit full);
 000003     logic [63:0] o;
 000003     bit ok;
 000003     chain = 0;
            // 1: Test-Logic-Reset selects IDCODE: a DR scan reads it
 000003     jt_reset;
 000003     jt_scan(0, 32, 64'hFFFF_FFFF, o);
 000003     jt_result($sformatf("reset + IDCODE read (%08x)", o[31:0]), o[31:0] == IDCODE_A);
 000002     if (full) begin
            // 2: IR scan selecting BYPASS (Capture-IR shifts out 0001), then a 1-bit delay
 000002     jt_scan(1, 4, 64'hF, o);
 000002     ok = o[3:0] == 4'b0001;
 000002     jt_scan(0, 16, 64'hA5C3, o);
~000002     jt_result("IR = BYPASS, 16-bit DR scan delayed by 1", ok && o[15:0] == 16'h4B86);
            // 3: USER: write a 32-bit value, read it back while writing another
 000002     jt_scan(1, 4, 64'b1010, o);
 000002     jt_scan(0, 32, 64'hDEAD_BEEF, o);
 000002     ok = o[31:0] == 32'h0;            // the power-up value, captured
 000002     jt_scan(0, 32, 64'h1234_5678, o);
~000002     ok &= o[31:0] == 32'hDEAD_BEEF;
 000002     jt_scan(0, 32, 64'h0, o);
~000002     jt_result("32-bit USER DR write and read-back", ok && o[31:0] == 32'h1234_5678 && u_tap_a.user == 32'h0);
            // 4: short scans, one record each: 1 bit and 7 bits (IR is still USER, USER = 0)
 000002     jt_scan(0, 1, 64'h1, o);          // captures USER bit 0, shifts a 1 in at bit 31
~000002     ok = o[0] == 1'b0 && u_tap_a.user == 32'h8000_0000;
 000002     jt_scan(0, 7, 64'h55, o);         // captures bits 6..0 (0); USER = 0x55 << 25 | 0x80000000 >> 7
~000002     ok &= o[6:0] == 7'h0;
 000002     jt_scan(0, 32, 64'h0, o);
~000002     jt_result("1-bit and 7-bit DR scans", ok && o[31:0] == 32'hAB00_0000);
            // 5: a chain of two TAPs: TDI -> A -> B -> TDO
 000002     chain = 1;
 000002     jt_reset;
 000002     jt_scan(0, 64, 64'hFFFF_FFFF_FFFF_FFFF, o);   // both IDCODEs: B's comes out first
~000002     ok = o[31:0] == IDCODE_B && o[63:32] == IDCODE_A;
 000002     jt_scan(1, 8, {56'd0, 4'b1010, 4'b1111}, o);  // B: BYPASS (shifted first), A: USER
~000002     ok &= o[7:0] == 8'h11;                       // both capture 0001
 000002     jt_scan(0, 33, {31'd0, 32'hCAFE_F00D, 1'b0}, o);  // bit 0 lands in B's bypass
 000002     jt_scan(0, 33, 64'd0, o);
~000002     ok &= o[0] == 1'b0 && o[32:1] == 32'hCAFE_F00D && u_tap_a.user == 32'h0 && u_tap_b.user == 32'hB0B0B0B0;
 000002     jt_result("2-TAP chain: IDCODEs, IR 8 bits, DR through BYPASS", ok);
 000002     chain = 0;
 000002     jt_reset;
            end
          endtask
        
          // ================= SWD host (engine 1) =================
          // records: [0][byte] raw 8 bits; [1][req] read; [2][req][d0..d3][parity] write (see swd.pbe)
 000067   function automatic logic [7:0] sw_req(input bit ap, input bit r, input logic [3:0] addr);
 000067     logic [1:0] a;
 000067     a = addr[3:2];
~000067     return {1'b1, 1'b0, ^{ap, r, a}, a[1], a[0], r, ap, 1'b1};
          endfunction
 000050   task automatic sw_raw(input logic [7:0] b);
 000050     q1.push_back(8'h00);
 000050     q1.push_back(b);
          endtask
 000002   task automatic sw_line_reset;  // 56 ones, 8 idle cycles
 000014     for (int i = 0; i < 7; i++) sw_raw(8'hFF);
 000002     sw_raw(8'h00);
 000002     flush(1);
        `ifdef PBE_SIGROK
            $display("SIGROK_SWD LINERESET");
        `endif
          endtask
 000002   task automatic sw_switch;  // line reset, 0xE79E, line reset, idle (ADIv5 B5.2.1)
 000014     for (int i = 0; i < 7; i++) sw_raw(8'hFF);
 000002     sw_raw(8'h9E);
 000002     sw_raw(8'hE7);
 000014     for (int i = 0; i < 7; i++) sw_raw(8'hFF);
 000002     sw_raw(8'h00);
 000002     flush(1);
        `ifdef PBE_SIGROK
            $display("SIGROK_SWD SWITCH");
        `endif
          endtask
          // ack: the RX byte (ACK bits 0..2 in bits 5..7: OK 0x20, WAIT 0x40, FAULT 0x80)
 000041   task automatic sw_read(input bit ap, input logic [3:0] addr, output logic [7:0] ack,
 000041                          output logic [31:0] d, output bit perr);
 000041     logic [7:0] b;
 000041     q1.push_back(8'h01);
 000041     q1.push_back(sw_req(ap, 1, addr));
 000041     flush(1);
 000041     rx(1, ack);
 000041     d = 'x;
 000041     perr = 0;
 000033     if (ack == 8'h20) begin
 000132       for (int i = 0; i < 4; i++) begin
 000132         rx(1, b);
 000132         d[8*i +: 8] = b;
              end
 000033       rx(1, b);
 000033       perr = b[0];
            end
        `ifdef PBE_SIGROK
            $display("SIGROK_SWD %s R %0x %02x %08x %0d", ap ? "AP" : "DP", addr, ack, d, perr);
        `endif
          endtask
 000026   task automatic sw_write(input bit ap, input logic [3:0] addr, input logic [31:0] d,
 000026                           input bit bad_par, output logic [7:0] ack);
 000026     q1.push_back(8'h02);
 000026     q1.push_back(sw_req(ap, 0, addr));
 000104     for (int i = 0; i < 4; i++) q1.push_back(d[8*i +: 8]);
 000026     q1.push_back(8'(^d ^ bad_par));  // parity, then 7 idle cycles
 000026     flush(1);
 000026     rx(1, ack);
        `ifdef PBE_SIGROK
            $display("SIGROK_SWD %s W %0x %02x %08x %0d", ap ? "AP" : "DP", addr, ack, d, bad_par);
        `endif
          endtask
        
 000001   int sw_pass = 0;
 000015   task automatic sw_result(input string name, input bit ok);
 000015     check(ok, name);
~000015     if (ok) sw_pass++;
~000015     $display("  SWD  %-40s %s", name, ok ? "PASS" : "FAIL");
          endtask
        
 000002   task automatic swd_scenarios(input bit full);
 000002     logic [7:0] ack;
 000002     logic [31:0] d;
 000002     bit perr, ok;
 000002     int n0, n1;
            // 1: the JTAG-to-SWD switch (the port starts in JTAG mode), line reset, DPIDR read
 000002     sw_switch;
 000002     sw_read(0, 4'h0, ack, d, perr);
~000002     sw_result($sformatf("switch + line reset + DPIDR (%08x)", d), ack == 8'h20 && d == DPIDR && !perr);
~000002     if (full) begin
            // 2: DP and AP registers: CTRL/STAT power-up, SELECT, TAR/DRW, AP read through RDBUFF
 000002     sw_write(0, 4'h4, 32'h5000_0000, 0, ack);  ok = ack == 8'h20;
~000002     sw_read(0, 4'h4, ack, d, perr);            ok &= ack == 8'h20 && d == 32'hF000_0000 && !perr;
~000002     sw_write(0, 4'h8, 32'h0000_0000, 0, ack);  ok &= ack == 8'h20;   // AP 0, bank 0
~000002     sw_write(1, 4'h4, 32'h0000_0008, 0, ack);  ok &= ack == 8'h20;   // TAR = 8 (mem[2])
~000002     sw_write(1, 4'hC, 32'hA5A5_0F0F, 0, ack);  ok &= ack == 8'h20;   // DRW
~000002     sw_read(1, 4'hC, ack, d, perr);            ok &= ack == 8'h20 && !perr;  // posted
~000002     sw_read(0, 4'hC, ack, d, perr);            ok &= ack == 8'h20 && d == 32'hA5A5_0F0F && !perr;
~000002     sw_write(0, 4'h8, 32'h0000_00F0, 0, ack);  ok &= ack == 8'h20;   // bank 0xF
~000002     sw_read(1, 4'hC, ack, d, perr);            ok &= ack == 8'h20;   // IDR, posted
~000002     sw_read(0, 4'hC, ack, d, perr);            ok &= ack == 8'h20 && d == AP_IDR;
~000002     sw_write(0, 4'h8, 32'h0000_0000, 0, ack);  ok &= ack == 8'h20;
~000002     sw_result("DP + AP write/read, AP read via RDBUFF", ok && u_dp.mem[2] == 32'hA5A5_0F0F);
            // 3: WAIT, then a retry: a read waits twice, a write once (its data phase is dropped)
 000002     u_dp.wait_n = 2;
 000002     sw_read(1, 4'h4, ack, d, perr);            ok = ack == 8'h40;
~000002     sw_read(1, 4'h4, ack, d, perr);            ok &= ack == 8'h40;
~000002     sw_read(1, 4'h4, ack, d, perr);            ok &= ack == 8'h20;
~000002     sw_read(0, 4'hC, ack, d, perr);            ok &= ack == 8'h20 && d == 32'h8;   // TAR
 000002     u_dp.wait_n = 1;
 000002     n0 = u_dp.n_writes;
~000002     sw_write(1, 4'h4, 32'h0000_000C, 0, ack);  ok &= ack == 8'h40 && u_dp.n_writes == n0;
~000002     sw_write(1, 4'h4, 32'h0000_000C, 0, ack);  ok &= ack == 8'h20 && u_dp.tar == 32'hC;
~000002     sw_read(0, 4'h0, ack, d, perr);            ok &= ack == 8'h20 && d == DPIDR;  // in step
~000002     sw_result("WAIT then retry (read and write)", ok && u_dp.n_writes == n0 + 1);
            // 4: FAULT: an AP access fails; sticky until ABORT.STKERRCLR
 000002     u_dp.fault_next = 1;
 000002     sw_read(1, 4'hC, ack, d, perr);            ok = ack == 8'h80;
~000002     sw_write(1, 4'hC, 32'h1, 0, ack);          ok &= ack == 8'h80;   // still sticky
~000002     sw_read(0, 4'h4, ack, d, perr);            ok &= ack == 8'h20 && d[5];  // STICKYERR
~000002     sw_write(0, 4'h0, 32'h0000_0004, 0, ack);  ok &= ack == 8'h20;   // ABORT.STKERRCLR
~000002     sw_read(0, 4'h4, ack, d, perr);            ok &= ack == 8'h20 && !d[5];
~000002     sw_read(1, 4'hC, ack, d, perr);            ok &= ack == 8'h20;
~000002     sw_result("FAULT, sticky, cleared by ABORT", ok && u_dp.mem[3] != 32'h1);
            // 5: the target sends read data with a wrong parity bit: reported
 000002     u_dp.bad_par_next = 1;
~000002     sw_read(0, 4'h0, ack, d, perr);            ok = ack == 8'h20 && d == DPIDR && perr;
~000002     sw_read(0, 4'h0, ack, d, perr);            ok &= ack == 8'h20 && !perr;
 000002     sw_result("target data parity error detected", ok);
            // 6: the host sends a write with a wrong parity bit: the target drops it, WDATAERR
 000002     n0 = u_dp.n_writes;
 000002     n1 = u_dp.n_wdataerr;
~000002     sw_write(1, 4'h4, 32'h0000_0010, 1, ack);  ok = ack == 8'h20 && u_dp.n_writes == n0 && u_dp.tar == 32'hC;
~000002     sw_read(1, 4'h4, ack, d, perr);            ok &= ack == 8'h80;   // FAULT while WDATAERR
~000002     sw_read(0, 4'h4, ack, d, perr);            ok &= ack == 8'h20 && d[7];
~000002     sw_write(0, 4'h0, 32'h0000_0008, 0, ack);  ok &= ack == 8'h20;   // ABORT.WDERRCLR
~000002     sw_write(1, 4'h4, 32'h0000_0010, 0, ack);  ok &= ack == 8'h20 && u_dp.tar == 32'h10;
~000002     sw_result("write parity error rejected by the target", ok && u_dp.n_wdataerr == n1 + 1);
            // 7: a line reset, then the DPIDR read it requires
 000002     sw_line_reset;
 000002     sw_read(0, 4'h0, ack, d, perr);
~000002     sw_result("line reset + DPIDR", ack == 8'h20 && d == DPIDR);
            end
          endtask
        
          // ---------------- engine set-up ----------------
 000004   task automatic setup(input logic [15:0] div);
 000004     reg_write(7'h00, 8'b1100_0000);   // stop both, flush their FIFOs
 000004     reg_write(7'h03, 8'hF0);          // pins 4..7 to engine 1
 000008     for (int e = 0; e < 2; e++) begin
 000008       logic [6:0] b;
 000008       b = e ? 7'h20 : 7'h10;
 000008       reg_write(b + 0, div[7:0]);
 000008       reg_write(b + 1, div[15:8]);
 000008       reg_write(b + 2, e ? 4 : 0);    // pin base
 000008       reg_write(b + 3, 0);
 000008       reg_write(b + 4, 0);            // LSB first both ways
 000008       reg_write(b + 5, e ? 64 : 0);   // start
 000008       reg_write(b + 'hB, 0);          // CRC off
 000008       reg_write(b + 'hC, 0);          // no timeout
 000008       reg_write(b + 'hD, 0);
 000008       reg_write(b + 'hE, 0);          // even parity
            end
 000004     reg_write(7'h00, 8'b0011_0011);   // restart and run both
          endtask
        
 000005   task automatic timing_clear;
 000005     jt_per = 1e9; jt_hi = 1e9; jt_lo = 1e9; jt_setup = 1e9; jt_rise = 0; jt_fall = 0;
 000005     sw_per = 1e9; sw_hi = 1e9; sw_lo = 1e9; sw_setup = 1e9; sw_rise = 0; sw_fall = 0;
          endtask
 000004   task automatic report_timing(input string what);
~000004     if (jt_rise > 0)
 000004       $display("  %s TCK:   min period %0.1f ns (%0.2f MHz), high %0.1f, low %0.1f, TMS/TDI setup %0.1f ns",
 000004                what, jt_per, 1000.0 / jt_per, jt_hi, jt_lo, jt_setup);
 000003     if (sw_rise > 0)
 000003       $display("  %s SWCLK: min period %0.1f ns (%0.2f MHz), high %0.1f, low %0.1f, SWDIO setup %0.1f ns",
 000003                what, sw_per, 1000.0 / sw_per, sw_hi, sw_lo, sw_setup);
 000004     timing_clear;
          endtask
        
          string only;
 000001   initial begin
~000001     if (!$value$plusargs("ONLY=%s", only)) only = "";
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
 000001     load_program("debug_image.hex");   // jtag at word 0, swd at word 64
 000001     jt_on = 1;
 000001     sw_on = 1;
        
~000001     if (only == "" || only == "jtag") begin
        `ifdef PBE_SIGROK
              sigrok_phase = 1;
        `endif
 000001       $display("Phase 1: JTAG alone, CLKDIV = 0");
 000001       setup(16'd0);
 000001       jtag_scenarios(1);
 000001       report_timing("CLKDIV 0");
            end
~000001     if (only == "" || only == "swd") begin
        `ifdef PBE_SIGROK
              sigrok_phase = 2;
        `endif
 000001       $display("Phase 2: SWD alone, CLKDIV = 0");
 000001       setup(16'd0);
 000001       swd_scenarios(1);
 000001       report_timing("CLKDIV 0");
            end
~000001     if (only == "" || only == "both") begin
        `ifdef PBE_SIGROK
              sigrok_phase = 3;
        `endif
 000001       $display("Phase 3: JTAG (engine 0) and SWD (engine 1) concurrently, CLKDIV = 0");
 000001       setup(16'd0);
 000001       fork
 000001         jtag_scenarios(1);
 000001         swd_scenarios(1);
              join
 000001       report_timing("CLKDIV 0");
            end
~000001     if (only == "" || only == "slow") begin
        `ifdef PBE_SIGROK
              sigrok_phase = 4;
        `endif
 000001       $display("Phase 4: both concurrently, CLKDIV = 0xFFFF (the slowest)");
              // the SW-DP must be in SWD mode first (the switch at full speed: 136 cycles at 0xFFFF
              // would take 45M clocks); then an IDCODE read and a DPIDR read, each about 45 cycles
~000001       if (u_dp.n_switch == 0) begin
%000000         setup(16'd0);
%000000         sw_switch;
              end
 000001       rx_wait = 64'd1_000_000_000;
 000001       setup(16'hFFFF);
 000001       timing_clear;
 000001       fork
 000001         jtag_scenarios(0);
 000001         begin
 000001           logic [7:0] ack;
 000001           logic [31:0] d;
 000001           bit perr;
 000001           sw_read(0, 4'h0, ack, d, perr);
~000001           sw_result($sformatf("DPIDR read (%08x)", d), ack == 8'h20 && d == DPIDR && !perr);
                end
              join
 000001       report_timing("CLKDIV 0xFFFF");
            end
        
 000001     check(jt_bad == 0, $sformatf("JTAG: TMS/TDI changed %0d times while TCK was high", jt_bad));
 000001     check(sw_bad == 0, $sformatf("SWD: SWDIO changed %0d times while SWCLK was high", sw_bad));
 000001     check(sw_fight == 0, $sformatf("SWD: host and target drove SWDIO together for %0d clocks", sw_fight));
 000001     check(u_dp.n_proto_err == 0, $sformatf("SWD target saw %0d protocol errors", u_dp.n_proto_err));
 000001     $display("  JTAG scenarios passed: %0d; SWD scenarios passed: %0d; SWD target: %0d line resets, %0d switches, %0d OK, %0d WAIT, %0d FAULT",
 000001              jt_pass, sw_pass, u_dp.n_line_reset, u_dp.n_switch, u_dp.n_ok, u_dp.n_wait, u_dp.n_fault);
 000001     if (errors == 0) begin
 000001       $display("PASS: debug ports");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          initial begin
            #3000ms;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
