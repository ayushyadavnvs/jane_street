//      // verilator_coverage annotation
        // Small synchronous FIFO used between the host interface and each engine.
        // Push while full and pop while empty are ignored.
        // Acceptance uses occupancy before the edge: simultaneous push+pop when full only pops,
        // when empty only pushes, and at intermediate occupancy accepts both. Reset/flush zeros
        // both pointers and count, with flush winning over pointer updates. Storage is unreset and
        // an accepted push still writes its old write-pointer slot on a flush/reset edge; those
        // bytes are not logically queued after the reset/flush. dout continuously exposes the
        // head slot, even while empty (stale/unknown data); callers must qualify it with !empty.
        // This is the existing storage/pointer contract, clarified in the round-2 model audit.
        module pbe_fifo #(
            parameter int WIDTH = 8,
            parameter int ADDR_BITS = 2  // depth = 2**ADDR_BITS
        ) (
 50328972     input  logic             clk,
~000008     input  logic             rst_n,
~000024     input  logic             flush,
 003826     input  logic             push,
~002377     input  logic [WIDTH-1:0] din,
 003826     input  logic             pop,
~001204     output logic [WIDTH-1:0] dout,
 003245     output logic             empty,
~000006     output logic             full,
~003826     output logic [ADDR_BITS:0] count  // bytes held
        );
          localparam int DEPTH = 1 << ADDR_BITS;
        
~000063   logic [WIDTH-1:0] mem[DEPTH];
~001915   logic [ADDR_BITS:0] wptr, rptr;  // extra bit tells full from empty
        
          assign empty = (wptr == rptr);
~49670105   assign full  = (wptr[ADDR_BITS-1:0] == rptr[ADDR_BITS-1:0]) && (wptr[ADDR_BITS] != rptr[ADDR_BITS]);
          assign dout  = mem[rptr[ADDR_BITS-1:0]];
          assign count = wptr - rptr;
        
 50328972   always_ff @(posedge clk or negedge rst_n) begin
 50328956     if (!rst_n) begin
 000028       wptr <= '0;
 000028       rptr <= '0;
~50328932     end else if (flush) begin
~000024       wptr <= '0;
~000024       rptr <= '0;
 50328932     end else begin
~50325106       if (push && !full) wptr <= wptr + 1'b1;
 50325106       if (pop && !empty) rptr <= rptr + 1'b1;
            end
          end
        
          // Storage has no reset: logical consumers must qualify reads with !empty.
 50328972   always_ff @(posedge clk) begin
~50325146     if (push && !full) mem[wptr[ADDR_BITS-1:0]] <= din;
          end
        
 000004   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
