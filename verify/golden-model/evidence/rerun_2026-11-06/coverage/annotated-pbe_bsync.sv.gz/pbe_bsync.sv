//      // verilator_coverage annotation
        // Bit-synchronous line coder (LINE2[5], D66): one bit timer for both directions, for wired-AND
        // buses on which every node reads back every bit (CAN, ISO 11898-1). The engine uses it in
        // place of pbe_line when LINE2[5] is set; LINE must then select NRZ (and normally stuffing 3).
        //
        // Timing. One timer, period_m1 + 1 clocks per bit. The sample point is LINE2[2:0] (as in
        // pbe_line). On the bus-idle level a falling edge hard-synchronizes (it is a start of frame);
        // inside a frame a falling edge resynchronizes, except while this node drives a dominant
        // bit (its own edge, delayed by the transceiver), and at most once between two sample points
        // (ISO 11898-1). An edge after the sample point starts the
        // next bit at once; an edge before it restarts the current bit.
        //
        // Transfers. OUT queues a unit of `width` bits (the top bits of OSR when MSB first); one unit
        // is buffered. At each bit start the coder drives the next bit of the current unit, or the
        // queued unit's first bit, or recessive when nothing is queued. IN takes a unit of `width`
        // received bits, right-justified. Stuff bits are inserted and removed here: they never reach
        // the program. Stuffing follows the bus, not the bits this node meant to send.
        //   A frame starts in units of 8 bits if LINE[5] (bytes), else 1, with arbitration on and
        //   stuffing on if LINE[3:2] != 0. LINECTL changes them (ctl, ctl_param, see pbe_engine).
        // Arbitration. Sent recessive and read dominant on a data bit while the arbitration window is
        //   on: the node stops driving at once (it is "silent"), keeps receiving, and pulses arb_lost
        //   if it had started the frame. A silent node checks nothing and drives only error flags.
        // Bit error. A non-silent node that reads back a level other than the one it drove (outside
        //   the arbitration rule) has a bit error.
        // Frame tail. When stuffing is switched off (LINECTL) the stuffed region ends after any stuff
        //   bit already due, and the coder runs the rest of the frame itself: CRC delimiter, ACK slot,
        //   ACK delimiter, 7 EOF bits. Every node is non-silent in the tail. A node that did not
        //   transmit drives the ACK slot dominant if crc_ok; a transmitter that reads the ACK slot
        //   recessive has an ACK error; a dominant delimiter or EOF bit is a form error (except EOF
        //   bit 7 for a receiver: no overload frame, D69); a receiver whose CRC is not ok has a CRC
        //   error after the ACK delimiter. After EOF bit 7 frame_end pulses, a transmitter pulses
        //   `sent`, and the error counters count a success.
        // Errors (stuff, bit, form, ACK, CRC, and LINECTL "error now"): err and frame_end pulse, the
        //   queued unit is dropped, and the error flag starts at the next bit: 6 dominant bits when
        //   error-active, 6 recessive (ended by 6 equal bits on the bus) when error-passive (the state
        //   in which the error was detected, before its own count); then the
        //   delimiter: wait for recessive, then 8 recessive bits.
        // Error confinement (D68), ISO 11898-1 rules: a transmitter's error adds 8 to TEC (except an
        //   error-passive transmitter's ACK error when its passive flag sees no dominant bit), a
        //   receiver's adds 1 to REC; a receiver that reads dominant as the first bit after its error
        //   flag adds 8; a bit error in its own active flag adds 8; 14 dominant bits after an active
        //   flag (8 after a passive one), and each 8 more, add 8; success subtracts 1 (REC above 127
        //   becomes 119). Error-passive at TEC or REC >= 128; bus-off when TEC > 255: the node is then
        //   silent until it has seen 128 runs of 11 recessive bits (counters back to 0).
        // Bus idle. After clear the node integrates: 11 recessive bits before a falling edge counts
        //   as a start of frame. With LINE2[6] the node starts its own frame (a queued unit whose first
        //   bit is dominant) only after 3 recessive bits following a frame end or error delimiter, or 11
        //   otherwise, plus 8 (suspend transmission) after it transmitted while error-passive. A
        //   foreign start of frame while a unit is queued (or queued before the SOF sample point) is
        //   joined if this node may start, otherwise the unit is sent silently and arb_lost pulses.
        // Frame follower (LINE2[7], D74, CAN-only): a CAN 2.0A program walks standard frames; when
        //   IDE (destuffed bit 13) or r0 (bit 14) is recessive, the coder follows the rest of the frame
        //   itself: no unit reaches IN after the one holding that bit, LINECTL is ignored, and from the
        //   RTR and DLC it finds the last CRC bit and ends the stuffed region there; the tail, ACK and
        //   error checks are the usual ones. The program's waiting IN ends at the frame end (vector).
        // Every config bit of this mode defaults to 0 in LINE2, so the engine never selects it unless
        // LINE2[5] is written.
        module pbe_bsync (
 35282306     input  logic        clk,
~000024     input  logic        rst_n,
~000141     input  logic        clear,
~000096     input  logic [7:0]  cfg,         // LINE: [3:2] stuffing, [5] frames start in byte units
~000022     input  logic [7:0]  cfg2,        // LINE2: [2:0] sample point, [6] wait for bus idle
~000022     input  logic [15:0] period_m1,
~000022     input  logic        out_msb_first,
~000022     input  logic        in_msb_first,
~007166     input  logic        a_in,        // synchronized receive level
~001198     output logic        drive,       // drive the pin dominant (low)
~001611     input  logic        tx_put,
~001343     input  logic [7:0]  tx_data,
~001613     output logic        tx_ready,
~001678     output logic        rx_valid,
~000586     output logic [7:0]  rx_data,
~001678     input  logic        rx_take,
~000204     output logic        frame_end,   // pulse: frame ended or an error was detected
~000059     output logic        err,         // pulse: an error (or receive overrun)
~000908     input  logic        ctl,         // LINECTL
~110223     input  logic [4:0]  ctl_param,
~000204     input  logic        drop,        // the engine abandoned the frame: drop the queued unit
~000204     input  logic        crc_ok,
~011548     output logic        crc_step,    // a received bit of the stuffed region, for the CRC
~002694     output logic        crc_bit,
~000003     output logic        arb_lost,    // pulses
~000033     output logic        bit_err,
~000035     output logic        sent,
~000026     output logic [8:0]  tec,
~000009     output logic [7:0]  rec,
~000002     output logic        passive,
~000001     output logic        busoff
        );
          localparam logic [2:0] C_INTEG = 3'd0, C_IDLE = 3'd1, C_FRAME = 3'd2, C_TAIL = 3'd3,
                                 C_EFLAG = 3'd4, C_EDWAIT = 3'd5, C_EDELIM = 3'd6, C_BUSOFF = 3'd7;
~000024   wire [1:0] st    = cfg[3:2];
~000141   wire       ones  = st != 2'd3;
~35282308   wire [2:0] run_n = (st == 2'd1) ? 3'd6 : 3'd5;
~000022   wire       idle_wait = cfg2[6];
~35282308   wire       _unused = &{cfg[7:6], cfg[4], cfg[1:0], cfg2[5:3], 1'b0};
~000141   wire       cfol = cfg2[7];   // LINE2[7]: follow CAN frames the program does not walk (D74)
        
          // ---- timing ----
~1080755   logic [15:0] cnt;
~021188   logic        sampled, a_d;
~000022   wire [15:0] n_per = period_m1 + 16'd1;
~35282308   wire        _unused_nper = &{n_per[1:0], 1'b0};
~000018   logic [15:0] sp_add;
 35282308   always_comb begin
 35282308     case (cfg2[2:0])
~004821       3'd1:    sp_add = {3'b0, n_per[15:3]};
~2711088       3'd2:    sp_add = {2'b0, n_per[15:2]};
~004893       3'd3:    sp_add = {2'b0, n_per[15:2]} + {3'b0, n_per[15:3]};
 35282308       default: sp_add = 16'd0;
            endcase
          end
          // the sample count, registered: the adders stay off the counter's compare path; a change
          // of CLKDIV or LINE2 takes effect one clock later. spv_ok: spv holds a computed value (from
          // the first clock after reset); before it, spv's reset 0 matched cnt's and the node sampled
          // at the first clock instead of at the sample point (BUG-104).
~000024   logic [15:0] spv;
~000024   logic        spv_ok;
 35282306   always_ff @(posedge clk or negedge rst_n)
 35282296     if (!rst_n) begin
 000164       spv    <= '0;
 000164       spv_ok <= 1'b0;
 35282296     end else begin
 35282296       spv    <= {1'b0, period_m1[15:1]} + 16'd1 + sp_add;
 35282296       spv_ok <= 1'b1;
            end
        
~000305   logic [2:0]  cs;
~001198   logic        drv;                  // driving dominant in this bit
~001779   logic        cur;                  // the level this node means to send in this bit (1 = recessive)
~000422   logic        slot_stuff, sof;
~001611   logic        q_valid;
~001783   logic [7:0]  q_data, tsh;
~004837   logic [3:0]  tleft, width;
~003030   logic        last, stuff_pend, st_en, arb_en;
~004074   logic [2:0]  run;
~000116   logic        silent, own, role_tx, joinw;
~002504   logic [7:0]  rsh;
~005611   logic [3:0]  rbits;
~001931   logic [4:0]  icnt;
~000203   logic        after, susp;
~000747   logic [3:0]  tpos;
~000058   logic        flag_on, flag_pas, fprev, ack_exc, first_after;
~000174   logic [2:0]  fcnt;
~000111   logic [3:0]  dom_cnt;
~000232   logic [2:0]  dcnt;
~000064   logic [6:0]  rseq;
~000643   logic [3:0]  rrun;
          // the CAN frame follower (D74): destuffed bit index, and the fields it needs
~005782   logic [6:0]  bidx, flast;
~000202   logic        follow, fext, frtr, fhave;
~000190   logic [2:0]  fdlc;
~35282308   wire  [6:0]  hdr_end = fext ? 7'd38 : 7'd18;               // the last DLC bit
~007166   wire  [3:0]  dlcv = {fdlc, b};
~35282308   wire  [6:0]  n8 = frtr ? 7'd0 : dlcv[3] ? 7'd64 : {1'b0, dlcv[2:0], 3'b000};
        
~35282308   assign passive  = tec >= 9'd128 || rec >= 8'd128;
          assign busoff   = cs == C_BUSOFF;
~35282308   assign tx_ready = !q_valid;
          assign drive    = drv;
        
~27977895   wire fall   = a_d && !a_in;
~000223   wire in_bus = cs != C_IDLE;
          // ISO 11898-1: at most one synchronization between two sample points
~002141   logic synced;
~27977897   wire resync = fall && !drv && in_bus && !synced;
~35282308   wire hard   = fall && cs == C_IDLE;
~021050   wire tend   = cnt == period_m1;
~35282296   wire sample = cnt == spv && !sampled && spv_ok;
~007166   wire b      = a_in;
        
          // the unit bits
~35282308   wire [7:0] src   = (tleft != 4'd0) ? tsh : q_data;
~35282308   wire       nb    = out_msb_first ? src[7] : src[0];
~35282308   wire [7:0] rest  = out_msb_first ? {src[6:0], 1'b0} : {1'b0, src[7:1]};
~35282308   wire       have  = tleft != 4'd0 || q_valid;
~35282308   wire [3:0] start_w = cfg[5] ? 4'd8 : 4'd1;
~35282308   wire       q_first = out_msb_first ? q_data[7] : q_data[0];
          // a frame's first unit always comes from the queue, never from a unit cut short by an error
~35282308   wire [7:0] q_rest  = out_msb_first ? {q_data[6:0], 1'b0} : {1'b0, q_data[7:1]};
        
          // may this node start (or join) a frame now
~35282308   wire [4:0] need = (after ? 5'd3 : 5'd11) + (susp ? 5'd8 : 5'd0);
~35282308   wire       may_tx = !idle_wait || icnt >= need;
        
          // frame start: own (bus idle, at a bit boundary) or foreign (hard synchronization)
~35282308   wire own_start = cs == C_IDLE && tend && q_valid && !q_first && may_tx;
~35282308   wire fstart    = own_start || hard;
          // the late join: a unit queued during the start-of-frame bit, before its sample point
~35282308   wire late_join = cs == C_FRAME && sof && joinw && !sampled && q_valid;
        
          // receive: the bit after stuffing state and unit assembly
~008178   logic [2:0] run_nx;
 35282308   always_comb begin
~35282308     if (ones) run_nx = b ? run + 3'd1 : 3'd0;
~2720592     else      run_nx = (b == last) ? run + 3'd1 : 3'd1;
          end
~35282308   wire [7:0] rsh_n = in_msb_first ? {rsh[6:0], b} : (rsh | ({7'd0, b} << rbits));
        
          // the role in this frame, for the counters
~35282308   wire        is_rx = !role_tx;
~000059   logic       e_now, e_bit, e_ack;   // an error detected in this clock
~000017   logic       e_rx8, e_tx8;          // +8 events without a new error flag
 35282308   always_comb begin
 35282308     e_now = 1'b0; e_bit = 1'b0; e_ack = 1'b0; e_rx8 = 1'b0; e_tx8 = 1'b0;
~35282308     if (sample) case (cs)
~011970       C_FRAME:
~020984         if (sof && b && !drv) ;                            // not a start of frame: see below
~000422         else if (slot_stuff) e_now = b != cur;             // stuff error
~011515         else if (!silent && !(arb_en && cur && !b) && b != cur) begin
~000033           e_now = 1'b1;                                    // bit error
~000033           e_bit = 1'b1;
                end
~001498       C_TAIL:
~001498         case (tpos)
~012524           4'd1: if (role_tx && b) begin                    // ACK error
~000020             e_now = 1'b1;
~000020             e_ack = 1'b1;
                  end
~008853           4'd2: e_now = !b || (is_rx && !crc_ok);          // form error, or CRC error
~014110           4'd9: e_now = !b && role_tx;                     // EOF 7: a receiver ignores it
~014110           default: e_now = !b;                             // delimiter / EOF: form error
                endcase
~000348       C_EFLAG:
~014877         if (flag_on && !flag_pas && b) begin               // bit error in an active flag
~000005           e_tx8 = role_tx;
~000005           e_rx8 = is_rx;
~000348         end else if (flag_on && flag_pas && ack_exc && !b) e_tx8 = 1'b1;
~000625       C_EDWAIT:
~014110         if (!b) begin
~000595           if (first_after && is_rx) e_rx8 = 1'b1;
~000600           if (dom_cnt == (flag_pas ? 4'd7 : 4'd13)) begin  // 8 / 14 dominant bits
~000075             e_tx8 = role_tx;
~000075             e_rx8 = is_rx;
                  end
                end
~014110       C_EDELIM: e_now = !b;                                // form error in the delimiter
~006718       default: ;
            endcase
~35282308     if (ctl && ctl_param[4] && ctl_param[2] && (cs == C_FRAME || cs == C_TAIL)) e_now = 1'b1;
          end
        
          // counter arithmetic
~35282308   wire        add8_tx = (e_now && role_tx && !(e_ack && passive)) || e_tx8;
~35282308   wire        add1_rx = e_now && is_rx;
~35282308   wire [9:0]  tec_add = {1'b0, tec} + (add8_tx ? 10'd8 : 10'd0);
~35282308   wire [8:0]  rec_add = {1'b0, rec} + (e_rx8 ? 9'd8 : add1_rx ? 9'd1 : 9'd0);
~35282308   wire [7:0]  rec_sat = rec_add[8] ? 8'd255 : rec_add[7:0];
~000001   wire        to_busoff = tec_add > 10'd255;
        
 35282306   always_ff @(posedge clk or negedge rst_n) begin
 35282296     if (!rst_n) begin
 000164       cnt <= '0; sampled <= 1'b0; a_d <= 1'b1; cs <= C_INTEG; drv <= 1'b0; cur <= 1'b1; synced <= 1'b0;
 000164       slot_stuff <= 1'b0; sof <= 1'b0; q_valid <= 1'b0; q_data <= '0; tsh <= '0; tleft <= '0;
 000164       width <= 4'd1; last <= 1'b1; stuff_pend <= 1'b0; st_en <= 1'b0; arb_en <= 1'b0; run <= '0;
 000164       silent <= 1'b0; own <= 1'b0; role_tx <= 1'b0; joinw <= 1'b0; rsh <= '0; rbits <= '0;
 000164       icnt <= '0; after <= 1'b0; susp <= 1'b0; tpos <= '0; flag_on <= 1'b0; flag_pas <= 1'b0;
 000164       fprev <= 1'b0; ack_exc <= 1'b0; first_after <= 1'b0; fcnt <= '0;
 000164       dom_cnt <= '0; dcnt <= '0; rseq <= '0; rrun <= '0; tec <= '0; rec <= '0;
 000164       bidx <= '0; flast <= '0; follow <= 1'b0; fext <= 1'b0; frtr <= 1'b0; fhave <= 1'b0; fdlc <= '0;
 000164       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0; crc_step <= 1'b0;
 000164       crc_bit <= 1'b0; arb_lost <= 1'b0; bit_err <= 1'b0; sent <= 1'b0;
~35282296     end else if (clear) begin
              // the error counters survive a restart (ISO: only bus-off recovery or a reset clears them)
~35282296       cnt <= '0; sampled <= 1'b0; a_d <= 1'b1; cs <= (cs == C_BUSOFF) ? C_BUSOFF : C_INTEG; synced <= 1'b0;
 35282296       drv <= 1'b0; cur <= 1'b1;
 35282296       slot_stuff <= 1'b0; sof <= 1'b0; q_valid <= 1'b0; q_data <= '0; tsh <= '0; tleft <= '0;
 35282296       width <= 4'd1; last <= 1'b1; stuff_pend <= 1'b0; st_en <= 1'b0; arb_en <= 1'b0; run <= '0;
 35282296       silent <= 1'b0; own <= 1'b0; role_tx <= 1'b0; joinw <= 1'b0; rsh <= '0; rbits <= '0;
 35282296       icnt <= '0; after <= 1'b0; susp <= 1'b0; tpos <= '0; flag_on <= 1'b0; flag_pas <= 1'b0;
 35282296       fprev <= 1'b0; ack_exc <= 1'b0; first_after <= 1'b0; fcnt <= '0;
 35282296       dom_cnt <= '0; dcnt <= '0; rrun <= '0;
 35282296       bidx <= '0; flast <= '0; follow <= 1'b0; fext <= 1'b0; frtr <= 1'b0; fhave <= 1'b0; fdlc <= '0;
 35282296       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0; crc_step <= 1'b0;
 35282296       crc_bit <= 1'b0; arb_lost <= 1'b0; bit_err <= 1'b0; sent <= 1'b0;
~2162437     end else begin
~2162437       frame_end <= 1'b0; err <= 1'b0; crc_step <= 1'b0; arb_lost <= 1'b0; bit_err <= 1'b0;
~2162437       sent <= 1'b0;
~2162437       a_d <= a_in;
~2160759       if (rx_take) rx_valid <= 1'b0;
~2160826       if (tx_put) begin
~001611         q_valid <= 1'b1;
~001611         q_data  <= tx_data;
              end
        
              // ---- timer ----
~2139884       if (fstart || tend || (resync && sampled)) begin
~021292         cnt     <= '0;
~021292         sampled <= 1'b0;
~2139884       end else if (resync) cnt <= '0;            // a late edge: the current bit restarts
~2139884       else cnt <= cnt + 16'd1;
~2141249       if (sample) sampled <= 1'b1;
~021188       if (sample) synced <= 1'b0;
~2139108       else if (resync || fstart) synced <= 1'b1;
        
              // ---- LINECTL ----
~2161541       if (ctl && !follow) begin   // the follower owns a frame the program does not walk
~000739         if (!ctl_param[4]) begin
~000739           width  <= {1'b0, ctl_param[2:0]} + 4'd1;
~000739           arb_en <= ctl_param[3];
~000157         end else begin
~000157           if (ctl_param[0]) st_en <= 1'b0;
~000157           if (ctl_param[1]) st_en <= 1'b1;
                end
              end
        
              // ---- bit start ----
~000204       if (fstart) begin
~000204         cs <= C_FRAME; sof <= 1'b1; last <= 1'b1; run <= '0; stuff_pend <= 1'b0;
~000204         st_en <= st != 2'd0; arb_en <= 1'b1; width <= start_w; rbits <= '0; rsh <= '0;
~000204         slot_stuff <= 1'b0; after <= 1'b0; susp <= 1'b0; tleft <= '0;
~000204         bidx <= '0; follow <= 1'b0; fext <= 1'b0; fhave <= 1'b0;
~000114         if (q_valid) begin                       // this node's queued unit is the first one
~000090           tsh     <= q_rest;
~000090           tleft   <= start_w - 4'd1;
~000090           q_valid <= 1'b0;
~000090           cur     <= q_first;
~000090           own     <= !q_first && may_tx;
~000090           role_tx <= !q_first && may_tx;
~000090           silent  <= !may_tx;
~000090           drv     <= !q_first && may_tx;
~000090           if (!q_first && !may_tx) arb_lost <= 1'b1;  // may not start yet: lost before it began
~000090           joinw   <= 1'b0;
~000114         end else begin
~000114           cur <= 1'b1; own <= 1'b0; role_tx <= 1'b0; silent <= 1'b0; drv <= 1'b0;
~000114           joinw <= 1'b1;
                end
~000001       end else if (late_join) begin
~000001         tsh     <= q_rest;
~000001         tleft   <= width - 4'd1;
~000001         q_valid <= 1'b0;
~000001         cur     <= q_first;
~000001         own     <= !q_first && may_tx;
~000001         role_tx <= !q_first && may_tx;
~000001         silent  <= !may_tx;
~000001         drv     <= !q_first && may_tx;
~000001         if (!q_first && !may_tx) arb_lost <= 1'b1;
~000001         joinw   <= 1'b0;
~2139884       end else if ((tend || (resync && sampled)) && cs != C_IDLE) begin
~015876         sof <= 1'b0; joinw <= 1'b0;
~015876         case (cs)
~011935           C_FRAME:
~000422             if (stuff_pend) begin
~000422               slot_stuff <= 1'b1;
~000422               cur <= ones ? 1'b0 : !last;
~000422               drv <= !silent && (ones ? 1'b1 : last);
~011344             end else if (!st_en) begin           // the stuffed region is over: the tail
~000169               cs <= C_TAIL; tpos <= '0; slot_stuff <= 1'b0; silent <= 1'b0;
~000169               cur <= 1'b1; drv <= 1'b0;
~011344             end else begin
~011344               slot_stuff <= 1'b0;
~009912               if (have) begin
~009912                 cur   <= nb;
~009912                 drv   <= !silent && !nb;
~009912                 tsh   <= rest;
~009912                 tleft <= (tleft != 4'd0) ? tleft - 4'd1 : width - 4'd1;
~008391                 if (tleft == 4'd0) q_valid <= 1'b0;
~001432               end else begin
~001432                 cur <= 1'b1;
~001432                 drv <= 1'b0;
                      end
                    end
~001329           C_TAIL: begin
~001329             tpos <= tpos + 4'd1;
                    // the ACK slot (tpos 1 next): a node that did not transmit acknowledges a good CRC
~001329             cur  <= !(tpos == 4'd0 && is_rx && crc_ok);
~001329             drv  <= tpos == 4'd0 && is_rx && crc_ok;
                  end
~000348           C_EFLAG: begin
~000290             if (!flag_on) begin
~000058               flag_on <= 1'b1;
~000058               fcnt    <= '0;
                    end
~000348             cur <= flag_pas;
~000348             drv <= !flag_pas;
                  end
~002264           default: begin
~002264             cur <= 1'b1;
~002264             drv <= 1'b0;
                  end
                endcase
~2141145       end else if (tend && cs == C_IDLE) begin
~005212         cur <= 1'b1;
~005212         drv <= 1'b0;
              end
        
              // ---- sample point ----
~2141249       if (sample) begin
~021188         case (cs)
~000209           C_INTEG: begin
~000209             icnt <= b ? icnt + 5'd1 : 5'd0;
~000190             if (b && icnt == 5'd10) begin
~000019               cs   <= C_IDLE;
~000019               icnt <= 5'd11;
                    end
                  end
~005089           C_IDLE:
~005089             if (b) begin
~003476               if (icnt != 5'd31) icnt <= icnt + 5'd1;
%000000             end else icnt <= '0;
~011970           C_FRAME:
~020984             if (sof && b && !drv) begin          // a glitch, not a start of frame
~000001               cs <= C_IDLE;
~000001               drv <= 1'b0;
~011548             end else if (slot_stuff) begin
~000422               stuff_pend <= 1'b0;
~000422               last <= b;
~000422               run  <= ones ? 3'd0 : 3'd1;
~011548             end else begin
~011548               last <= b;
~011548               run  <= run_nx;
~011548               stuff_pend <= st_en && st != 2'd0 && run_nx == run_n;
~011432               if (!silent && arb_en && cur && !b) begin   // lost arbitration
~000116                 silent  <= 1'b1;
~000116                 drv     <= 1'b0;
~000116                 role_tx <= 1'b0;
~000114                 if (own) arb_lost <= 1'b1;
                      end
~011548               if (st_en) begin
~011548                 crc_step <= 1'b1;
~011548                 crc_bit  <= b;
                      end
                      // the frame follower: an extended frame (IDE recessive) or a standard frame with
                      // r0 recessive is walked here, not by the program: header, data length, CRC end
~011548               if (bidx != 7'd127) bidx <= bidx + 7'd1;
~011548               if (cfol) begin
~011336                 if (bidx == 7'd12 || (fext && bidx == 7'd32)) frtr <= b;   // RTR (SRR first)
~011538                 if (bidx == 7'd13 && b) begin fext <= 1'b1; follow <= 1'b1; end
~011546                 if (bidx == 7'd14 && !fext && b) follow <= 1'b1;
~010740                 if (bidx >= hdr_end - 7'd3 && bidx <= hdr_end) fdlc <= dlcv[2:0];
~011346                 if (bidx == hdr_end) begin
~000202                   flast <= hdr_end + 7'd15 + n8;   // the last CRC bit
~000202                   fhave <= 1'b1;
                        end
~011536                 if (follow && fhave && bidx == flast) st_en <= 1'b0;   // then the usual tail
                      end
~009704               if (rbits == width - 4'd1) begin
~001844                 rx_data  <= rsh_n;
~001844                 if (rx_valid && !rx_take) err <= 1'b1;
                        // nothing reaches the program after the unit that held IDE (bit 13) or r0
~001678                 if (!(follow && bidx > 7'd15)) rx_valid <= 1'b1;
~001844                 rbits    <= '0;
~001844                 rsh      <= '0;
~009704               end else begin
~009704                 rbits <= rbits + 4'd1;
~009704                 rsh   <= rsh_n;
                      end
                    end
~001498           C_TAIL:
~012872             if (tpos == 4'd9 && !e_now) begin    // the frame is over
~000145               cs <= C_IDLE; icnt <= '0; after <= 1'b1; susp <= role_tx && passive;
~000145               frame_end <= 1'b1;
~000035               if (role_tx) begin
~000035                 sent <= 1'b1;
~000033                 if (tec != 9'd0) tec <= tec - 9'd1;
~000001               end else if (rec > 8'd127) rec <= 8'd119;
~000104               else if (rec != 8'd0) rec <= rec - 8'd1;
                    end
~000348           C_EFLAG:
~000348             if (flag_on) begin
~000348               fcnt  <= fcnt + 3'd1;
~000348               fprev <= b;
~000114               if (flag_pas) begin
                        // a passive flag ends after 6 equal bits on the bus, counted from its start
~000095                 if (fcnt == 3'd0 || b != fprev) fcnt <= 3'd1;
~000095                 if (fcnt != 3'd0 && b == fprev && fcnt == 3'd5) begin
~000019                   cs <= C_EDWAIT; dom_cnt <= '0; first_after <= 1'b1;
                        end
~000114                 if (!b) ack_exc <= 1'b0;
~000195               end else if (fcnt == 3'd5) begin
~000039                 cs <= C_EDWAIT; dom_cnt <= 4'd6; first_after <= 1'b1;
                      end
                    end
~000248           C_EDWAIT: begin
~000248             first_after <= 1'b0;
~000058             if (b) begin
~000058               cs <= C_EDELIM; dcnt <= 3'd1;
~000190             end else if (dom_cnt == (flag_pas ? 4'd7 : 4'd13)) dom_cnt <= flag_pas ? 4'd0 : 4'd6;
~000190             else dom_cnt <= dom_cnt + 4'd1;
                  end
~000406           C_EDELIM:
~000406             if (b) begin
~000406               dcnt <= dcnt + 3'd1;
~000348               if (dcnt == 3'd7) begin
~000058                 cs <= C_IDLE; icnt <= '0; after <= 1'b1; susp <= role_tx && passive;
                      end
                    end
~001420           default: begin                         // C_BUSOFF: wait for 128 x 11 recessive bits
~001414             if (!b) rrun <= '0;
~001286             else if (rrun == 4'd10) begin
~000128               rrun <= '0;
~000128               rseq <= rseq + 7'd1;
~000127               if (rseq == 7'd127) begin
~000001                 cs <= C_IDLE; icnt <= 5'd11; after <= 1'b0; susp <= 1'b0;
~000001                 tec <= '0; rec <= '0;
                      end
~001286             end else rrun <= rrun + 4'd1;
                  end
                endcase
              end
        
              // ---- an error: count it, then the error flag from the next bit (or bus-off) ----
~2162437       if (e_tx8 || e_rx8) begin
~000017         tec <= tec_add[8:0];
~000017         rec <= rec_sat;
~000017         if (e_tx8 && ack_exc) ack_exc <= 1'b0;
~000017         if (to_busoff) begin
%000000           cs <= C_BUSOFF; rseq <= '0; rrun <= '0; drv <= 1'b0;
                end
              end
~2162378       if (e_now) begin
~000059         err       <= 1'b1;
~000059         frame_end <= 1'b1;
~000059         bit_err   <= e_bit;
~000059         q_valid   <= 1'b0;
~000059         tleft     <= '0;                         // the unit being sent is abandoned too
~000059         rx_valid  <= 1'b0;
~000059         tec       <= tec_add[8:0];
~000059         rec       <= rec_sat;
~000059         ack_exc   <= e_ack && passive && role_tx;
~000059         silent    <= 1'b0;
~000058         if (to_busoff) begin
~000001           cs <= C_BUSOFF; rseq <= '0; rrun <= '0; drv <= 1'b0;
~000058         end else begin
                  // the flag type is the state in which the error was detected (ISO 11898-1: the
                  // counter changes when the flag is sent, so the error that reaches 128 still gets
                  // an active flag; the next one gets a passive flag)
~000058           cs <= C_EFLAG; flag_on <= 1'b0; flag_pas <= passive;
                end
              end
~2162233       if (drop) begin
~000204         q_valid <= 1'b0;
~000204         if (cs != C_FRAME) tleft <= '0;
              end
            end
          end
~35282306   always @(posedge clk) if (rst_n && !clear) begin
~2162437     pbe_cov_bsync_state_integ: cover (cs == 3'd0);
~2162437     pbe_cov_bsync_state_idle: cover (cs == 3'd1);
~2162437     pbe_cov_bsync_state_frame: cover (cs == 3'd2);
~2162437     pbe_cov_bsync_state_tail: cover (cs == 3'd3);
~2162437     pbe_cov_bsync_state_eflag: cover (cs == 3'd4);
~2162437     pbe_cov_bsync_state_edwait: cover (cs == 3'd5);
~2162437     pbe_cov_bsync_state_edelim: cover (cs == 3'd6);
~2162437     pbe_cov_bsync_state_busoff: cover (cs == 3'd7);
~2162437     pbe_cov_bsync_own_start: cover (own_start);
~2162437     pbe_cov_bsync_foreign_start: cover (hard);
~2162437     pbe_cov_bsync_late_join: cover (late_join);
~2162437     pbe_cov_bsync_arbitration_lost: cover (arb_lost);
~2162437     pbe_cov_bsync_bit_error: cover (bit_err);
~2162437     pbe_cov_bsync_frame_sent: cover (sent);
~2162437     pbe_cov_bsync_error_detected: cover (e_now);
~2162437     pbe_cov_bsync_passive_flag: cover (cs == C_EFLAG && flag_on && flag_pas);
~2162437     pbe_cov_bsync_active_flag: cover (cs == C_EFLAG && flag_on && !flag_pas);
~2162437     pbe_cov_bsync_stuff_slot: cover (sample && slot_stuff);
~2162437     pbe_cov_bsync_ack_given: cover (cs == C_TAIL && drv);
~2162437     pbe_cov_bsync_unit_1: cover (sample && cs == C_FRAME && width == 1 && rx_valid == 0 && rbits == 0);
~2162437     pbe_cov_bsync_unit_3: cover (sample && cs == C_FRAME && width == 3 && rbits == 2);
~2162437     pbe_cov_bsync_unit_4: cover (sample && cs == C_FRAME && width == 4 && rbits == 3);
~2162437     pbe_cov_bsync_unit_7: cover (sample && cs == C_FRAME && width == 7 && rbits == 6);
~2162437     pbe_cov_bsync_unit_8: cover (sample && cs == C_FRAME && width == 8 && rbits == 7);
~2162437     pbe_cov_bsync_busoff_recovered: cover (cs == C_BUSOFF && sample && rseq == 7'd127 && rrun == 4'd10 && b);
          end
        
 000002   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
