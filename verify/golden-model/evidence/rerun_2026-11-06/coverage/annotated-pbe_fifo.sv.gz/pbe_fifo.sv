//      // verilator_coverage annotation
        // Small synchronous FIFO used between the host interface and each engine.
        // Push while full and pop while empty are ignored.
        // Acceptance uses occupancy before the edge: simultaneous push+pop when full only pops,
        // when empty only pushes, and at intermediate occupancy accepts both. Reset/flush zeros
        // both pointers and count, with flush winning over pointer updates. Storage is unreset and
        // an accepted push still writes its old write-pointer slot on a flush/reset edge; those
        // bytes are not logically queued after the reset/flush. dout continuously exposes the
        // head slot, even while empty (stale/unknown data); callers must qualify it with !empty.
        // This is the existing storage/pointer contract, clarified in the round-2 model audit.
        //
        // Mark and rewind (D70, for retransmission): `mark` remembers the read position and holds it;
        // `rewind` moves the read pointer back to it, so the bytes popped since the mark are read again.
        // While a mark is held, `full` counts from the mark, so a push cannot overwrite bytes that a
        // rewind could still need. Without a mark (reset, flush, or never marked) the mark follows the
        // read pointer and every output is exactly as before. Mark and rewind in the same clock: the
        // rewind wins and the mark stays where it was. A pop and a rewind in the same clock: the rewind
        // wins.
        module pbe_fifo #(
            parameter int WIDTH = 8,
            parameter int ADDR_BITS = 2  // depth = 2**ADDR_BITS
        ) (
 70564612     input  logic             clk,
~000048     input  logic             rst_n,
~000044     input  logic             flush,
 003994     input  logic             push,
~002475     input  logic [WIDTH-1:0] din,
 003994     input  logic             pop,
~000223     input  logic             mark,    // hold the current read position
~000169     input  logic             rewind,  // read again from the held position
~001218     output logic [WIDTH-1:0] dout,
 003360     output logic             empty,
~000006     output logic             full,
~003994     output logic [ADDR_BITS:0] count  // bytes held
        );
          localparam int DEPTH = 1 << ADDR_BITS;
        
~000064   logic [WIDTH-1:0] mem[DEPTH];
~001999   logic [ADDR_BITS:0] wptr, rptr;  // extra bit tells full from empty
~001999   logic [ADDR_BITS:0] mptr;        // the mark (equals rptr while no mark is held)
~000019   logic               held;
        
          assign empty = (wptr == rptr);
~65499841   assign full  = (wptr[ADDR_BITS-1:0] == mptr[ADDR_BITS-1:0]) && (wptr[ADDR_BITS] != mptr[ADDR_BITS]);
          assign dout  = mem[rptr[ADDR_BITS-1:0]];
          assign count = wptr - rptr;
        
 70564612   always_ff @(posedge clk or negedge rst_n) begin
 70564592     if (!rst_n) begin
 000328       wptr <= '0;
 000328       rptr <= '0;
 000328       mptr <= '0;
 000328       held <= 1'b0;
~70564576     end else if (flush) begin
~000044       wptr <= '0;
~000044       rptr <= '0;
~000044       mptr <= '0;
~000044       held <= 1'b0;
 70564576     end else begin
~70563409       if (push && !full) wptr <= wptr + 1'b1;
~000169       if (rewind) rptr <= mptr;
 70563412       else if (pop && !empty) begin
 003994         rptr <= rptr + 1'b1;
~003994         if (!held && !mark) mptr <= rptr + 1'b1;
              end
~70564576       if (mark && !rewind) begin
~000223         mptr <= rptr;
~000223         held <= 1'b1;
              end
            end
          end
        
          // Storage has no reset: logical consumers must qualify reads with !empty.
 70564612   always_ff @(posedge clk) begin
~70563445     if (push && !full) mem[wptr[ADDR_BITS-1:0]] <= din;
          end
        
 000004   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
