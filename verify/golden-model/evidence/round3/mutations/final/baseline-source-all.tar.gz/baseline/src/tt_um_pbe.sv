// Programmable Bit Engine: top level for Tiny Tapeout.
//
// Pins
//   ui_in[0]  host SCK        uo_out[0]  host MISO
//   ui_in[1]  host CS_n       uo_out[1]  IRQ (engine 0 or 1 raised an interrupt)
//   ui_in[2]  host MOSI (D0)  uo_out[2]  engine 0 running    uo_out[3] engine 1 running
//   ui_in[3]  host D1 (quad)
//   ui_in[4]  host D2 (quad)
//   ui_in[5]  host D3 (quad)
//                             uo_out[4]  E0 RX FIFO has data uo_out[5] E1 RX FIFO has data
//                             uo_out[6]  E0 TX FIFO full     uo_out[7] E1 TX FIFO full
//   uio[7:0]  protocol pins, driven by the engines
//   Quad host mode (HOSTCFG[0], D89): while CS_n is low, uo_out[3:1] carry Q3..Q1 of the
//   host port's read data (uo_out[0] is Q0); while CS_n is high they show IRQ and the running
//   bits as above. uo_out[7:4] (RX data, TX full) are never borrowed: they are the flow control
//   of a streaming host. ui_in[6] and ui_in[7] are unused.
//
// Register map (7-bit address, see pbe_host_spi for the SPI framing)
//   0x00 CTRL     W  [0] run E0, [1] run E1, [4] restart E0, [5] restart E1,
//                    [6] flush E0 FIFOs, [7] flush E1 FIFOs   (bits 4..7 are self-clearing)
//                 R  [0] run E0, [1] run E1
//   0x01 STATUS   R  [0] E0 RX empty, [1] E0 RX full, [2] E0 TX empty, [3] E0 TX full, [7:4] same for E1
//   0x02 IRQ      R  [0] E0, [1] E1 pending;  W  write 1 to clear
//   0x03 PIN_OWN  RW bit i = 1 gives pin i to E1, 0 to E0
//   0x04 FLAGS    RW 8 flags. Engine e's FLAG n (n = 0..3 in instructions) is flag (FLAG_BASE[e] + n) mod 8,
//                    so by default engine 0 has flags 0-3 and engine 1 has flags 4-7; overlapping
//                    bases let the engines signal each other
//   0x08 FLAG_SET W  write 1s to set flags
//   0x09 FLAG_CLR W  write 1s to clear flags (use these two so the other engine's flags are untouched)
//   0x05 PINS     R  synchronized pin levels
//   0x0A, 0x0B RX_COUNT R  bytes in E0's, E1's RX FIFO; 0x0C, 0x0D TX_COUNT R  bytes in their TX FIFOs.
//                    A burst read of an RX FIFO must not read more than RX_COUNT bytes: a byte that
//                    arrives during the burst is not in it (the host would get a stale value)
//   0x0E TX_FLUSH W  [0] empties E0's TX FIFO, [1] E1's, leaving the RX FIFOs alone (to drop a
//                    queued reply while received data keeps arriving)
//   Program memory (D82): each engine has its own 256 x 16 memory (an IHP SRAM macro), 512
//   words in all. The host writes through a 10-bit byte pointer {PM_ADDR_H[1:0], PM_ADDR[7:0]}
//   = {engine, word[7:0], byte}:
//   0x06 PM_ADDR  RW pointer [7:0]: [7:1] word[6:0], [0] = 0 high byte, 1 low byte
//   0x50 HOSTCFG  RW [0] quad host mode (D89): takes effect at the next CS_n high, so the
//                    transaction that writes it ends in the old mode. Back to single mode:
//                    write 0 (in quad mode), or 8 SCK rising edges while CS_n is high (works
//                    whatever the mode), or reset. Reset 0: single-lane SPI.
//   0x0F PM_ADDR_H RW pointer [9:8]: [0] word[7], [1] engine (0 = E0's memory, 1 = E1's);
//                    [7:2] read 0. Reset 0: engine 0, word 0, high byte
//   0x07 PM_DATA  W  write the byte at the pointer into the selected engine's memory, then
//                    {word, byte} += 1: the low byte carries into the next word and word 255
//                    into word 0 of the same engine (the engine bit never changes). A burst
//                    (one SPI write with many data bytes) streams a whole image. Write only.
//                    Only the selected engine refetches (two bubbles, BUG-074); the other runs on.
//   With PBE_PMEM_FF (the flip-flop fallback, D82) each engine has 64 words: the same registers;
//   writes to words 64-255 are dropped, and pc and START_PC address the words mod 64.
//   0x10+0x10*e   engine e (e = 0, 1):
//      +0 CLKDIV_L, +1 CLKDIV_H   tick every (CLKDIV + 1) clocks
//      +2 PIN_BASE[2:0]  +3 JMP_PIN[2:0]  +4 SHIFT [0] OUT msb first, [1] IN msb first
//      +5 START_PC[7:0]   the program's first word in this engine's own memory; 6-bit jump
//                         offsets are relative to it, modulo 256; sequential execution is not
//                         confined to 64 words (a PAGE instruction is reserved for that, D82)
//      +8 FLAG_BASE[2:0]  first physical flag this engine sees (reset: 0 for E0, 4 for E1)
//      +9 CRC_POLY_L, +A CRC_POLY_H   W: CRC polynomial bits 15..0 (top term implied); R: the CRC's
//                    current value, bits 15..0 (bits 31..16 at second-page +8, +9, D91)
//      +B CRC_CFG    [3:0] width - 1, [4] init all ones, [5] reversed output, [6] feed OUT bits,
//                    [7] feed IN bits (both 0: CRC off)
//      +C TIMEOUT_L, +D TIMEOUT_H     ticks a blocked WAIT/PULL/PUSH may wait (0 = forever)
//      +E LINE_CFG   [5:0] TIMEOUT_PC (where a timeout jumps), [6] no parity, [7] odd parity
//      +F STATUS     R: [0] receive parity error, [1] CRC ok (at CRC_GOOD), [2] timeout happened,
//                       [3] RX overflow (a PUSH found the RX FIFO full; also raises IRQ),
//                       [4] line error (line coder: stuff error, receive overrun, send underrun;
//                           bit-synchronous mode: any bus error), [5] arbitration lost,
//                       [6] bit error, [7] frame sent (bit-synchronous mode, D71)
//                    W: [0] = 1 restarts the CRC, [1] = 1 clears "timeout happened",
//                       [2] = 1 clears "RX overflow", [3] = 1 clears "line error",
//                       [4] = 1 clears "arbitration lost", [5] = 1 clears "bit error",
//                       [6] = 1 clears "frame sent"
//      +6 FIFO data: W pushes the TX FIFO, R pops the RX FIFO (each FIFO holds 16 bytes)
//   0x30+0x10*e   engine e, second page:
//      +0 LINE       line coder, see pbe_line: [1:0] mode (0 off, 1 NRZ, 2 NRZI, 3 Manchester,
//                    D90), [3:2] stuffing (0 none, 1 after 6 ones, 2 after 5 ones, 3 after 5
//                    equal; none in Manchester), [4] pair, [5] bytes, [6] flag-delimited frames
//                    (HDLC, D94), [7] Manchester polarity (0 IEEE 802.3: a 1 is low then high)
//      +1 SYNC       frame start pattern (0 = none)
//      +2 CRC_GOOD_L, +3 CRC_GOOD_H   the CRC value that means "ok" (0 unless the CRC is sent inverted)
//      +4 LINE2      line coder (D65): [2:0] sample point (0 default, 1 62.5 %, 2 75 %, 3 87.5 %),
//                    [3] resync on falling edges only, [4] receive on pin_base+1, [5] bit-synchronous
//                    (CAN) mode, see pbe_bsync, [6] wait for bus idle before a frame, [7] CAN
//                    frame follower (extended frames, D74). Reset 0.
//      +5 CAN_TEC  R transmit error counter [7:0]; +6 CAN_REC R receive error counter
//      +7 CAN_STATE R [0] TEC[8], [1] error-passive, [2] bus-off (bit-synchronous mode, D68)
//      +8 CRC_POLY_2, +9 CRC_POLY_3   W: CRC polynomial bits 23..16, 31..24; R: the CRC's current
//                    value, bits 23..16, 31..24 (CRCs of 17-32 bits, D91). Reset 0.
//      +A CRC_GOOD_2, +B CRC_GOOD_3   RW: CRC_GOOD bits 23..16, 31..24. Reset 0.
//      +C CRC_CFG2   RW [0] CRC width bit 4: width - 1 = {CRC_CFG2[0], CRC_CFG[3:0]} (1-32 bits).
//                    Reset 0, which leaves every CRC of up to 16 bits as before.
//
// Edge/reset contract, clarified by the round-2 model audit (no logic changes):
// Host pins and protocol pins pass through two clk registers; engines/host SPI consume
// their pre-edge second-stage values. ena and ui_in[7:6] have no functional effect;
// ui_in[5:3] only in quad host mode (D89).
// Reset: host synchronizers=6'b000010, protocol synchronizers=0; configuration, run, IRQ,
// ownership, flags, PM pointer=0 except FLAG_BASE={4,0}. RAM/FIFO storage is not reset;
// both bytes of an unwritten program word must be loaded before deterministic execution.
// Register writes/config changes affect engines on the next edge; combinational pin muxes
// and readback reflect the newly written configuration immediately after the write edge.
// Full FLAGS write wins over all same-edge flag events; otherwise clear wins over set
// across host and both engines. IRQ W1C wins over same-edge IRQ assertion. CTRL run bits
// are always replaced, even for a restart/flush write; restart and flush are independent.
// PM_DATA byte writes wrap the 9-bit {word, byte} pointer within the selected engine and
// invalidate that engine's fetch (twice: at the write and one clock later, and once after
// reset, BUG-074), regardless of which of its words was written; the other engine is
// untouched. Other byte of a partially written word is retained/unspecified, never
// zero-initialized by the write. PM_DATA has no readable RAM.
// FIFO acceptance and flush ordering are in pbe_fifo. An empty FIFO read returns its
// unqualified head storage (possibly stale/unknown); only a nonempty pop changes count.
// Unmapped register reads return 0 and unmapped writes do nothing. Only the documented
// low-width configuration bits are stored/read; other readback bits are 0. LINE[7]
// is reserved outside Manchester mode (3, D90); LINE[6] does nothing in Manchester mode. The CAN counters survive a restart; only reset (or bus-off recovery)
// clears them.
module tt_um_ayushyadavnvs_pbe (  // Tiny Tapeout needs the GitHub user in the name
    input  wire [7:0] ui_in,
    output wire [7:0] uo_out,
    input  wire [7:0] uio_in,
    output wire [7:0] uio_out,
    output wire [7:0] uio_oe,
    input  wire       ena,
    input  wire       clk,
    input  wire       rst_n
);
  // ---- input synchronizers ----
  logic [5:0] host_s1, host_s2;  // {D3, D2, D1, MOSI/D0, CS_n, SCK}
  logic [7:0] pins_s1, pins_s2;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      host_s1 <= 6'b000010;  // CS_n idles high
      host_s2 <= 6'b000010;
      pins_s1 <= '0;
      pins_s2 <= '0;
    end else begin
      host_s1 <= ui_in[5:0];
      host_s2 <= host_s1;
      pins_s1 <= uio_in;
      pins_s2 <= pins_s1;
    end
  end

  // The protocol pins sampled on the falling clock edge too (D90): pins_n0 at the falling edge,
  // then two rising-edge stages, so pins_n2 is the pin half a clock before pins_s2 (a 3-flop
  // synchronizer whose first stage has half a clock to settle). Only the Manchester receiver
  // reads it, to time edges to half a clock.
  logic [7:0] pins_n0, pins_n1, pins_n2;
  always_ff @(negedge clk or negedge rst_n)
    if (!rst_n) pins_n0 <= '0;
    else pins_n0 <= uio_in;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      pins_n1 <= '0;
      pins_n2 <= '0;
    end else begin
      pins_n1 <= pins_n0;
      pins_n2 <= pins_n1;
    end

  // ---- host register port ----
  logic [6:0] addr, wr_addr, rd_addr;
  logic [7:0] rd_data, wr_data;
  logic       wr_en, rd_done, miso;
  logic [2:0] miso_hi;
  logic       host_quad, quad, quad_exit;  // HOSTCFG[0]; the mode in use; the SCK recovery

  pbe_host_spi u_host (
      .clk, .rst_n,
      .sck (host_s2[0]),
      .cs_n(host_s2[1]),
      .mosi(host_s2[2]),
      .miso,
      .quad_req (host_quad),
      .mosi_hi  (host_s2[5:3]),
      .miso_hi,
      .quad,
      .quad_exit,
      .addr, .rd_data, .wr_en, .wr_addr, .wr_data, .rd_done, .rd_addr
  );

  // ---- control and configuration registers ----
  // Per-engine values are packed into flat buses: engine e uses slice [e*W +: W].
  logic [1:0]  run, irq_pend;
  logic [7:0]  pin_own;
  logic [7:0]  flags;
  logic [5:0]  flag_base;  // 3 bits per engine
  logic [63:0] crc_poly;   // 32 bits per engine (D91)
  logic [31:0] timeout;
  logic [15:0] crc_cfg, line_cfg;
  logic [15:0] e_status;   // 8 bits per engine
  logic [15:0] coder_cfg, coder_cfg2, sync;
  logic [17:0] can_tec;    // 9 bits per engine
  logic [15:0] can_rec;
  logic [3:0]  can_state;  // {bus-off, passive} per engine
  logic [63:0] crc_good;   // 32 bits per engine (D91)
  logic [63:0] e_crc;      // each engine's current CRC value
  logic [1:0]  crc_wide;   // CRC_CFG2[0] per engine
  logic [31:0] clkdiv;
  logic [5:0]  pin_base, jmp_pin;
  logic [3:0]  shiftcfg;
  logic [15:0] start_pc;  // 8 bits per engine
  logic [9:0]  pm_ptr;    // {engine, word[7:0], byte}

  wire [1:0] restart = (wr_en && wr_addr == 7'h00) ? wr_data[5:4] : 2'b00;
  wire [1:0] flush   = (wr_en && wr_addr == 7'h00) ? wr_data[7:6] : 2'b00;
  wire [1:0] tx_flush = flush | ((wr_en && wr_addr == 7'h0E) ? wr_data[1:0] : 2'b00);

  // engine-facing signals
  logic [15:0] pc;       // 8 bits per engine
  logic [47:0] pc_copy;  // 3 x 8 bits per engine
  logic [31:0] instr;
  logic [15:0] e_out, e_oe, tx_data, rx_din, rx_dout;
  logic [1:0]  tx_empty, tx_full, tx_pop, tx_mark, tx_rewind, rx_empty, rx_full, rx_push, e_irq;
  logic [9:0]  tx_count, rx_count;  // 5 bits per engine
  logic [7:0]  f_set, f_clr;  // engine-relative, 4 bits per engine
  logic [15:0] p_set, p_clr;  // the same, mapped to physical flags, 8 bits per engine
  logic [7:0]  e_flags;       // each engine's view of its 4 flags

  wire [7:0] host_set = (wr_en && wr_addr == 7'h08) ? wr_data : 8'h00;
  wire [7:0] host_clr = (wr_en && wr_addr == 7'h09) ? wr_data : 8'h00;

  wire       wr_e0 = wr_en && wr_addr[6:4] == 3'd1;
  wire       wr_e1 = wr_en && wr_addr[6:4] == 3'd2;
  wire       wr_p0 = wr_en && wr_addr[6:4] == 3'd3;  // second pages
  wire       wr_p1 = wr_en && wr_addr[6:4] == 3'd4;
  wire [3:0] wr_reg = wr_addr[3:0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      run      <= '0;
      irq_pend <= '0;
      pin_own  <= '0;
      flags    <= '0;
      flag_base <= 6'b100_000;  // E1 starts at flag 4, E0 at flag 0
      crc_poly <= '0;
      crc_cfg  <= '0;
      timeout  <= '0;
      line_cfg <= '0;
      clkdiv   <= '0;
      pin_base <= '0;
      jmp_pin  <= '0;
      shiftcfg <= '0;
      start_pc <= '0;
      pm_ptr   <= '0;
      coder_cfg <= '0;
      coder_cfg2 <= '0;
      sync     <= '0;
      crc_good <= '0;
      crc_wide <= '0;
      host_quad <= 1'b0;
    end else begin
      if (quad_exit) host_quad <= 1'b0;  // 8 SCK edges with CS_n high (never during a write)
      // engine events first, so a host write in the same cycle wins
      flags    <= (flags | p_set[7:0] | p_set[15:8] | host_set) & ~(p_clr[7:0] | p_clr[15:8] | host_clr);
      irq_pend <= irq_pend | e_irq;

      if (wr_en) begin
        case (wr_addr)
          7'h00: run <= wr_data[1:0];
          7'h02: irq_pend <= (irq_pend | e_irq) & ~wr_data[1:0];
          7'h03: pin_own <= wr_data;
          7'h04: flags <= wr_data;
          7'h06: pm_ptr[7:0] <= wr_data;
          7'h0F: pm_ptr[9:8] <= wr_data[1:0];
          7'h07: pm_ptr[8:0] <= pm_ptr[8:0] + 1'b1;  // the engine bit stays
          7'h50: host_quad <= wr_data[0];
          default: ;
        endcase
      end
      if (wr_e0) begin
        case (wr_reg)
          4'h0: clkdiv[7:0]   <= wr_data;
          4'h1: clkdiv[15:8]  <= wr_data;
          4'h2: pin_base[2:0] <= wr_data[2:0];
          4'h3: jmp_pin[2:0]  <= wr_data[2:0];
          4'h4: shiftcfg[1:0] <= wr_data[1:0];
          4'h5: start_pc[7:0]  <= wr_data;
          4'h8: flag_base[2:0] <= wr_data[2:0];
          4'h9: crc_poly[7:0]   <= wr_data;
          4'hA: crc_poly[15:8]  <= wr_data;
          4'hB: crc_cfg[7:0]    <= wr_data;
          4'hC: timeout[7:0]    <= wr_data;
          4'hD: timeout[15:8]   <= wr_data;
          4'hE: line_cfg[7:0]   <= wr_data;
          default: ;
        endcase
      end
      if (wr_e1) begin
        case (wr_reg)
          4'h0: clkdiv[23:16] <= wr_data;
          4'h1: clkdiv[31:24] <= wr_data;
          4'h2: pin_base[5:3] <= wr_data[2:0];
          4'h3: jmp_pin[5:3]  <= wr_data[2:0];
          4'h4: shiftcfg[3:2] <= wr_data[1:0];
          4'h5: start_pc[15:8] <= wr_data;
          4'h8: flag_base[5:3] <= wr_data[2:0];
          4'h9: crc_poly[39:32] <= wr_data;
          4'hA: crc_poly[47:40] <= wr_data;
          4'hB: crc_cfg[15:8]   <= wr_data;
          4'hC: timeout[23:16]  <= wr_data;
          4'hD: timeout[31:24]  <= wr_data;
          4'hE: line_cfg[15:8]  <= wr_data;
          default: ;
        endcase
      end
      if (wr_p0 || wr_p1) begin
        case (wr_reg)
          4'h0: if (wr_p1) coder_cfg[15:8] <= wr_data; else coder_cfg[7:0] <= wr_data;
          4'h1: if (wr_p1) sync[15:8] <= wr_data; else sync[7:0] <= wr_data;
          4'h2: if (wr_p1) crc_good[39:32] <= wr_data; else crc_good[7:0] <= wr_data;
          4'h3: if (wr_p1) crc_good[47:40] <= wr_data; else crc_good[15:8] <= wr_data;
          4'h4: if (wr_p1) coder_cfg2[15:8] <= wr_data; else coder_cfg2[7:0] <= wr_data;
          4'h8: if (wr_p1) crc_poly[55:48] <= wr_data; else crc_poly[23:16] <= wr_data;
          4'h9: if (wr_p1) crc_poly[63:56] <= wr_data; else crc_poly[31:24] <= wr_data;
          4'hA: if (wr_p1) crc_good[55:48] <= wr_data; else crc_good[23:16] <= wr_data;
          4'hB: if (wr_p1) crc_good[63:56] <= wr_data; else crc_good[31:24] <= wr_data;
          4'hC: if (wr_p1) crc_wide[1] <= wr_data[0]; else crc_wide[0] <= wr_data[0];
          default: ;
        endcase
      end
    end
  end

  // ---- register read mux ----
  wire       rd_eng = addr[6:4] == 3'd1 || addr[6:4] == 3'd2;
  wire       rd_e1  = addr[5];  // 0x2x
  wire [3:0] rd_reg = addr[3:0];

  logic [7:0] eng_rd;
  always_comb begin
    case (rd_reg)
      4'h0:    eng_rd = rd_e1 ? clkdiv[23:16] : clkdiv[7:0];
      4'h1:    eng_rd = rd_e1 ? clkdiv[31:24] : clkdiv[15:8];
      4'h2:    eng_rd = {5'b0, rd_e1 ? pin_base[5:3] : pin_base[2:0]};
      4'h3:    eng_rd = {5'b0, rd_e1 ? jmp_pin[5:3] : jmp_pin[2:0]};
      4'h4:    eng_rd = {6'b0, rd_e1 ? shiftcfg[3:2] : shiftcfg[1:0]};
      4'h5:    eng_rd = rd_e1 ? start_pc[15:8] : start_pc[7:0];
      4'h8:    eng_rd = {5'b0, rd_e1 ? flag_base[5:3] : flag_base[2:0]};
      4'h9:    eng_rd = rd_e1 ? e_crc[39:32] : e_crc[7:0];   // reads give the CRC value
      4'hA:    eng_rd = rd_e1 ? e_crc[47:40] : e_crc[15:8];
      4'hB:    eng_rd = rd_e1 ? crc_cfg[15:8] : crc_cfg[7:0];
      4'hC:    eng_rd = rd_e1 ? timeout[23:16] : timeout[7:0];
      4'hD:    eng_rd = rd_e1 ? timeout[31:24] : timeout[15:8];
      4'hE:    eng_rd = rd_e1 ? line_cfg[15:8] : line_cfg[7:0];
      4'hF:    eng_rd = rd_e1 ? e_status[15:8] : e_status[7:0];
      4'h6:    eng_rd = rd_e1 ? rx_dout[15:8] : rx_dout[7:0];
      default: eng_rd = 8'h00;
    endcase
  end

  wire       rd_pg  = addr[6:4] == 3'd3 || addr[6:4] == 3'd4;
  wire       rd_p1  = addr[6:4] == 3'd4;
  logic [7:0] pg_rd;
  always_comb begin
    case (rd_reg)
      4'h0:    pg_rd = rd_p1 ? coder_cfg[15:8] : coder_cfg[7:0];
      4'h1:    pg_rd = rd_p1 ? sync[15:8] : sync[7:0];
      4'h2:    pg_rd = rd_p1 ? crc_good[39:32] : crc_good[7:0];
      4'h3:    pg_rd = rd_p1 ? crc_good[47:40] : crc_good[15:8];
      4'h4:    pg_rd = rd_p1 ? coder_cfg2[15:8] : coder_cfg2[7:0];
      4'h5:    pg_rd = rd_p1 ? can_tec[16:9] : can_tec[7:0];
      4'h6:    pg_rd = rd_p1 ? can_rec[15:8] : can_rec[7:0];
      4'h7:    pg_rd = {5'b0, rd_p1 ? {can_state[3:2], can_tec[17]} : {can_state[1:0], can_tec[8]}};
      4'h8:    pg_rd = rd_p1 ? e_crc[55:48] : e_crc[23:16];     // the CRC value, bits 23..16
      4'h9:    pg_rd = rd_p1 ? e_crc[63:56] : e_crc[31:24];
      4'hA:    pg_rd = rd_p1 ? crc_good[55:48] : crc_good[23:16];
      4'hB:    pg_rd = rd_p1 ? crc_good[63:56] : crc_good[31:24];
      4'hC:    pg_rd = {7'b0, crc_wide[rd_p1]};
      default: pg_rd = 8'h00;
    endcase
  end

  always_comb begin
    case (addr)
      7'h00:   rd_data = {6'b0, run};
      7'h01:   rd_data = {tx_full[1], tx_empty[1], rx_full[1], rx_empty[1],
                          tx_full[0], tx_empty[0], rx_full[0], rx_empty[0]};
      7'h02:   rd_data = {6'b0, irq_pend};
      7'h03:   rd_data = pin_own;
      7'h04:   rd_data = flags;
      7'h05:   rd_data = pins_s2;
      7'h06:   rd_data = pm_ptr[7:0];
      7'h0F:   rd_data = {6'b0, pm_ptr[9:8]};
      7'h0A:   rd_data = {3'b0, rx_count[4:0]};
      7'h0B:   rd_data = {3'b0, rx_count[9:5]};
      7'h0C:   rd_data = {3'b0, tx_count[4:0]};
      7'h0D:   rd_data = {3'b0, tx_count[9:5]};
      7'h50:   rd_data = {7'b0, host_quad};
      default: rd_data = rd_eng ? eng_rd : rd_pg ? pg_rd : 8'h00;
    endcase
  end

  // ---- program memory: one 256 x 16 memory per engine, written by the host (D82) ----
  // Each engine reads the word after its current instruction into its instruction register
  // (D50), so this read is a pipeline stage of its own. A write goes to the engine that the
  // pointer's top bit selects, and only that engine refetches.
  wire         pm_wr = wr_en && wr_addr == 7'h07;
  wire  [1:0]  pm_wr_e = {pm_wr && pm_ptr[9], pm_wr && !pm_ptr[9]};
  logic [15:0] pc_d;      // each engine's next read address (8 bits per engine)
  logic [1:0]  eng_pm_wr; // each engine's refetch
`ifndef PBE_PMEM_FF
  // The default: an IHP SRAM macro per engine (pbe_pmem_sram, D62, D82). A write takes that
  // macro's port for that clock, so its engine refetches at the write and once more one clock
  // later (BUG-074). The reset value refetches once after reset, when the macros' output is
  // unknown.
  localparam bit PC_COPIES = 1'b0;
  logic [1:0] pm_wr_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pm_wr_q <= 2'b11;
    else pm_wr_q <= pm_wr_e;
  end
  assign eng_pm_wr = pm_wr_e | pm_wr_q;

  pbe_pmem_sram u_pmem (.clk, .pm_wr(pm_wr_e), .pm_ptr(pm_ptr[8:0]), .wr_data, .pc_d, .instr);
  wire _unused_pc = &{pc, pc_copy, 1'b0};
`else
  // The flip-flop fallback (D82): 64 x 16 per engine, the same flip-flop count as the shared
  // 128-word memory before D82. Writes to words 64-255 are dropped (BUG-111: a whole 256-word
  // image would otherwise overwrite words 0-63 with its upper words); reads wrap mod 64.
  localparam bit PC_COPIES = 1'b1;
  assign eng_pm_wr = pm_wr_e;
  logic [15:0] pmem0[64], pmem1[64];
  wire  [5:0]  pm_word = pm_ptr[6:1];
  wire         pm_low  = pm_ptr[8:7] == 2'b00;  // a word below 64
  always_ff @(posedge clk) begin
    if (pm_wr_e[0] && pm_low) begin
      if (pm_ptr[0]) pmem0[pm_word][7:0] <= wr_data;
      else pmem0[pm_word][15:8] <= wr_data;
    end
    if (pm_wr_e[1] && pm_low) begin
      if (pm_ptr[0]) pmem1[pm_word][7:0] <= wr_data;
      else pmem1[pm_word][15:8] <= wr_data;
    end
  end
  // Each engine reads its 16 bits as four 4-bit slices, each at its own copy of the address.
  wire [31:0] ra0 = {pc_copy[23:0], pc[7:0]};
  wire [31:0] ra1 = {pc_copy[47:24], pc[15:8]};
  for (genvar k = 0; k < 4; k++) begin : g_slice
    assign instr[k*4+:4]      = pmem0[ra0[k*8+:6]][k*4+:4];
    assign instr[16+k*4+:4]   = pmem1[ra1[k*8+:6]][k*4+:4];
  end
  wire _unused_pc_d = &{pc_d, ra0[31:30], ra0[23:22], ra0[15:14], ra0[7:6],
                        ra1[31:30], ra1[23:22], ra1[15:14], ra1[7:6], 1'b0};
`endif

  // ---- engines and their FIFOs ----
  for (genvar e = 0; e < 2; e++) begin : g_eng
    localparam logic [6:0] FIFO_ADDR = (e == 0) ? 7'h16 : 7'h26;

    pbe_fifo #(.ADDR_BITS(4)) u_txf (
        .clk, .rst_n,
        .flush(tx_flush[e]),
        .push (wr_en && wr_addr == FIFO_ADDR),
        .din  (wr_data),
        .pop  (tx_pop[e]),
        .mark (tx_mark[e]),
        .rewind(tx_rewind[e]),
        .dout (tx_data[e*8+:8]),
        .empty(tx_empty[e]),
        .full (tx_full[e]),
        .count(tx_count[e*5+:5])
    );

    pbe_fifo #(.ADDR_BITS(4)) u_rxf (
        .clk, .rst_n,
        .flush(flush[e]),
        .push (rx_push[e]),
        .din  (rx_din[e*8+:8]),
        .pop  (rd_done && rd_addr == FIFO_ADDR),
        .mark (1'b0),
        .rewind(1'b0),
        .dout (rx_dout[e*8+:8]),
        .empty(rx_empty[e]),
        .full (rx_full[e]),
        .count(rx_count[e*5+:5])
    );

    // Engine-relative flags: FLAG n is physical flag (base + n) mod 8.
    wire [2:0]  fbase = flag_base[e*3+:3];
    wire [15:0] fl2   = {flags, flags};
    wire [15:0] set2  = {12'b0, f_set[e*4+:4]} << fbase;
    wire [15:0] clr2  = {12'b0, f_clr[e*4+:4]} << fbase;
    assign e_flags[e*4+:4] = fl2[{1'b0, fbase}+:4];
    assign p_set[e*8+:8]   = set2[7:0] | set2[15:8];
    assign p_clr[e*8+:8]   = clr2[7:0] | clr2[15:8];

    pbe_engine #(.PC_COPIES(PC_COPIES)) u_eng (
        .clk, .rst_n,
        .run          (run[e]),
        .restart      (restart[e]),
        .clkdiv       (clkdiv[e*16+:16]),
        .pin_base     (pin_base[e*3+:3]),
        .jmp_pin      (jmp_pin[e*3+:3]),
        .out_msb_first(shiftcfg[e*2]),
        .in_msb_first (shiftcfg[e*2+1]),
        .start_pc     (start_pc[e*8+:8]),
        .crc_poly     (crc_poly[e*32+:32]),
        .crc_cfg      (crc_cfg[e*8+:8]),
        .crc_wide     (crc_wide[e]),
        .timeout      (timeout[e*16+:16]),
        .line_cfg     (line_cfg[e*8+:8]),
        .coder_cfg    (coder_cfg[e*8+:8]),
        .coder_cfg2   (coder_cfg2[e*8+:8]),
        .sync         (sync[e*8+:8]),
        .crc_good     (crc_good[e*32+:32]),
        .host_crc_init(wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[0]),
        .host_tmo_clr (wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[1]),
        .host_ovf_clr (wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[2]),
        .host_lerr_clr(wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[3]),
        .host_arb_clr (wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[4]),
        .host_berr_clr(wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[5]),
        .host_sent_clr(wr_en && wr_addr == FIFO_ADDR + 7'd9 && wr_data[6]),
        .status       (e_status[e*8+:8]),
        .can_tec      (can_tec[e*9+:9]),
        .can_rec      (can_rec[e*8+:8]),
        .can_state    (can_state[e*2+:2]),
        .crc_now      (e_crc[e*32+:32]),
        .pc           (pc[e*8+:8]),
        .pc_copy      (pc_copy[e*24+:24]),
        .pc_d         (pc_d[e*8+:8]),
        .instr        (instr[e*16+:16]),
        .pm_wr        (eng_pm_wr[e]),
        .pins_in      (pins_s2),
        .pins_in_n    (pins_n2),
        .pins_out     (e_out[e*8+:8]),
        .pins_oe      (e_oe[e*8+:8]),
        .tx_data      (tx_data[e*8+:8]),
        .tx_empty     (tx_empty[e]),
        .tx_pop       (tx_pop[e]),
        .tx_mark      (tx_mark[e]),
        .tx_rewind    (tx_rewind[e]),
        .rx_data      (rx_din[e*8+:8]),
        .rx_full      (rx_full[e]),
        .rx_push      (rx_push[e]),
        .flags        (e_flags[e*4+:4]),
        .flag_set     (f_set[e*4+:4]),
        .flag_clr     (f_clr[e*4+:4]),
        .irq          (e_irq[e])
    );
  end

  // ---- pin mux: each pin is driven by exactly one engine ----
  assign uio_out = (e_out[15:8] & pin_own) | (e_out[7:0] & ~pin_own);
  assign uio_oe  = (e_oe[15:8] & pin_own)  | (e_oe[7:0] & ~pin_own);

  // quad host mode (D89): Q3..Q1 on uo_out[3:1] while CS_n is low
  wire q_lines = quad && !host_s2[1];
  assign uo_out = {tx_full[1], tx_full[0], ~rx_empty[1], ~rx_empty[0],
                   q_lines ? miso_hi : {run[1], run[0], |irq_pend}, miso};

  wire _unused = &{ena, ui_in[7:6], 1'b0};
endmodule
