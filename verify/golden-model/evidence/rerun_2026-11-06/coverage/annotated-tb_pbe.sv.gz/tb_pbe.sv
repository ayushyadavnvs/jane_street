//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // End-to-end test of tt_um_pbe through its real pins only.
        //
        //  Test 1  UART: engine 0 runs uart_tx on pin 0, engine 1 runs uart_rx on pin 1,
        //          pin 0 is looped back to pin 1. An independent UART monitor also decodes pin 0.
        //  Test 2  SPI:  engine 0 runs spi_ctrl on pins 0..3 against a behavioural mode-0 peripheral.
        //
        // Every pin has a pull-up and lines are wired-AND, like a real open-drain bus.
        module tb_pbe;
          localparam real CLK_NS = 20.8333;  // 48 MHz, the planned clock
          localparam int HOST_HALF = 8;  // host SCK half period in clocks (SCK = clk / 16)
          localparam int UART_BIT = 100;  // clocks per UART bit (500 kbaud at 50 MHz)
        
~16622013   logic clk = 0, rst_n = 0;
 33244026   always #(CLK_NS / 2) clk = ~clk;
        
~916480   logic [7:0] ui_in = 8'b0000_0010;  // CS_n high
~154783   wire  [7:0] uo_out, uio_out, uio_oe;
~000922   logic [7:0] ext_drive = '0, ext_val = '0;
 000001   logic       loop01 = 0;
        
~004345   wire  [7:0] chip_lvl = ~uio_oe | uio_out;  // released pins float high
~000923   wire  [7:0] ext_lvl  = ~ext_drive | ext_val;
~000447   wire  [7:0] dev_pull;                       // 1-Wire device models pulling low
~004345   wire  [7:0] bus      = chip_lvl & ext_lvl & ~dev_pull & (loop01 ? {6'h3f, chip_lvl[0], 1'b1} : 8'hff);
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in(bus), .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
        
          // Verification-only scalar pins and phase markers; disabled for normal tests.
        `ifdef PBE_SIGROK
          integer sigrok_phase = 0;
          wire p0 = bus[0], p1 = bus[1], p2 = bus[2], p3 = bus[3];
          wire p4 = bus[4], p5 = bus[5], p6 = bus[6], p7 = bus[7];
          initial begin
            $dumpfile("tb_pbe_pins.vcd");
            $dumpvars(0, p0, p1, p2, p3, p4, p5, p6, p7, sigrok_phase);
          end
        `endif
        
          `include "tb_host.svh"
        
          // ---------------- independent UART monitor on pin 0 ----------------
          logic [7:0] uart_seen[$];
 000002   bit uart_mon_en = 0;
%000000   initial begin
 000273     forever begin
 000273       @(negedge bus[0]);
 000263       if (uart_mon_en) begin
 000010         logic [7:0] b;
 000500         repeat (UART_BIT / 2) @(posedge clk);
 000010         check(bus[0] == 0, "UART monitor: start bit not low at its middle");
 000080         for (int i = 0; i < 8; i++) begin
 008000           repeat (UART_BIT) @(posedge clk);
 000080           b[i] = bus[0];
                end
 001000         repeat (UART_BIT) @(posedge clk);
 000010         check(bus[0] == 1, "UART monitor: stop bit not high");
 000010         uart_seen.push_back(b);
              end
            end
          end
        
          // ---------------- behavioural SPI peripheral, mode 0, pins 0..3 ----------------
          logic [7:0] spi_reply[$], spi_got[$];
 000001   bit spi_dev_en = 0;
 000008   logic [7:0] dev_tx, dev_rx;
          int dev_bits;
 000004   bit dev_loaded = 0;  // dev_tx holds the next reply byte
 000004   function automatic logic [7:0] next_reply();
 000004     return spi_reply.size() ? spi_reply.pop_front() : 8'hEE;
          endfunction
~000003   always @(negedge bus[3]) if (spi_dev_en) begin
~000003     if (!dev_loaded) dev_tx = next_reply();
 000003     dev_loaded = 1;
 000003     dev_bits = 0;
 000003     ext_drive[2] = 1;
 000003     ext_val[2] = dev_tx[7];
          end
 000004   always @(posedge bus[3]) if (spi_dev_en) ext_drive[2] = 0;
 000287   always @(posedge bus[0]) if (spi_dev_en && !bus[3]) begin
 000024     dev_rx = {dev_rx[6:0], bus[1]};
 000024     dev_bits++;
 000021     if (dev_bits == 8) begin
 000003       spi_got.push_back(dev_rx);
 000003       dev_bits = 0;
 000003       dev_loaded = 0;
            end
          end
 000286   always @(negedge bus[0]) if (spi_dev_en && !bus[3]) begin
 000021     if (dev_bits == 0) begin
 000003       dev_tx = next_reply();
 000003       dev_loaded = 1;
 000021     end else dev_tx = {dev_tx[6:0], 1'b0};
 000024     ext_val[2] = dev_tx[7];
          end
        
        
          // ---------------- behavioural I2C peripheral at 0x50, SDA = pin 4, SCL = pin 5 ----------------
          // Register device: write [reg] [data...] stores bytes; reads return bytes from the pointer.
          // It holds SCL low for I2C_STRETCH clocks after bit 4 and bit 8 of every byte (clock stretching).
          // SMBus PEC (i_pec_mode): it keeps its own CRC-8 (poly 0x07) over every byte since the last
          // STOP, in both directions, and sends it as the third byte of a read (i_pec_corrupt flips a bit).
          localparam int SDA = 4, SCL = 5, I2C_STRETCH = 120;
          localparam logic [6:0] I2C_ADDR = 7'h50;
          localparam int I_IDLE = 0, I_ADDR = 1, I_REG = 2, I_WDATA = 3, I_RDATA = 4;
          logic [7:0] i2c_mem[256];
~000741   logic [7:0] i_ptr, i_sh;
 000001   int i_st = I_IDLE, i_bit = 0, i_starts = 0, i_stops = 0, i_stretches = 0;
 000065   bit i2c_en = 0, i_acking = 0;
~000001   bit i_pec_mode = 0, i_pec_corrupt = 0;
 000199   logic [7:0] i_pec = 0, i_pec_at_stop = 0;
 000001   int i_rd_count = 0;
        
          // CRC-8 as SMBus defines it: poly x^8 + x^2 + x + 1, init 0, MSB first, no final XOR
 000474   function automatic logic [7:0] crc8(input logic [7:0] crc, input logic [7:0] b);
 000474     crc ^= b;
 003792     for (int i = 0; i < 8; i++) crc = crc[7] ? {crc[6:0], 1'b0} ^ 8'h07 : {crc[6:0], 1'b0};
 000474     return crc;
          endfunction
        
 000922   bit scl_stretched = 0, scl_after_stretch = 0;  // declared before the peripheral model uses it (BUG-037)
        
 001346   task automatic i_sda(input bit v);  // open drain: 0 pulls low, 1 releases
 001346     ext_drive[SDA] = !v;
 001346     ext_val[SDA] = 0;
          endtask
        
~001389   always @(negedge bus[SDA]) if (i2c_en && bus[SCL]) begin  // START
 000195     i_st = I_ADDR;
 000195     i_bit = 0;
 000195     i_rd_count = 0;
 000195     i_starts++;
          end
 001390   always @(posedge bus[SDA]) if (i2c_en && bus[SCL]) begin  // STOP
 000130     i_st = I_IDLE;
 000130     i_pec_at_stop = i_pec;  // 0 when the message ended in its correct PEC
 000130     i_pec = 0;
 000130     i_stops++;
          end
 004345   always @(posedge bus[SCL]) if (i2c_en && i_st != I_IDLE) begin
 004277     i_bit++;
 003257     if (i_bit <= 8 && i_st != I_RDATA) i_sh = {i_sh[6:0], bus[SDA]};
~004212     if (i_bit == 9 && i_st == I_RDATA && bus[SDA]) i_st = I_IDLE;  // controller NACKed: stop sending
          end
~004344   always @(negedge bus[SCL]) if (i2c_en && i_st != I_IDLE) begin
 000461     if (i_bit == 8) begin
 000461       i_pec = crc8(i_pec, i_sh);  // the byte just sent or received
 000461       i_acking = 1;
 000461       case (i_st)
 000195         I_ADDR:  if (i_sh[7:1] == I2C_ADDR) i_st = i_sh[0] ? I_RDATA : I_REG;
 000001                  else begin i_st = I_IDLE; i_acking = 0; end
 000129         I_REG:   begin i_ptr = i_sh; i_st = I_WDATA; end
 000067         I_WDATA: begin i2c_mem[i_ptr] = i_sh; i_ptr++; end
 000070         default: i_acking = 0;  // sending: the controller drives the ACK slot
              endcase
 000461       i_sda(!i_acking);
 000395     end else if (i_bit == 9) begin
 000395       i_bit = 0;
 000325       if (i_st == I_RDATA) begin
 000068         if (i_pec_mode && i_rd_count == 2) i_sh = i_pec ^ {7'b0, i_pec_corrupt};
 000068         else begin
 000068           i_sh = i2c_mem[i_ptr];
 000068           i_ptr++;
                end
 000070         i_rd_count++;
 000070         i_sda(i_sh[7]);
 000325       end else i_sda(1);
 002932     end else if (i_st == I_RDATA && i_bit >= 1) begin
 000490       i_sda(i_sh[7 - i_bit]);
            end
            // clock stretching mid-byte and before the ACK slot: keep SCL low a while
 003356     if (i_bit == 4 || i_bit == 8) begin
 000922       ext_drive[SCL] = 1;
 000922       ext_val[SCL] = 0;
 000922       i_stretches++;
 000922       scl_stretched = 1;
 110640       repeat (I2C_STRETCH) @(posedge clk);
 000922       ext_drive[SCL] = 0;
            end
          end
          // a read starts right after the address ACK: first bit goes out when that ACK clock ends
~004344   always @(negedge bus[SCL]) if (i2c_en && i_st == I_RDATA && i_bit == 0 && i_acking) begin
 000065     i_acking = 0;
          end
        
          // SCL timing against I2C fast mode: low >= 1.3 us, high >= 0.6 us, period >= 2.5 us (BUG-010)
          // The period check skips the cycle right after a stretch: the controller times that high
          // phase from when it sees SCL rise, which the spec allows (only low/high minimums apply).
 000001   realtime scl_fell = 0, scl_rose = 0, scl_min_low = 1e9, scl_min_high = 1e9, scl_min_period = 1e9;
 004345   always @(posedge bus[SCL]) if (i2c_en) begin
 004341     if (scl_fell > 0 && $realtime - scl_fell < scl_min_low) scl_min_low = $realtime - scl_fell;
 004341     if (scl_rose > 0 && !scl_after_stretch && $realtime - scl_rose < scl_min_period)
 000003       scl_min_period = $realtime - scl_rose;
 004344     scl_after_stretch = scl_stretched;
 004344     scl_stretched = 0;
 004344     scl_rose = $realtime;
          end
~004344   always @(negedge bus[SCL]) if (i2c_en) begin
 004340     if (scl_rose > 0 && $realtime - scl_rose < scl_min_high) scl_min_high = $realtime - scl_rose;
 004344     scl_fell = $realtime;
          end
        
          // FLAG1 must clear only once the STOP is on the bus (BUG-011). This monitor looks inside the
          // design (the flags register), so it runs on the RTL only, not on the gate-level netlist.
        `ifndef GL_TEST
 000132   wire i2c_stop_flag = dut.flags[fphys(1, 1)];  // engine 1's FLAG1
 000132   always @(negedge i2c_stop_flag) if (i2c_en)
~000130     check(bus[SDA] && bus[SCL], "I2C: FLAG1 (STOP) cleared before the STOP finished");
        `endif
        
          // host-side helpers for the i2c_ctrl program on engine 1
          // FLAG0 = START: happens when the next byte is queued.
          // FLAG1 = STOP: happens right away; wait until the engine clears the flag.
 000325   task automatic i2c_cond(input logic [3:0] flag);
 000325     bit b;
 000325     wait_tx_empty(1);
 000195     if (flag[0]) flag_set(1, 0);
 000195     if (flag[1]) begin
 000130       flag_set(1, 1);
 000137       do flag_get(1, 1, b); while (b);
            end
          endtask
 000461   task automatic i2c_xfer(input logic [7:0] data, input logic [7:0] ack_out,
 000461                           output logic [7:0] seen, output logic [7:0] ack_in);
 000461     fifo_send(1, data);
 000461     fifo_send(1, ack_out);
 000461     fifo_recv(1, seen);
 000461     fifo_recv(1, ack_in);
          endtask
        
        
          // ---------------- 1-Wire: two DS18B20-style devices on pin 6 ----------------
          localparam int OW = 6;
          localparam logic [63:0] ROM_A = 64'h2C000800003C5A28;  // family 28, valid CRC8
          localparam logic [63:0] ROM_B = 64'h1B000800003C5B28;
          localparam logic [71:0] OW_SP = 72'h1C100CFF7F464B0550;  // DS18B20 power-up scratchpad, CRC 1C
 000002   bit ow_en_a = 0, ow_en_b = 0, ow_mon = 0;
 000247   wire ow_pull_a, ow_pull_b;
          localparam logic [71:0] OW_SP_25C = 72'h70100CFF7F464B0191;  // after CONVERT T: 25.0625 C, CRC 70
          localparam logic [79:0] OW_BLK = 80'hB41E8877665544332211;   // 8 bytes + inverted CRC-16 (1E B4)
 16481332   wire ow_strong = uio_oe[OW] && uio_out[OW];                   // chip drives DQ hard high
          ow_device #(.ROM(ROM_A), .SP(OW_SP), .SP_CONV(OW_SP_25C), .BLK(OW_BLK)) u_ow_a
              (.dq(bus[OW]), .enable(ow_en_a), .hard_hi(ow_strong), .pull(ow_pull_a));
          ow_device #(.ROM(ROM_B), .SP(OW_SP), .SP_CONV(OW_SP_25C), .BLK(OW_BLK)) u_ow_b
              (.dq(bus[OW]), .enable(ow_en_b), .hard_hi(ow_strong), .pull(ow_pull_b));
 31903321   wire ow_pull_any = ow_pull_a | ow_pull_b;
 000001   realtime ow_last_rise = 0, ow_spu_on = 0;  // DQ's last rising edge; when the strong pull-up began
 001568   always @(posedge bus[OW]) ow_last_rise = $realtime;
 000002   always @(posedge ow_strong) ow_spu_on = $realtime;
        
          // Slot timing: every low pulse the controller makes on its own must be a write-1/read pulse
          // (1-15 us), a write-0 pulse (60-120 us) or a reset (>= 480 us); recovery >= 1 us.
 000001   realtime ow_fell = 0, ow_rose = 0;
 000358   bit ow_touched = 0;
 000001   int ow_short = 0, ow_long = 0, ow_resets = 0, ow_bad = 0;
 000447   always @(posedge ow_pull_any) ow_touched = 1;
 001567   always @(negedge bus[OW]) if (ow_mon) begin
~001039     if (ow_rose > 0 && $realtime - ow_rose < 1000) begin
%000000       ow_bad++;
%000000       check(0, $sformatf("1-Wire: recovery %0.0f ns, needs 1 us", $realtime - ow_rose));
            end
 001039     ow_fell = $realtime;
          end
 001568   always @(posedge bus[OW]) if (ow_mon) begin
~001039     if (!ow_touched) begin
 000404       if ($realtime - ow_fell >= 1000 && $realtime - ow_fell <= 15000) ow_short++;
 000270       else if ($realtime - ow_fell >= 60000 && $realtime - ow_fell <= 120000) ow_long++;
~000007       else if ($realtime - ow_fell >= 480000) ow_resets++;
%000000       else begin
%000000         ow_bad++;
%000000         check(0, $sformatf("1-Wire: controller low pulse of %0.0f ns", $realtime - ow_fell));
              end
            end
 001039     ow_touched = 0;
 001039     ow_rose = $realtime;
          end
        
          // Host side of the onewire_ctrl program on engine 1 (static tasks: see BUG-006).
~000301   logic [7:0] ow_tx, ow_r, ow_f, ow_crc, ow_byte;
 000001   int ow_e = 1;  // engine running the 1-Wire program
 000012   bit ow_fb;
          logic [7:0] ow_buf[$];
~000288   bit ow_present, ow_b;
          int ow_i, ow_j;
 000011   task ow_reset;
 000011     wait_tx_empty(ow_e);
 000011     flag_set(ow_e, 0);        // FLAG0: reset/presence
 001539     do flag_get(ow_e, 0, ow_fb); while (ow_fb);
 000011     fifo_recv(ow_e, ow_r);
 000011     ow_present = (ow_r == 8'h00);
          endtask
 000072   task ow_xbyte;  // send ow_tx as 8 slots; the byte seen comes back in ow_r
 000072     fifo_send(ow_e, ow_tx);
 000072     fifo_recv(ow_e, ow_r);
          endtask
 000768   task ow_xbit;   // single-slot mode: send bit 0 of ow_tx, the bit seen comes back in ow_b
 000768     fifo_send(ow_e, ow_tx);
 000768     fifo_recv(ow_e, ow_r);
 000768     ow_b = ow_r[7];
          endtask
 000004   task ow_read_bytes;  // read ow_i bytes into ow_buf
 000004     ow_buf.delete();
 000033     for (ow_j = ow_i; ow_j > 0; ow_j--) begin
 000033       ow_tx = 8'hFF;
 000033       ow_xbyte;
 000033       ow_buf.push_back(ow_r);
            end
          endtask
 000003   task ow_crc8;   // Dallas CRC8 over ow_buf; 0 when the block ends in its correct CRC
 000003     ow_crc = 0;
 000025     for (ow_i = 0; ow_i < ow_buf.size(); ow_i++) begin
 000025       ow_byte = ow_buf[ow_i];
 000200       for (ow_j = 0; ow_j < 8; ow_j++) begin
~000112         if ((ow_crc ^ ow_byte) & 8'h01) ow_crc = (ow_crc >> 1) ^ 8'h8C;
 000110         else ow_crc = ow_crc >> 1;
 000200         ow_byte = ow_byte >> 1;
              end
            end
          endtask
        
          // Search ROM, the algorithm from Maxim application note 187, run by the host bit by bit.
~000002   logic [63:0] s_rom;
 000001   int s_last_disc = 0, s_last_zero, s_i;
 000037   bit s_done = 0, s_ok, s_id, s_cmp, s_dir;
 000004   task ow_search_next;  // s_ok = a device was found, its ROM in s_rom
 000004     s_ok = 0;
~000004     if (!s_done) begin
 000004       ow_reset;
~000004       if (ow_present) begin
 000004         ow_tx = 8'hF0;
 000004         ow_xbyte;
 000004         wait_tx_empty(ow_e);
 000004         flag_set(ow_e, 1);        // FLAG1: single-slot mode
 000004         s_last_zero = 0;
 000004         s_ok = 1;
 000256         for (s_i = 1; s_i <= 64; s_i++) begin
~000256           if (s_ok) begin
 000256             ow_tx = 8'h01; ow_xbit; s_id = ow_b;   // the bit
 000256             ow_tx = 8'h01; ow_xbit; s_cmp = ow_b;  // its complement
~000256             if (s_id && s_cmp) s_ok = 0;            // nobody answered
 000256             else begin
 000252               if (s_id != s_cmp) s_dir = s_id;
 000004               else begin                            // discrepancy: devices differ here
~000004                 if (s_i < s_last_disc) s_dir = s_rom[s_i-1];
 000004                 else s_dir = (s_i == s_last_disc);
 000002                 if (!s_dir) s_last_zero = s_i;
                      end
 000256               s_rom[s_i-1] = s_dir;
 000256               ow_tx = {7'b0, s_dir};
 000256               ow_xbit;                              // devices that differ drop out
                    end
                  end
                end
 000004         wait_tx_empty(ow_e);
 000004         flag_clear(ow_e, 1);      // back to byte mode
 000004         s_last_disc = s_last_zero;
 000002         if (s_last_disc == 0) s_done = 1;
              end
            end
          endtask
        
          // ---------------- Modbus RTU device (RS-485) on pins 0 (master TX), 1 (master RX), 2 (DE) ----------------
          // Independent of the RTL: it samples at exactly 19200 baud, checks even parity, stop bits,
          // that DE is on during every character and off before it answers, and the gaps between
          // characters, then answers with mb_resp (parity flipped on byte mb_bad, if set).
 000001   real MB_BIT = 1.0e9 / 19200.0;  // ns
 000001   bit mb_en = 0;
 000002   bit mb_npar = 0;  // 8N2: no parity bit, a second stop bit instead
 000001   int mb_gap_at = -1;     // the response pauses before this byte...
 000001   real mb_gap_chars = 0;  // ...for this many character times (11 bits)
 000001   int mb_bad = -1, mb_frames = 0, mb_par_err = 0, mb_stop_err = 0, mb_de_err = 0, mb_k, mb_m;
 000001   real mb_max_gap = 0;
          // If >= 0: the response's first start bit begins this many ns after the master turned its
          // driver off (instead of 1 bit after 3.5 characters of silence), to place it exactly
          // against the program's idle timeouts (BUG-100).
 000001   real mb_resp_at = -1;
 000001   realtime mb_t_end, mb_de_off = 0, mb_rsp_start = 0;
 000038   always @(negedge bus[2]) if (mb_en) mb_de_off = $realtime;
          logic [7:0] mb_req_got[$], mb_resp[$];
~000068   logic [7:0] mb_c, mb_o;
~000017   bit mb_p, mb_s, mb_more, mb_first;
~000017   initial forever begin
~000017     wait (mb_en && !bus[0]);  // start bit of a request
 000017     #(MB_BIT / 4);
~000017     if (!bus[0]) begin        // still low: a real start bit, not a glitch (BUG-014)
 000017     mb_req_got.delete();
 000017     mb_more = 1;
 000017     mb_first = 1;
 000136     while (mb_more) begin
~000136       #(mb_first ? MB_BIT * 1.25 : MB_BIT * 1.5);
 000136       mb_first = 0;
 001088       for (mb_k = 0; mb_k < 8; mb_k++) begin
 001088         mb_c[mb_k] = bus[0];
~001088         if (!bus[2]) mb_de_err++;
 001088         #(MB_BIT);
              end
 000136       mb_p = bus[0];
 000136       #(MB_BIT);
 000136       mb_s = bus[0];
~000136       if (mb_npar ? !mb_p : ^{mb_c, mb_p}) mb_par_err++;
~000136       if (!mb_s) mb_stop_err++;
 000136       mb_req_got.push_back(mb_c);
 000136       mb_t_end = $realtime + MB_BIT / 2;
 011847       while (bus[0] && $realtime - mb_t_end < 3.5 * 11 * MB_BIT) #(MB_BIT / 16);
 000119       if (!bus[0]) begin
 000083         if ($realtime - mb_t_end > mb_max_gap) mb_max_gap = $realtime - mb_t_end;
 000017       end else mb_more = 0;
            end
 000017     mb_frames++;
~000017     if (bus[2]) mb_de_err++;  // the master must have turned its driver off by now
 000017     ext_drive[1] = 1;
 000017     ext_val[1] = 1;
 000010     if (mb_resp_at >= 0 && mb_de_off + mb_resp_at > $realtime) #(mb_de_off + mb_resp_at - $realtime);
 000010     else #(MB_BIT);
 000153     for (mb_m = 0; mb_m < mb_resp.size(); mb_m++) begin
 000153       mb_o = mb_resp[mb_m];
 000149       if (mb_m == mb_gap_at) #(mb_gap_chars * 11 * MB_BIT);  // a pause inside the frame
 000136       if (mb_m == 0) mb_rsp_start = $realtime;
 000153       ext_val[1] = 0;  // start
 000153       #(MB_BIT);
 001224       for (mb_k = 0; mb_k < 8; mb_k++) begin
 001224         ext_val[1] = mb_o[mb_k];
 001224         #(MB_BIT);
              end
 000153       ext_val[1] = mb_npar ? 1'b1 : ^mb_o ^ (mb_m == mb_bad);  // even parity (optionally wrong) or stop
 000153       #(MB_BIT);
 000153       ext_val[1] = 1;  // stop
 000153       #(MB_BIT);
            end
 000017     ext_drive[1] = 0;
            end
          end
        
          // Any low pulse on the master's TX line shorter than half a bit is a glitch (BUG-013).
 000001   realtime mb_fell = 0;
 000001   int mb_glitches = 0;
 000286   always @(negedge bus[0]) if (mb_en) mb_fell = $realtime;
~000287   always @(posedge bus[0]) if (mb_en && $realtime - mb_fell < MB_BIT / 2) mb_glitches++;
        
          // Host side of the modbus_rtu program on engine 0.
          logic [7:0] mb_rx[$], mb_par[$], mb_buf[$];
~000136   logic [7:0] mb_f, mb_st, mb_d, mb_x, mb_b;
%000000   logic [15:0] mb_crc;
 000017   bit mb_fdone, mb_fb;
          int mb_i, mb_j, mb_perr;  // mb_i/mb_j belong to the tasks; static tasks share variables
%000000   task mb_crc16;  // Modbus CRC over mb_buf -> mb_crc ({high byte, low byte}; low byte is sent first)
%000000     mb_crc = 16'hFFFF;
%000000     for (mb_i = 0; mb_i < mb_buf.size(); mb_i++) begin
%000000       mb_b = mb_buf[mb_i];
%000000       mb_crc = mb_crc ^ {8'h00, mb_b};
%000000       for (mb_j = 0; mb_j < 8; mb_j++)
%000000         if (mb_crc[0]) mb_crc = (mb_crc >> 1) ^ 16'hA001;
%000000         else mb_crc = mb_crc >> 1;
            end
          endtask
 000017   task mb_send;  // send mb_buf without its last 2 bytes: the engine adds parity and the CRC
 000102     for (mb_i = 0; mb_i < mb_buf.size() - 2; mb_i++) begin
 000102       mb_b = mb_buf[mb_i];
 000102       fifo_send(0, mb_b);
            end
 000017     wait_tx_empty(0);
 000017     flag_set(0, 1);                  // FLAG1: request complete
 003472     do flag_get(0, 1, mb_fb); while (mb_fb);
          endtask
          int mb_div, mb_tmo;
 000001   real mb_baud = 19200.0;
 000017   task mb_config;  // engine 0 for Modbus at mb_baud: tick = 1/8 bit, CRC, parity, timeout
 000017     mb_div = $rtoi(1.0e9 / mb_baud / 8.0 / CLK_NS + 0.5) - 1;
            // 1.5 characters of silence (the program then watches 2 more for the frame end, BUG-039);
            // +9 ticks because the program starts waiting 9 ticks before the stop bit ends
 000017     mb_tmo = 1.5 * 11 * 8 + 9;
 000017     reg_write(7'h00, 8'b0000_0000);    // stop E0
 000017     reg_write(7'h10, mb_div[7:0]);
 000017     reg_write(7'h11, mb_div[15:8]);
 000017     reg_write(7'h1C, mb_tmo[7:0]);     // TIMEOUT
 000017     reg_write(7'h1D, mb_tmo[15:8]);
 000017     MB_BIT = 1.0e9 / mb_baud;          // the device model follows
 000017     reg_write(7'h00, 8'b0001_0001);    // restart + run E0
          endtask
 000016   task mb_receive;  // collect one response frame into mb_rx / mb_par
 000016     mb_rx.delete();
 000016     mb_par.delete();
 000016     mb_fdone = 0;
 008989     while (!mb_fdone) begin
 008989       flag_get(0, 2, mb_fdone);  // read the flag first, so every byte before it gets drained
 008989       reg_read(7'h01, mb_st);
~000134       while (!mb_st[0]) begin
 000134         fifo_recv(0, mb_d);
 000134         fifo_recv(0, mb_x);
 000134         mb_rx.push_back(mb_d);
 000134         mb_par.push_back(mb_x);
 000134         reg_read(7'h01, mb_st);
              end
            end
          endtask
          assign dev_pull = {1'b0, ow_pull_any, 6'b0};
        
          // state for the two-protocol test
~000001   logic [63:0] conc_rom;
~000186   logic [7:0] conc_v, conc_seen, conc_ack;
~000001   bit conc_ow_done = 0, conc_i2c_busy = 0;
 000001   int conc_rounds = 0, conc_overlap = 0;
~001567   always @(negedge bus[OW]) if (conc_i2c_busy && !conc_ow_done) conc_overlap++;
        
        
        `ifdef PBE_PROTOCOL_REFERENCE
          `include "modbus_reference.svh"
        `endif
        
          // ---------------- tests ----------------
 000001   initial begin
 000001     logic [7:0] sent[$], got;
        `ifndef PBE_SIGROK
~000001     if ($test$plusargs("vcd")) begin  // waveforms on request: vvp sim.vvp +vcd
%000000       $dumpfile("tb_pbe.vcd");
%000000       $dumpvars(0, tb_pbe);
            end
        `endif
        
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
        
        `ifdef PBE_PROTOCOL_REFERENCE
            modbus_reference;
            $finish;
        `endif
        
            // register readback sanity check
 000001     reg_write(7'h10, 8'hA5);
 000001     reg_read(7'h10, got);
 000001     check(got == 8'hA5, $sformatf("CLKDIV_L readback %02x", got));
        
            // ===== Test 0: NOP has no side effects (BUG-008) =====
        `ifdef PBE_SIGROK
            sigrok_phase = 0;
        `endif
 000001     $display("Test 0: NOP has no side effects");
 000001     load_program("nop_image.hex");
 000001     reg_write(7'h10, 0);
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 2);                 // pins 2, 3: a USB pair in v2
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h00, 8'b0001_0001);      // restart + run E0
 000300     repeat (300) @(posedge clk);
 000001     check(uio_oe == 8'h00, $sformatf("NOP drove pins: uio_oe = %08b", uio_oe));
 000001     reg_read(7'h04, got);                // the flags, through the host port
~000001     check(got == '0 && !uo_out[1], "NOP changed flags or raised IRQ");
 000001     reg_write(7'h00, 8'b0000_0000);
        
            // ===== Test 1: UART loopback =====
        `ifdef PBE_SIGROK
            sigrok_phase = 1;
        `endif
 000001     $display("Test 1: UART TX (engine 0) looped back into UART RX (engine 1)");
 000001     load_program("uart_image.hex");
 000001     reg_write(7'h10, UART_BIT / 2 - 1);  // E0 tick = 1/2 bit
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);                 // E0 pins start at 0
 000001     reg_write(7'h14, 2'b00);             // LSB first
 000001     reg_write(7'h15, 0);                 // start at word 0
 000001     reg_write(7'h20, UART_BIT / 4 - 1);  // E1 tick = 1/4 bit
 000001     reg_write(7'h21, 0);
 000001     reg_write(7'h22, 1);                 // E1 pins start at 1
 000001     reg_write(7'h23, 0);                 // JMP pin = rx
 000001     reg_write(7'h24, 2'b00);
 000001     reg_write(7'h25, 8);                 // start at word 8
 000001     reg_write(7'h03, 8'b0000_0010);      // pin 1 belongs to E1
 000001     loop01 = 1;
 000001     uart_mon_en = 1;
 000001     reg_write(7'h00, 8'b0011_0011);      // restart + run both
        
 000001     sent = '{8'h55, 8'hA3, 8'h00, 8'hFF, 8'h0F, 8'h80};
            // one host port, so sends and receives take turns; keep up to 4 bytes queued
 000004     for (int i = 0; i < 4; i++) fifo_send(0, sent[i]);
~000006     foreach (sent[i]) begin
 000006       fifo_recv(1, got);
 000006       check(got === sent[i], $sformatf("UART RX byte %0d: got %02x, sent %02x", i, got, sent[i]));
 000004       if (i + 4 < sent.size()) fifo_send(0, sent[i+4]);
            end
 000200     repeat (2 * UART_BIT) @(posedge clk);
 000001     check(uart_seen.size() == sent.size(), $sformatf("UART monitor saw %0d bytes", uart_seen.size()));
~000006     foreach (uart_seen[i])
 000006       check(uart_seen[i] === sent[i], $sformatf("UART monitor byte %0d: %02x", i, uart_seen[i]));
 000001     $display("  sent %0d bytes, engine 1 and the monitor received them", sent.size());
        
            // ===== Test 2: SPI controller =====
        `ifdef PBE_SIGROK
            sigrok_phase = 2;
        `endif
 000001     $display("Test 2: SPI controller (engine 0) against a mode-0 peripheral");
 000001     reg_write(7'h00, 8'b1100_0000);      // stop both, flush FIFOs
 000001     uart_mon_en = 0;
 000001     loop01 = 0;
 000001     load_program("spi_image.hex");
 000001     reg_write(7'h03, 8'h00);
 000001     reg_write(7'h10, 3);                 // tick = 4 clocks
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h14, 2'b11);             // MSB first both ways
 000001     reg_write(7'h15, 0);
 000001     spi_reply = '{8'h3C, 8'hC3, 8'h81};
 000001     spi_dev_en = 1;
 000001     reg_write(7'h00, 8'b0001_0001);      // restart + run E0
 000050     repeat (50) @(posedge clk);
~000001     check(bus[3] == 1 && bus[0] == 0, "SPI idle: CS_n high, SCLK low");
        
 000001     sent = '{8'hA5, 8'h5A, 8'h7E};
~000003     foreach (sent[i]) fifo_send(0, sent[i]);
~000003     foreach (sent[i]) begin
 000003       fifo_recv(0, got);
 000003       check(got === (i == 0 ? 8'h3C : i == 1 ? 8'hC3 : 8'h81),
 000003             $sformatf("SPI read byte %0d: got %02x", i, got));
            end
 000100     repeat (100) @(posedge clk);
 000001     check(bus[3] == 1, "SPI: CS_n released at the end");
 000001     check(spi_got.size() == 3, $sformatf("SPI peripheral got %0d bytes", spi_got.size()));
~000003     foreach (spi_got[i])
 000003       check(spi_got[i] === sent[i], $sformatf("SPI peripheral byte %0d: %02x, expected %02x", i, spi_got[i], sent[i]));
 000001     $display("  exchanged %0d bytes in both directions", spi_got.size());
        
            // ===== Test 3: I2C on engine 1 while engine 0 sends UART =====
        `ifdef PBE_SIGROK
            sigrok_phase = 3;
        `endif
 000001     $display("Test 3: I2C controller (engine 1, pins 4-5) running alongside UART TX (engine 0)");
 000001     reg_write(7'h00, 8'b1100_0000);      // stop both, flush FIFOs
 000001     spi_dev_en = 0;
 000001     ext_drive = '0;
 000001     load_program("mixed_image.hex");
 000001     reg_write(7'h03, 8'b0011_0000);      // pins 4, 5 belong to E1
 000001     reg_write(7'h10, UART_BIT / 2 - 1);  // E0: UART TX as in test 1
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h14, 2'b00);
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h20, 17);                // E1 tick = 18 clocks, SCL = 7 ticks: I2C fast mode (<= 400 kHz)
 000001     reg_write(7'h21, 0);
 000001     reg_write(7'h22, 4);                 // E1 pins start at 4
 000001     reg_write(7'h24, 2'b11);             // MSB first
 000001     reg_write(7'h25, 8);                 // i2c_ctrl at word 8
 000001     uart_seen.delete();
 000001     uart_mon_en = 1;
 000001     i2c_en = 1;
 000001     reg_write(7'h00, 8'b0011_0011);      // restart + run both
        
 000001     sent = '{8'hC3, 8'h3C, 8'h99, 8'h66};
~000004     foreach (sent[i]) fifo_send(0, sent[i]);  // UART keeps running during the I2C traffic
        
 000001     begin
 000001       logic [7:0] seen, ack;
              // write 0xDE, 0xAD to registers 0x10, 0x11
 000001       i2c_cond(1);
 000001       i2c_xfer(8'hA0, 8'h80, seen, ack); check(ack == 0, "I2C: address+W not ACKed");
 000001       i2c_xfer(8'h10, 8'h80, seen, ack); check(ack == 0, "I2C: register not ACKed");
 000001       i2c_xfer(8'hDE, 8'h80, seen, ack); check(ack == 0, "I2C: data 0 not ACKed");
 000001       i2c_xfer(8'hAD, 8'h80, seen, ack); check(ack == 0, "I2C: data 1 not ACKed");
 000001       i2c_cond(2);
~000001       check(i2c_mem[8'h10] === 8'hDE && i2c_mem[8'h11] === 8'hAD,
 000001             $sformatf("I2C write: peripheral holds %02x %02x", i2c_mem[8'h10], i2c_mem[8'h11]));
        
              // read them back: write the register pointer, repeated START, read 2 bytes
 000001       i2c_cond(1);
 000001       i2c_xfer(8'hA0, 8'h80, seen, ack); check(ack == 0, "I2C: address+W not ACKed (read)");
 000001       i2c_xfer(8'h10, 8'h80, seen, ack); check(ack == 0, "I2C: pointer not ACKed");
 000001       i2c_cond(1);                                                  // repeated START
 000001       i2c_xfer(8'hA1, 8'h80, seen, ack); check(ack == 0, "I2C: address+R not ACKed");
 000001       i2c_xfer(8'hFF, 8'h00, seen, ack); check(seen === 8'hDE, $sformatf("I2C read 0: %02x", seen));
 000001       i2c_xfer(8'hFF, 8'h80, seen, ack); check(seen === 8'hAD, $sformatf("I2C read 1: %02x", seen));
 000001       check(ack == 1, "I2C: last read byte should carry our NACK");
 000001       i2c_cond(2);
        
              // nobody at 0x58: expect a NACK
 000001       i2c_cond(1);
 000001       i2c_xfer(8'hB0, 8'h80, seen, ack); check(ack == 1, "I2C: missing device should NACK");
 000001       i2c_cond(2);
            end
 000050     repeat (50) @(posedge clk);
~000001     check(bus[SDA] && bus[SCL], "I2C: bus not idle (both high) at the end");
~000001     check(i_starts == 4 && i_stops == 3, $sformatf("I2C: saw %0d STARTs, %0d STOPs", i_starts, i_stops));
 000001     check(i_stretches >= 20, $sformatf("I2C: only %0d clock stretches", i_stretches));
 000001     check(scl_min_low >= 1300, $sformatf("I2C: SCL low %0.0f ns, fast mode needs 1300", scl_min_low));
 000001     check(scl_min_high >= 600, $sformatf("I2C: SCL high %0.0f ns, fast mode needs 600", scl_min_high));
 000001     check(scl_min_period >= 2500, $sformatf("I2C: SCL period %0.0f ns, over 400 kHz", scl_min_period));
        
 000001     wait (uart_seen.size() == sent.size() || $time > 15ms);
~000004     foreach (sent[i])
 000004       check(uart_seen[i] === sent[i], $sformatf("UART during I2C: byte %0d %02x", i, uart_seen[i]));
 000001     $display("  I2C write, read with repeated START, and NACK passed with %0d clock stretches;", i_stretches);
 000001     $display("  UART sent %0d bytes at the same time", uart_seen.size());
 000001     $display("  SCL min low %0.0f ns, min high %0.0f ns, min period %0.0f ns", scl_min_low, scl_min_high, scl_min_period);
        
            // $fatal gives a non-zero exit code, so make and CI see the failure (BUG-007)
            // ===== Test 4: 1-Wire =====
        `ifdef PBE_SIGROK
            sigrok_phase = 4;
        `endif
 000001     $display("Test 4: 1-Wire controller (engine 1, pin 6) with two DS18B20-style devices");
 000001     reg_write(7'h00, 8'b1100_0000);      // stop both, flush FIFOs
 000001     uart_mon_en = 0;
 000001     i2c_en = 0;
 000001     loop01 = 0;
 000001     ext_drive = '0;
 000001     reg_write(7'h04, 8'h00);
 000001     reg_write(7'h02, 8'h03);
 000001     load_program("ow_image.hex");
 000001     reg_write(7'h03, 8'b0100_0000);      // pin 6 belongs to E1
 000001     reg_write(7'h20, 8'($rtoi(1000.0 / CLK_NS + 0.5) - 1));  // tick = 1 us
 000001     reg_write(7'h21, 0);
 000001     reg_write(7'h22, OW);
 000001     reg_write(7'h24, 2'b00);             // LSB first
 000001     reg_write(7'h25, 0);
 000001     ow_mon = 1;
 000001     reg_write(7'h00, 8'b0010_0010);      // restart + run E1 only
        
 000001     ow_reset;
~000001     check(!ow_present, "1-Wire: presence reported with no device on the bus");
 000001     ow_en_a = 1;
 000001     ow_reset;
 000001     check(ow_present, "1-Wire: no presence pulse from device A");
 000001     reg_write(7'h29, 8'h31);             // CRC unit: 1-Wire CRC-8, poly 0x31
 000001     reg_write(7'h2A, 8'h00);
 000001     reg_write(7'h2B, 8'hA7);             // 8 bits, init 0, reversed, fed by IN bits only
 000001     ow_tx = 8'h33; ow_xbyte;             // READ ROM (one device only)
 000001     reg_write(7'h2F, 8'h01);             // restart the CRC after the command byte
 000001     ow_i = 8; ow_read_bytes;
 000001     reg_read(7'h2F, ow_f);
 000001     check(ow_f[1], "1-Wire: hardware CRC-8 of the ROM ID not ok");
 000008     for (ow_i = 0; ow_i < 8; ow_i++)
 000008       check(ow_buf[ow_i] === ROM_A[8*ow_i+:8], $sformatf("1-Wire READ ROM byte %0d: %02x", ow_i, ow_buf[ow_i]));
 000001     ow_crc8;
 000001     check(ow_crc == 0, "1-Wire: READ ROM CRC8 failed");
 000001     $display("  presence, absence and READ ROM ok");
        
 000001     ow_en_b = 1;                         // two devices: find both with Search ROM
 000001     s_done = 0;
 000001     s_last_disc = 0;
 000001     ow_search_next;
 000001     check(s_ok, "1-Wire: search found no device");
 000001     ow_buf.delete();
 000008     for (ow_i = 0; ow_i < 8; ow_i++) ow_buf.push_back(s_rom[8*ow_i+:8]);
 000001     ow_crc8;
~000001     check(ow_crc == 0 && (s_rom == ROM_A || s_rom == ROM_B), $sformatf("1-Wire: search 1 found %016x", s_rom));
 000001     ow_tx = 8'hxx;
 000001     begin
 000001       logic [63:0] first;
 000001       first = s_rom;
 000001       ow_search_next;
~000001       check(s_ok && s_done, "1-Wire: search did not find a second device");
~000001       check(s_rom != first && (s_rom == ROM_A || s_rom == ROM_B), $sformatf("1-Wire: search 2 found %016x", s_rom));
 000001       $display("  Search ROM found %016x and %016x", first, s_rom);
            end
        
 000001     ow_reset;                            // MATCH ROM device B, then READ SCRATCHPAD
 000001     ow_tx = 8'h55; ow_xbyte;
 000008     for (ow_j = 0; ow_j < 8; ow_j++) begin
 000008       ow_tx = ROM_B[8*ow_j+:8];
 000008       fifo_send(ow_e, ow_tx);
 000008       fifo_recv(ow_e, ow_r);
            end
 000001     ow_tx = 8'hBE; ow_xbyte;
 000001     reg_write(7'h2F, 8'h01);             // restart the CRC
 000001     ow_i = 8; ow_read_bytes;
 000001     reg_read(7'h2F, ow_f);
~000001     check(!ow_f[1], "1-Wire: hardware CRC ok before the CRC byte was read");
 000001     ow_tx = 8'hFF; ow_xbyte;             // the 9th byte is the CRC
 000001     ow_buf.push_back(ow_r);
 000001     reg_read(7'h2F, ow_f);
 000001     check(ow_f[1], "1-Wire: hardware CRC-8 of the scratchpad not ok");
 000009     for (ow_i = 0; ow_i < 9; ow_i++)
 000009       check(ow_buf[ow_i] === OW_SP[8*ow_i+:8], $sformatf("1-Wire scratchpad byte %0d: %02x", ow_i, ow_buf[ow_i]));
 000001     ow_crc8;
 000001     check(ow_crc == 0, "1-Wire: scratchpad CRC8 failed");
 000001     ow_mon = 0;
~000001     check(ow_bad == 0 && ow_short > 0 && ow_long > 0 && ow_resets >= 5,
 000001           $sformatf("1-Wire timing: %0d bad, %0d short, %0d long, %0d resets", ow_bad, ow_short, ow_long, ow_resets));
 000001     $display("  hardware CRC-8 checked the ROM ID and the scratchpad");
        
            // CONVERT T on parasite-powered device A: strong pull-up right after the command byte
 000001     ow_reset;
 000001     ow_tx = 8'h55; ow_xbyte;
 000008     for (ow_j = 0; ow_j < 8; ow_j++) begin
 000008       ow_tx = ROM_A[8*ow_j+:8];
 000008       ow_xbyte;
            end
 000001     fifo_send(ow_e, 8'h44);              // CONVERT T, queued first...
 000001     flag_set(ow_e, 0);                   // ...then FLAG0: strong pull-up after this byte
 000001     fifo_recv(ow_e, ow_r);
 000001     #(50us);
 000001     check(ow_strong, "1-Wire: DQ not driven high after CONVERT T");
 000001     #(1200us);
 000001     flag_clear(ow_e, 0);                 // conversion time over: pull-up off
 000001     #(20us);
~000001     check(!uio_oe[OW], "1-Wire: DQ still driven after the strong pull-up ended");
~000001     check(u_ow_a.conversions == 1 && u_ow_a.conv_fails == 0,
 000001           $sformatf("1-Wire: %0d conversions, %0d failed", u_ow_a.conversions, u_ow_a.conv_fails));
 000001     ow_reset;                            // read the new temperature
 000001     ow_tx = 8'h55; ow_xbyte;
 000008     for (ow_j = 0; ow_j < 8; ow_j++) begin
 000008       ow_tx = ROM_A[8*ow_j+:8];
 000008       ow_xbyte;
            end
 000001     ow_tx = 8'hBE; ow_xbyte;
 000001     ow_i = 9; ow_read_bytes;
 000009     for (ow_i = 0; ow_i < 9; ow_i++)
 000009       check(ow_buf[ow_i] === OW_SP_25C[8*ow_i+:8], $sformatf("1-Wire converted scratchpad byte %0d: %02x", ow_i, ow_buf[ow_i]));
 000001     $display("  CONVERT T with strong pull-up: device read 25.0625 C");
        
            // CONVERT T while the RX FIFO is full (BUG-038): the strong pull-up must come within 10 us
            // of the last slot, not after the host has made room for the byte's PUSH
 000006     for (ow_j = 0; ow_j < 6; ow_j++) fifo_send(ow_e, 8'hFF);  // 6 read slots, left unread
 000518     do reg_read(7'h0B, ow_f); while (ow_f != 6);
 000001     flag_set(ow_e, 0);                   // reset: its presence byte is left unread too
 000162     do flag_get(ow_e, 0, ow_fb); while (ow_fb);
 000001     ow_tx = 8'h55; fifo_send(ow_e, ow_tx);
 000008     for (ow_j = 0; ow_j < 8; ow_j++) fifo_send(ow_e, ROM_A[8*ow_j+:8]);
 000775     do reg_read(7'h0B, ow_f); while (ow_f != 16);
 000001     reg_read(7'h01, ow_f);
 000001     check(ow_f[5], "1-Wire: RX FIFO not full before CONVERT T");
 000001     ow_spu_on = 0;
 000001     begin
 000001       int conv0;
 000001       conv0 = u_ow_a.conversions;
 000001       fifo_send(ow_e, 8'h44);            // CONVERT T, then FLAG0, with the RX FIFO full
 000001       flag_set(ow_e, 0);
 000001       #(700us);                          // 8 slots and more; the host still reads nothing
 000001       check(ow_spu_on > 0, "1-Wire: no strong pull-up after CONVERT T with the RX FIFO full");
~000001       if (ow_spu_on > 0)
 000001         check(ow_spu_on - ow_last_rise <= 10000,
 000001               $sformatf("1-Wire: strong pull-up %0.1f us after the last slot, needs <= 10 us",
 000001                         (ow_spu_on - ow_last_rise) / 1000.0));
 000017       for (ow_j = 0; ow_j < 17; ow_j++) fifo_recv(ow_e, ow_r);  // 16 waiting and CONVERT T's
 000001       check(ow_r == 8'h44, $sformatf("1-Wire: CONVERT T came back as %02x", ow_r));
 000001       #(1200us);
 000001       flag_clear(ow_e, 0);
 000001       #(20us);
~000001       check(!uio_oe[OW], "1-Wire: DQ still driven after the strong pull-up ended (RX FIFO full)");
~000001       check(u_ow_a.conversions == conv0 + 1 && u_ow_a.conv_fails == 0,
 000001             $sformatf("1-Wire: RX FIFO full: %0d conversions, %0d failed", u_ow_a.conversions - conv0, u_ow_a.conv_fails));
~000001       if (ow_spu_on > 0)
 000001         $display("  CONVERT T with the RX FIFO full: strong pull-up %0.1f us after the last slot",
 000001                  (ow_spu_on - ow_last_rise) / 1000.0);
            end
        
            // Inverted CRC-16 (DS2408/DS2431 style): the host reads the CRC unit's value and compares
 000001     ow_reset;
 000001     ow_tx = 8'h55; ow_xbyte;
 000008     for (ow_j = 0; ow_j < 8; ow_j++) begin
 000008       ow_tx = ROM_B[8*ow_j+:8];
 000008       ow_xbyte;
            end
 000001     ow_tx = 8'hAA; ow_xbyte;
 000001     reg_write(7'h29, 8'h05);             // CRC-16, poly 0x8005, init 0, reversed, fed by IN
 000001     reg_write(7'h2A, 8'h80);
 000001     reg_write(7'h2B, 8'hAF);
 000001     reg_write(7'h2F, 8'h01);             // restart it after the command byte
 000001     ow_i = 8; ow_read_bytes;
 000008     for (ow_i = 0; ow_i < 8; ow_i++)
 000008       check(ow_buf[ow_i] === OW_BLK[8*ow_i+:8], $sformatf("1-Wire block byte %0d: %02x", ow_i, ow_buf[ow_i]));
 000001     reg_read(7'h29, ow_crc);             // the live CRC value (low byte)...
 000001     reg_read(7'h2A, ow_byte);            // ...and high byte
 000001     ow_tx = 8'hFF; ow_xbyte; ow_f = ow_r;
 000001     ow_tx = 8'hFF; ow_xbyte;
 000001     check({ow_byte, ow_crc} == 16'h4BE1, $sformatf("1-Wire: CRC unit value %04x, expected 4be1", {ow_byte, ow_crc}));
~000001     check(ow_f === ~ow_crc && ow_r === ~ow_byte,
 000001           $sformatf("1-Wire: device sent CRC %02x %02x, inverted CRC unit value %02x %02x", ow_f, ow_r, ~ow_crc, ~ow_byte));
 000001     reg_write(7'h2B, 8'h00);             // CRC off again
 000001     $display("  inverted CRC-16 checked by the host against the CRC unit's value");
 000001     $display("  MATCH ROM + READ SCRATCHPAD ok; timing checked on %0d short, %0d long pulses and %0d resets",
 000001              ow_short, ow_long, ow_resets);
 000001     ow_en_a = 0;
 000001     ow_en_b = 0;
        
            // ===== Test 5: Modbus RTU =====
        `ifdef PBE_SIGROK
            sigrok_phase = 5;
        `endif
 000001     $display("Test 5: Modbus RTU master (engine 0, pins 0-2) with an RS-485 device model, 8E1, hardware CRC/parity/timeout");
 000001     reg_write(7'h00, 8'b1100_0000);
 000001     reg_write(7'h04, 8'h00);
 000001     reg_write(7'h02, 8'h03);
 000001     load_program("modbus_image.hex");
 000001     reg_write(7'h03, 8'h00);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h13, 1);                 // JMP pin = rx
 000001     reg_write(7'h14, 2'b00);             // LSB first
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h19, 8'h05);             // CRC_POLY = 0x8005
 000001     reg_write(7'h1A, 8'h80);
 000001     reg_write(7'h1B, 8'hFF);             // CRC_CFG: 16 bits, init ones, reversed, fed by OUT and IN
 000001     reg_write(7'h1E, 8'h01);             // LINE_CFG: timeout jumps to word 1, even parity
 000001     mb_en = 1;
        
            // round 0: normal; 1: response parity error; 2: response CRC corrupted; 3: normal at 115200;
            // 4: 8N2 at 19200; 5, 6: a 2-character pause inside the response at 19200 and 115200 (the
            // frame is invalid, BUG-039); 7, 8: a 1-character pause at 115200 and 19200 (allowed);
            // 9..15: the response's start edge lands just after an idle timeout, while the program runs
            // the timeout routine between two WAITs (BUG-100): 0.1, 1.5 and 2.9 ticks after it at
            // 19200, 0.1 and 2.9 at 115200, 0.1 at 8N2; 15: 0.1 ticks with the device 1% fast (an
            // edge just after the timeout is seen ~3 ticks late, the worst case for sampling, D78)
 000016     for (int round = 0; round < 16; round++) begin
 000016       bit invalid;
 000016       real mb_after;
        `ifdef PBE_SIGROK
              sigrok_phase = 50 + round;  // isolate each baud/parity/error scenario
        `endif
 000016       mb_baud = (round == 3 || round == 6 || round == 7 || round == 12 || round == 13) ? 115200.0 : 19200.0;
 000016       mb_npar = (round == 4 || round == 14);
 000016       reg_write(7'h1E, mb_npar ? 8'h41 : 8'h01);  // LINE_CFG: even parity, or a second stop bit
 000016       mb_config;
              // The idle program times out every TIMEOUT + 3 engine ticks after the driver goes off
              // (WAIT, then tmo and JMP TX_EMPTY before the next WAIT); start just after the third.
 000016       case (round)
 000004         9, 12, 14, 15: mb_after = 0.1;
 000001         10:            mb_after = 1.5;
 000002         11, 13:        mb_after = 2.9;
 000009         default:   mb_after = -1;
              endcase
 000016       mb_resp_at = (mb_after < 0) ? -1 : (3 * (mb_tmo + 3) + mb_after) * (mb_div + 1) * CLK_NS;
 000015       if (round == 15) MB_BIT = MB_BIT / 1.01;  // the device's clock 1% fast
 000016       mb_bad = (round == 1) ? 3 : -1;
 000016       mb_gap_at = (round >= 5 && round <= 8) ? 4 : -1;
 000016       mb_gap_chars = (round == 5 || round == 6) ? 2.0 : 1.0;
 000016       mb_resp = '{8'h01, 8'h03, 8'h04, 8'h12, 8'h34, 8'h56, 8'h78, 8'h81, 8'h07};
 000015       if (round == 2) mb_resp[8] = 8'h06;  // wrong CRC high byte
 000016       mb_buf = '{8'h01, 8'h03, 8'h00, 8'h00, 8'h00, 8'h02, 8'hC4, 8'h0B};  // what must arrive
 000016       mb_max_gap = 0;
 000016       mb_send;
 000016       mb_receive;
 000016       check(uo_out[1], "Modbus: no IRQ at the end of the response");
 000009       if (mb_resp_at >= 0)
~000007         check(mb_rsp_start - mb_de_off >= mb_resp_at - 1.0 && mb_rsp_start - mb_de_off <= mb_resp_at + 1.0,
 000007               $sformatf("Modbus round %0d: response started %0.0f ns after DE off, wanted %0.0f",
 000007                         round, mb_rsp_start - mb_de_off, mb_resp_at));
 000016       mb_resp_at = -1;
 000016       flag_get(0, 3, invalid);             // FLAG3: the frame had a pause of over 1.5 characters
 000016       flag_clear(0, 3);
 000016       flag_clear(0, 2);
 000016       reg_write(7'h02, 8'h03);
 000016       mb_gap_at = -1;
 000016       check(invalid == (round == 5 || round == 6),
 000016             $sformatf("Modbus round %0d: frame reported %0s", round, invalid ? "invalid" : "valid"));
 000014       if (round == 5 || round == 6) begin
 000002         check(mb_rx.size() == 4, $sformatf("Modbus round %0d: %0d bytes before the pause, expected 4", round, mb_rx.size()));
 000002         $display("  round %0d at %0.0f baud: a 2-character pause inside the response: frame %0s",
~000002                  round, mb_baud, invalid ? "reported invalid" : "NOT reported invalid");
 000014       end else begin
 000014         check(mb_req_got.size() == 8, $sformatf("Modbus round %0d: device got %0d request bytes", round, mb_req_got.size()));
 000112         for (mb_i = 0; mb_i < 8 && mb_i < mb_req_got.size(); mb_i++)
 000112           check(mb_req_got[mb_i] === mb_buf[mb_i],
 000112                 $sformatf("Modbus round %0d request byte %0d: %02x, expected %02x", round, mb_i, mb_req_got[mb_i], mb_buf[mb_i]));
 000014         check(mb_rx.size() == mb_resp.size(), $sformatf("Modbus round %0d: host got %0d response bytes", round, mb_rx.size()));
 000014         mb_perr = 0;
 000126         for (mb_i = 0; mb_i < mb_rx.size(); mb_i++) begin
 000126           check(mb_rx[mb_i] === mb_resp[mb_i], $sformatf("Modbus round %0d response byte %0d: %02x", round, mb_i, mb_rx[mb_i]));
 000126           mb_x = mb_par[mb_i];
 000125           if (mb_x[0]) mb_perr++;            // parity errors found by the engine
                end
 000014         check(mb_perr == (round == 1 ? 1 : 0), $sformatf("Modbus round %0d: engine reported %0d parity errors", round, mb_perr));
 000014         mb_x = mb_par[mb_par.size() - 1];  // status after the last character: CRC ok?
 000014         check(mb_x[1] == (round != 2), $sformatf("Modbus round %0d: CRC ok = %b", round, mb_x[1]));
 000014         check(mb_max_gap <= 1.5 * 11 * MB_BIT, $sformatf("Modbus round %0d: %0.0f ns gap inside a request", round, mb_max_gap));
 000014         $display("  round %0d at %0.0f baud %s: request with hardware CRC ok; response %0d parity error(s), CRC ok = %b",
 000014                  round, mb_baud, mb_npar ? "8N2" : "8E1", mb_perr, mb_x[1]);
 000007         if (mb_after >= 0)
 000007           $display("    (its start edge %0.1f ticks after an idle timeout%0s)", mb_after,
 000007                    round == 15 ? ", the device 1% fast" : "");
              end
            end
 000001     mb_npar = 0;
        
            // RX overflow: the host does not read during the response; the engine must report it
 000001     reg_write(7'h1E, 8'h01);             // back to 8E1
 000001     mb_baud = 115200.0;
 000001     mb_config;
 000001     mb_bad = -1;
 000001     mb_resp = '{8'h01, 8'h03, 8'h04, 8'h12, 8'h34, 8'h56, 8'h78, 8'h81, 8'h07};
 000001     mb_send;
~000255     do flag_get(0, 2, mb_fdone); while (!mb_fdone);  // wait for the frame end, reading nothing
 000001     reg_read(7'h1F, mb_st);
 000001     check(mb_st[3], "Modbus: RX overflow not reported in STATUS");
 000001     check(uo_out[1], "Modbus: no IRQ for the RX overflow");
 000001     reg_read(7'h01, mb_st);
 000016     while (!mb_st[0]) begin               // drain whatever arrived
 000016       reg_read(7'h16, mb_d);
 000016       reg_read(7'h01, mb_st);
            end
 000001     reg_write(7'h1F, 8'h04);             // clear the overflow
 000001     reg_read(7'h1F, mb_st);
~000001     check(!mb_st[3], "Modbus: RX overflow did not clear");
 000001     flag_clear(0, 2);
 000001     reg_write(7'h02, 8'h03);
 000001     $display("  RX overflow (host not reading) reported in STATUS and by IRQ");
~000001     check(mb_par_err == 0 && mb_stop_err == 0 && mb_de_err == 0,
 000001           $sformatf("Modbus: device saw %0d parity, %0d stop, %0d DE errors", mb_par_err, mb_stop_err, mb_de_err));
 000001     check(mb_glitches == 0, $sformatf("Modbus: %0d glitches on the TX line", mb_glitches));
 000001     mb_en = 0;
 000001     reg_write(7'h1B, 8'h00);             // CRC off
 000001     reg_write(7'h1C, 8'h00);             // timeout off
 000001     reg_write(7'h1D, 8'h00);
 000001     reg_write(7'h1E, 8'h00);
        
            // ===== Test 6: two flag-using protocols at once (BUG-017) =====
        `ifdef PBE_SIGROK
            sigrok_phase = 6;
        `endif
 000001     $display("Test 6: 1-Wire Search ROM (engine 0, pin 6) and I2C (engine 1, pins 4-5) at the same time");
 000001     reg_write(7'h00, 8'b1100_0000);
 000001     mb_en = 0;
 000001     reg_write(7'h04, 8'h00);
 000001     reg_write(7'h02, 8'h03);
 000001     load_program("conc_image.hex");      // i2c_ctrl at word 0, onewire_ctrl at word 64
 000001     reg_write(7'h03, 8'b0011_0000);      // pins 4, 5 to E1; pin 6 to E0
 000001     reg_write(7'h10, 8'($rtoi(1000.0 / CLK_NS + 0.5) - 1));  // E0: 1-Wire, tick = 1 us
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, OW);
 000001     reg_write(7'h14, 2'b00);
 000001     reg_write(7'h15, 64);
 000001     reg_write(7'h20, 17);                // E1: I2C fast mode
 000001     reg_write(7'h21, 0);
 000001     reg_write(7'h22, 4);
 000001     reg_write(7'h24, 2'b11);
 000001     reg_write(7'h25, 0);
 000001     ow_e = 0;
 000001     ow_en_a = 1;
 000001     ow_en_b = 1;
 000001     ow_mon = 1;
 000001     ow_bad = 0;
 000001     i2c_en = 1;
 000001     i_starts = 0;
 000001     i_stops = 0;
 000001     reg_write(7'h00, 8'b0011_0011);      // restart + run both
 000001     fork
 000001       begin  // host process A: 1-Wire on engine 0
 000001         ow_reset;
 000001         check(ow_present, "concurrent 1-Wire: no presence");
 000001         s_done = 0;
 000001         s_last_disc = 0;
 000001         ow_search_next;
 000001         conc_rom = s_rom;
 000001         ow_search_next;
~000001         check(s_done && ((conc_rom == ROM_A && s_rom == ROM_B) || (conc_rom == ROM_B && s_rom == ROM_A)),
 000001               $sformatf("concurrent 1-Wire search found %016x, %016x", conc_rom, s_rom));
 000001         conc_ow_done = 1;
              end
 000001       begin  // host process B: I2C on engine 1, until 1-Wire is done (at least 3 rounds)
 000001         conc_i2c_busy = 1;
 000001         conc_rounds = 0;
 000062         while (!conc_ow_done || conc_rounds < 3) begin
 000062           conc_v = 8'h40 + conc_rounds;
 000062           i2c_cond(1);
 000062           i2c_xfer(8'hA0, 8'h80, conc_seen, conc_ack); check(conc_ack == 0, "concurrent I2C: address not ACKed");
 000062           i2c_xfer(8'h20, 8'h80, conc_seen, conc_ack);
 000062           i2c_xfer(conc_v, 8'h80, conc_seen, conc_ack);
 000062           i2c_cond(2);
 000062           i2c_cond(1);
 000062           i2c_xfer(8'hA0, 8'h80, conc_seen, conc_ack);
 000062           i2c_xfer(8'h20, 8'h80, conc_seen, conc_ack);
 000062           i2c_cond(1);
 000062           i2c_xfer(8'hA1, 8'h80, conc_seen, conc_ack);
 000062           i2c_xfer(8'hFF, 8'h80, conc_seen, conc_ack);
 000062           check(conc_seen === conc_v, $sformatf("concurrent I2C round %0d read %02x, wrote %02x", conc_rounds, conc_seen, conc_v));
 000062           i2c_cond(2);
 000062           conc_rounds++;
                end
 000001         conc_i2c_busy = 0;
              end
            join
 000001     ow_mon = 0;
 000001     check(ow_bad == 0, "concurrent 1-Wire: timing violations");
~000001     check(i_starts == 3 * conc_rounds && i_stops == 2 * conc_rounds,
 000001           $sformatf("concurrent I2C: %0d STARTs, %0d STOPs for %0d rounds", i_starts, i_stops, conc_rounds));
 000001     check(conc_overlap > 100, $sformatf("only %0d 1-Wire edges happened during I2C traffic", conc_overlap));
 000001     $display("  Search ROM found both devices while I2C ran %0d write/read rounds; %0d 1-Wire edges overlapped I2C traffic",
 000001              conc_rounds, conc_overlap);
 000001     ow_en_a = 0;
 000001     ow_en_b = 0;
 000001     i2c_en = 0;
        
            // ===== Test 7: SMBus PEC =====
        `ifdef PBE_SIGROK
            sigrok_phase = 7;
        `endif
 000001     $display("Test 7: SMBus PEC: I2C controller (engine 1) with its CRC unit as CRC-8 (poly 0x07)");
 000001     begin
 000001       logic [7:0] seen, ack, pec, lo, hi, st, c;
 000001       string s;
 000001       s = "123456789";
 000001       c = 0;
 000009       for (int i = 0; i < 9; i++) c = crc8(c, s[i]);
 000001       check(c == 8'hF4, $sformatf("testbench CRC-8 of \"123456789\" is %02x, the standard says f4", c));
        
 000001       reg_write(7'h00, 8'b1100_0000);
 000001       reg_write(7'h04, 8'h00);
 000001       load_program("conc_image.hex");    // i2c_ctrl at word 0
 000001       reg_write(7'h03, 8'b0011_0000);
 000001       reg_write(7'h20, 17);              // E1: I2C fast mode, as in test 3
 000001       reg_write(7'h21, 0);
 000001       reg_write(7'h22, 4);
 000001       reg_write(7'h24, 2'b11);
 000001       reg_write(7'h25, 0);
 000001       reg_write(7'h29, 8'h07);           // CRC-8, poly 0x07
 000001       reg_write(7'h2A, 8'h00);
 000001       reg_write(7'h2B, 8'h87);           // 8 bits, init 0, plain output, fed by IN bits only
 000001       i2c_en = 1;
 000001       i_pec_mode = 1;
 000001       i_pec_corrupt = 0;
 000001       reg_write(7'h00, 8'b0010_0010);    // restart + run E1
        
              // Write Word with PEC: [addr+W] [command 0x30] [0x12] [0x34] [PEC]
 000001       reg_write(7'h2F, 8'h01);           // restart the CRC for a new message
 000001       i2c_cond(1);
 000001       i2c_xfer(8'hA0, 8'h80, seen, ack); check(ack == 0, "SMBus: address+W not ACKed");
 000001       i2c_xfer(8'h30, 8'h80, seen, ack);
 000001       i2c_xfer(8'h12, 8'h80, seen, ack);
 000001       i2c_xfer(8'h34, 8'h80, seen, ack);
 000001       reg_read(7'h29, pec);              // the CRC unit's value is the PEC
 000001       c = crc8(crc8(crc8(crc8(0, 8'hA0), 8'h30), 8'h12), 8'h34);
 000001       check(pec == c, $sformatf("SMBus write: engine PEC %02x, expected %02x", pec, c));
 000001       i2c_xfer(pec, 8'h80, seen, ack); check(ack == 0, "SMBus: PEC byte not ACKed");
 000001       i2c_cond(2);
 000001       check(i_pec_at_stop == 0, $sformatf("SMBus write: the device's CRC over the message and PEC is %02x", i_pec_at_stop));
~000001       check(i2c_mem[8'h30] === 8'h12 && i2c_mem[8'h31] === 8'h34, "SMBus write: device did not store the word");
        
              // Read Word with PEC: [addr+W] [0x30] Sr [addr+R] [low] [high] [PEC], then once with a bad PEC
 000002       for (int bad = 0; bad < 2; bad++) begin
 000002         i_pec_corrupt = bad;
 000002         reg_write(7'h2F, 8'h01);
 000002         i2c_cond(1);
 000002         i2c_xfer(8'hA0, 8'h80, seen, ack);
 000002         i2c_xfer(8'h30, 8'h80, seen, ack);
 000002         i2c_cond(1);
 000002         i2c_xfer(8'hA1, 8'h80, seen, ack); check(ack == 0, "SMBus: address+R not ACKed");
 000002         i2c_xfer(8'hFF, 8'h00, lo, ack);
 000002         i2c_xfer(8'hFF, 8'h00, hi, ack);
 000002         i2c_xfer(8'hFF, 8'h80, pec, ack);  // NACK the PEC: last byte
 000002         i2c_cond(2);
 000002         reg_read(7'h2F, st);
~000002         check(lo == 8'h12 && hi == 8'h34, $sformatf("SMBus read word %02x%02x", hi, lo));
 000002         check(st[1] == !bad, $sformatf("SMBus read with %s PEC %02x: CRC ok = %0d",
 000002                                        bad ? "a bad" : "the right", pec, st[1]));
              end
 000001       $display("  Write Word and Read Word with PEC; the engine computes the PEC and checks the device's");
 000001       i2c_en = 0;
 000001       i_pec_mode = 0;
 000001       reg_write(7'h2B, 8'h00);
            end
        
 000001     if (errors == 0) begin
 000001       $display("PASS");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          initial begin
            #400ms;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
        // A DS18B20-style 1-Wire device: presence pulse, READ ROM (33), SEARCH ROM (F0), MATCH ROM (55),
        // SKIP ROM (CC) and READ SCRATCHPAD (BE). It samples written bits 30 us into a slot and holds
        // the line low for 30 us to send a 0. Written independently of the RTL.
        module ow_device #(
            parameter logic [63:0] ROM = 64'h0,
            parameter logic [71:0] SP  = 72'h0,
            parameter logic [71:0] SP_CONV = 72'h0,  // scratchpad after a successful CONVERT T
            parameter logic [79:0] BLK = 80'h0       // sent by function AA: data + inverted CRC-16
        ) (
 001568     input  wire  dq,
 000002     input  wire  enable,
 000002     input  wire  hard_hi, // DQ actively driven high (strong pull-up)
 000247     output logic pull
        );
          localparam int S_IDLE = 0, S_CMD = 1, S_ROMTX = 2, S_SRCH = 3, S_MATCH = 4, S_FUNC = 5, S_SPTX = 6,
                         S_BLKTX = 7;
          localparam realtime CONV_NS = 1000000;  // conversion time (1 ms here; 750 ms in a real DS18B20)
 000001   int st = S_IDLE, n = 0, sub = 0, conversions = 0, conv_fails = 0;
~000003   logic [71:0] sp = SP;
          event conv_go;
          // Parasite power: the conversion needs DQ driven hard high within 10 us and for CONV_NS.
~000002   initial forever begin
~000002     @(conv_go);
~000002     #10000;
~000002     begin : conv
~000002       realtime t;
~000002       bit ok;
~000002       ok = 1;
~000002       t = $realtime;
~002000       while ($realtime - t < CONV_NS) begin
~002000         if (!hard_hi) ok = 0;
~002000         #1000;
              end
~000002       if (ok) begin
~000002         sp = SP_CONV;
~000002         conversions++;
%000000       end else conv_fails++;
            end
          end
~000011   logic [63:0] sh;
 000428   bit tx_mode, tx_bit, b;
          realtime t0;
%000000   initial begin
%000000     pull = 0;
 001557     forever begin
 001557       @(negedge dq);
~001555       if (enable && !pull) begin
 001555         tx_mode = 0;
 001555         tx_bit = 1;
~001491         if (st == S_ROMTX) begin tx_mode = 1; tx_bit = ROM[n]; end
 001263         if (st == S_SRCH && sub < 2) begin tx_mode = 1; tx_bit = sub ? !ROM[n] : ROM[n]; end
 001483         if (st == S_SPTX) begin tx_mode = 1; tx_bit = sp[n]; end
~001555         if (st == S_BLKTX) begin tx_mode = 1; tx_bit = BLK[n]; end
 001555         t0 = $realtime;
 001319         if (tx_mode && !tx_bit) pull = 1;
 001555         #30000;
 001555         b = dq;
 001555         pull = 0;
 020068         while (!dq && $realtime - t0 < 400000) #1000;
 001544         if (!dq) begin  // reset pulse: answer with a presence pulse
 000011           @(posedge dq);
 000011           #30000;
 000011           pull = 1;
 000011           #120000;
 000011           pull = 0;
 000011           st = S_CMD;
 000011           n = 0;
 000011           sh = 0;
 001544         end else begin
 001544           case (st)
 000080             S_CMD: begin
 000080               sh[n] = b;
 000080               n++;
 000070               if (n == 8) begin
 000010                 n = 0;
 000010                 case (sh[7:0])
~000001                   8'h33: st = S_ROMTX;
 000004                   8'hF0: begin st = S_SRCH; sub = 0; end
 000005                   8'h55: st = S_MATCH;
%000000                   8'hCC: st = S_FUNC;
%000000                   default: st = S_IDLE;
                        endcase
 000010                 sh = 0;
                      end
                    end
~000064             S_ROMTX: begin n++; if (n == 64) st = S_IDLE; end
 000438             S_SRCH: begin
 000292               if (sub < 2) sub++;
 000146               else begin
 000146                 sub = 0;
 000144                 if (b != ROM[n]) st = S_IDLE;  // controller chose the other branch
 000144                 else begin
 000144                   n++;
 000142                   if (n == 64) st = S_IDLE;
                        end
                      end
                    end
 000320             S_MATCH: begin
 000320               sh[n] = b;
 000320               n++;
 000315               if (n == 64) begin
~000005                 st = (sh == ROM) ? S_FUNC : S_IDLE;
 000005                 n = 0;
 000005                 sh = 0;
                      end
                    end
 000024             S_FUNC: begin
 000024               sh[n] = b;
 000024               n++;
 000021               if (n == 8) begin
 000003                 case (sh[7:0])
 000001                   8'hBE: st = S_SPTX;   // READ SCRATCHPAD
~000001                   8'hAA: st = S_BLKTX;  // block with an inverted CRC-16
~000002                   8'h44: begin          // CONVERT T, parasite powered
~000002                     st = S_IDLE;
~000002                     -> conv_go;
                          end
%000000                   default: st = S_IDLE;
                        endcase
 000003                 n = 0;
                      end
                    end
 000072             S_SPTX: begin n++; if (n == 72) st = S_IDLE; end
~000080             S_BLKTX: begin n++; if (n == 80) st = S_IDLE; end
 000546             default: ;
                  endcase
                end
              end
            end
          end
        endmodule
        
