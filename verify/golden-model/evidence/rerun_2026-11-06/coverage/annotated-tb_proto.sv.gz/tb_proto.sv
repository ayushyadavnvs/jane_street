//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // End-to-end tests of the LED and device-side protocols, through the chip's pins only.
        //
        //  Test 8   WS2812 LED driver (engine 0, pin 0) against a decoder that checks every pulse width
        //  Test 9   SPI peripheral (engine 0, pins 0..3) driven by a mode-0 controller model at 2 MHz
        //  Test 10  I2C target: i2c_target (engine 0) and i2c_watch (engine 1) share pins 0-1 and their
        //           flags; an I2C controller model drives the bus and the host answers through flags
        //
        // Every pin has a pull-up and lines are wired-AND, like a real open-drain bus.
        module tb_proto;
          localparam real CLK_NS = 20.8333;  // 48 MHz
          localparam int HOST_HALF = 8;      // host SCK = clk / 16
        
~184227   logic clk = 0, rst_n = 0;
 368453   always #(CLK_NS / 2) clk = ~clk;
        
~010504   logic [7:0] ui_in = 8'b0000_0010;  // CS_n high
~000553   wire  [7:0] uo_out, uio_out, uio_oe;
~000303   logic [7:0] ext_drive = '0, ext_val = '0;
        
~000274   wire  [7:0] chip_lvl = ~uio_oe | uio_out;  // released pins float high
~000318   wire  [7:0] ext_lvl  = ~ext_drive | ext_val;
~000397   wire  [7:0] bus      = chip_lvl & ext_lvl;
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in(bus), .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
        
          // Verification-only scalar pins and phase markers; disabled for normal tests.
        `ifdef PBE_SIGROK
          integer sigrok_phase = 0;
          wire p0 = bus[0], p1 = bus[1], p2 = bus[2], p3 = bus[3];
          wire p4 = bus[4], p5 = bus[5], p6 = bus[6], p7 = bus[7];
          initial begin
            $dumpfile("tb_proto_pins.vcd");
            $dumpvars(0, p0, p1, p2, p3, p4, p5, p6, p7, sigrok_phase);
          end
        `endif
        
          `include "tb_host.svh"
        
          // Burst bytes into engine e's TX FIFO in one SPI transaction, pausing while the TX-full pin
          // (uo_out[6 + e]) is high: the flow control a real host would use.
          logic [7:0] stream_q[$];
 000002   task automatic fifo_stream(input int e);
 000002     logic [7:0] d;
 000002     cs(0);
 000002     spi_byte({1'b1, e ? 7'h26 : 7'h16}, d);
 000030     while (stream_q.size()) begin
%000000       while (uo_out[6+e]) @(posedge clk);
 000030       d = stream_q.pop_front();  // Icarus 12 crashes on a queue pop passed as an argument
 000030       spi_byte(d, d);
            end
 000002     cs(1);
          endtask
        
          // ---------------- WS2812 decoder on pin 0 ----------------
          // WS2812B datasheet: T0H 0.4 us, T1H 0.8 us, T0L 0.85 us, T1L 0.45 us, each +/-150 ns.
          // A low of 50 us or more latches the frame; ws_take_frame collects it.
 000001   bit ws_en = 0;
 000001   int ws_bad = 0;
          logic [7:0] ws_bits[$];  // one bit per entry (Icarus 12 mishandles queues of 1-bit elements)
 000049   bit ws_last;
 000001   realtime ws_rise = 0, ws_fall = 0, low, high;  // not declared in the always blocks: a
                                                         // declaration's initializer runs only once
 000397   always @(posedge bus[0]) if (ws_en) begin
 000238     if (ws_fall > 0) begin
 000238       low = $realtime - ws_fall;
~000238       if (ws_last ? (low < 300 || low > 600) : (low < 700 || low > 1000)) begin
%000000         ws_bad++;
%000000         $display("  WS2812: low after a %0d bit lasted %0.0f ns", ws_last, low);
              end
            end
 000240     ws_rise = $realtime;
          end
 000396   always @(negedge bus[0]) if (ws_en && ws_rise > 0) begin
 000240     high = $realtime - ws_rise;
 000240     ws_last = high > 600;
~000240     if (ws_last ? (high < 650 || high > 950) : (high < 250 || high > 550)) begin
%000000       ws_bad++;
%000000       $display("  WS2812: high lasted %0.0f ns", high);
            end
 000240     ws_bits.push_back(8'(ws_last));
 000240     ws_fall = $realtime;
          end
          logic [7:0] ws_bytes[$];
 000002   task automatic ws_take_frame;  // decoded bytes into ws_bytes
 000002     ws_bytes.delete();
 000002     check(bus[0] == 0, "WS2812: line not low at the end of a frame");
 000002     check(ws_bits.size() % 8 == 0, $sformatf("WS2812: frame of %0d bits", ws_bits.size()));
 000030     while (ws_bits.size() >= 8) begin
 000030       logic [7:0] b;
 000030       logic [7:0] x;
 000240       for (int i = 7; i >= 0; i--) begin  // MSB first
 000240         x = ws_bits.pop_front();
 000240         b[i] = x[0];
              end
 000030       ws_bytes.push_back(b);
            end
 000002     ws_bits.delete();
 000002     ws_fall = 0;  // the next low is a reset, not a bit
          endtask
        
          // ---------------- SPI controller model, mode 0: sclk 0, mosi 1, miso 2, cs 3 ----------------
          localparam int SPI_HALF = 12;  // SCLK half period in clocks: 2 MHz at 48 MHz
 000001   bit spic_en = 0;
 000007   task automatic spic_select(input bit sel);
 000007     ext_drive[0] = 1; ext_drive[1] = 1; ext_drive[3] = 1;
 000007     ext_val[3] = !sel;
          endtask
 000007   task automatic spic_byte(input logic [7:0] tx, output logic [7:0] rx);
 000056     for (int i = 7; i >= 0; i--) begin
 000056       ext_val[1] = tx[i];
 000672       repeat (SPI_HALF) @(posedge clk);
 000056       rx[i] = bus[2];  // sampled just before the rising edge: tests the setup time
 000056       ext_val[0] = 1;
 000672       repeat (SPI_HALF) @(posedge clk);
 000056       ext_val[0] = 0;
            end
          endtask
          // the peripheral may change MISO only while SCLK is low
 000021   always @(bus[2]) if (spic_en && !bus[3])
~000020     check(!bus[0], "SPI peripheral: MISO changed while SCLK was high");
        
          // ---------------- I2C controller model: sda = pin 0, scl = pin 1, fast mode ----------------
          localparam int IC_LOW = 64, IC_HIGH = 32;  // 1.33 us low, 0.67 us high: 400 kHz
          localparam logic [6:0] TGT_ADDR = 7'h42;
 000001   bit ic_en = 0;
 000001   int ic_stretch = 0;  // clocks the target held SCL low
 000311   task automatic ic_sda(input bit v);
 000311     ext_drive[0] = !v;
 000311     ext_val[0] = 0;
          endtask
 000604   task automatic ic_scl(input bit v);
 000604     ext_drive[1] = !v;
 000604     ext_val[1] = 0;
          endtask
 000302   task automatic ic_release_scl;  // release SCL and wait while the target stretches it
 000302     ic_scl(1);
 000302     @(posedge clk);
 013694     while (!bus[1]) begin
 013694       ic_stretch++;
 013694       @(posedge clk);
            end
          endtask
 000297   task automatic ic_bit(input bit b, output bit r);  // SCL is low on entry and exit
 004752     repeat (IC_LOW / 4) @(posedge clk);
 000297     ic_sda(b);
 014256     repeat (IC_LOW - IC_LOW / 4) @(posedge clk);
 000297     ic_release_scl;
 009504     repeat (IC_HIGH) @(posedge clk);
 000297     r = bus[0];
 000297     ic_scl(0);
          endtask
 000005   task automatic ic_start;  // START, or repeated START when SCL is low
            // Test our own drive, not bus[1]: right after ic_scl(0) the net has not updated yet.
 000004     if (ext_drive[1]) begin
 000016       repeat (IC_LOW / 4) @(posedge clk);
 000001       ic_sda(1);
 000048       repeat (IC_LOW - IC_LOW / 4) @(posedge clk);
 000001       ic_release_scl;
 000032       repeat (IC_HIGH) @(posedge clk);  // tSU;STA
            end
 000005     ic_sda(0);
 000160     repeat (IC_HIGH) @(posedge clk);    // tHD;STA
 000005     ic_scl(0);
          endtask
 000004   task automatic ic_stop;
 000064     repeat (IC_LOW / 4) @(posedge clk);
 000004     ic_sda(0);
 000192     repeat (IC_LOW - IC_LOW / 4) @(posedge clk);
 000004     ic_release_scl;
 000128     repeat (IC_HIGH) @(posedge clk);    // tSU;STO
 000004     ic_sda(1);
 000256     repeat (IC_LOW) @(posedge clk);     // tBUF
          endtask
 000001   bit ic_other = 0;  // another target on the bus ACKs (pulls SDA low in the ACK slot)
 000029   task automatic ic_write(input logic [7:0] b, output bit ack);
 000029     bit r;
 000232     for (int i = 7; i >= 0; i--) ic_bit(b[i], r);
 000029     ic_bit(!ic_other, r);
~000029     ack = !r;
          endtask
 000004   task automatic ic_read(input bit ack, output logic [7:0] b);
 000004     bit r;
 000032     for (int i = 7; i >= 0; i--) begin
 000032       ic_bit(1, r);  // not ic_bit(1, b[i]): Icarus 12 crashes on a bit-select as an output argument
 000032       b[i] = r;
            end
 000004     ic_bit(!ack, r);
          endtask
        
          // The target must change SDA only while SCL is low, at least 300 ns after SCL fell (data hold),
          // and at least 250 ns before it lets go of a stretched SCL (data setup, standard mode).
 000001   realtime ic_fell = 0, ic_sda_chg = 0;
 000001   int ic_hold_min = 1000000, ic_setup_min = 1000000;
 000317   always @(negedge bus[1]) ic_fell = $realtime;
 000547   always @(chip_lvl[0]) if (ic_en) begin
~000064     check(!bus[1], "I2C target: SDA changed while SCL was high");
 000040     if ($realtime - ic_fell < ic_hold_min) ic_hold_min = $realtime - ic_fell;
 000064     ic_sda_chg = $realtime;
          end
 000032   always @(posedge chip_lvl[1]) if (ic_en)
 000030     if ($realtime - ic_sda_chg < ic_setup_min) ic_setup_min = $realtime - ic_sda_chg;
        
          // Host service loop for the target: a register device like the one in tb_pbe. A write's first
          // byte sets the pointer, later bytes are stored; reads return bytes from the pointer.
~000006   logic [7:0] tgt_mem[256], tgt_ptr;
          logic [7:0] tgt_pending[$];
 000002   bit tgt_run = 0, tgt_first = 0;
 000001   int tgt_acks = 0, tgt_nacks = 0, tgt_stops = 0, tgt_reads = 0, tgt_bytes = 0;
 000046   task automatic tgt_drain;
 000046     logic [7:0] st, d;
 000046     reg_read(7'h01, st);
 000027     while (!st[0]) begin
 000027       reg_read(7'h16, d);
 000027       tgt_pending.push_back(d);
 000027       reg_read(7'h01, st);
            end
          endtask
 000022   task automatic tgt_data(input logic [7:0] d);
 000022     tgt_bytes++;
 000020     if (tgt_first) tgt_ptr = d;
 000020     else begin
 000020       tgt_mem[tgt_ptr] = d;
 000020       tgt_ptr++;
            end
 000022     tgt_first = 0;
          endtask
~138758   initial forever begin
 138758     @(posedge clk);
 138722     if (tgt_run) begin
 000036       logic [7:0] f, a, a2;
 000036       tgt_drain;
 000036       reg_read(7'h04, f);  // after the drain: if FLAG2 is still clear, no address was drained
 000028       if (f[2]) begin
 000009         tgt_drain;
 000005         if (tgt_pending.size()) begin  // an address, after any data bytes written before it
 000005           a = tgt_pending.pop_back();
 000001           while (tgt_pending.size()) begin
 000001             a2 = tgt_pending.pop_front();
 000001             tgt_data(a2);
                  end
 000004           if (a[7:1] == TGT_ADDR) begin
 000004             tgt_acks++;
 000004             tgt_first = !a[0];
 000001           end else begin
 000001             tgt_nacks++;
 000001             reg_write(7'h00, 8'b0001_0011);  // NACK: restart engine 0, keep both running
                  end
 000004         end else begin                 // a read needs its next byte
 000004           a = tgt_mem[tgt_ptr];
 000004           fifo_send(0, a);
 000004           tgt_ptr++;
 000004           tgt_reads++;
                end
 000009         reg_write(7'h09, 8'h04);       // clear FLAG2: the engine goes on
 000021       end else while (tgt_pending.size()) begin
 000021         a2 = tgt_pending.pop_front();
 000021         tgt_data(a2);
              end
 000033       if (f[3]) begin
 000003         tgt_stops++;
 000003         reg_write(7'h09, 8'h08);
              end
            end
          end
 000004   task automatic tgt_wait_stops(input int n);
 000004     int t = 0;
~002101     while (tgt_stops < n && t < 20000) begin
 002101       @(posedge clk);
 002101       t++;
            end
 000004     check(tgt_stops >= n, $sformatf("I2C target: host saw %0d STOPs, expected %0d", tgt_stops, n));
          endtask
        
          // ---------------- tests ----------------
 000001   initial begin
 000001     logic [7:0] got[$], exp[$];
        `ifndef PBE_SIGROK
~000001     if ($test$plusargs("vcd")) begin
%000000       $dumpfile("tb_proto.vcd");
%000000       $dumpvars(0, tb_proto);
            end
        `endif
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
        
            // ===== Test 8: WS2812 =====
        `ifdef PBE_SIGROK
            sigrok_phase = 8;
        `endif
 000001     $display("Test 8: WS2812 LED driver (engine 0, pin 0) at 800 kbit/s");
 000001     load_program("ws2812_image.hex");
 000001     reg_write(7'h10, 1);                 // tick = 2 clocks (41.7 ns)
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h14, 2'b01);             // OUT MSB first
 000001     reg_write(7'h15, 0);
 000001     ws_en = 1;
 000001     reg_write(7'h00, 8'b0001_0001);      // restart + run E0
 000002     for (int frame = 0; frame < 2; frame++) begin
 000002       exp.delete();
 000010       for (int led = 0; led < 5; led++) begin  // G, R, B per LED
                // 8'() casts: Icarus 12 aborts when push_back gets a wider value than the queue holds
 000010         exp.push_back(8'(8'h10 * led + frame));
 000010         exp.push_back(8'(frame ? 8'hFF - 8'h33 * led : 8'h01 << led));
 000010         exp.push_back(8'(8'hA5 ^ (8'h11 * led)));
              end
 000030       foreach (exp[i]) stream_q.push_back(exp[i]);
 000002       fifo_stream(0);
 000002       wait_tx_empty(0);
 005760       repeat ($rtoi(60000 / CLK_NS)) @(posedge clk);  // the last byte, then a 50 us reset
 000002       ws_take_frame;
 000002       got.delete();
 000030       foreach (ws_bytes[i]) got.push_back(ws_bytes[i]);
 000002       check(got.size() == exp.size(), $sformatf("WS2812 frame %0d: %0d bytes", frame, got.size()));
~000030       foreach (got[i])
~000030         if (i < exp.size())
 000030           check(got[i] === exp[i], $sformatf("WS2812 frame %0d byte %0d: %02x, sent %02x", frame, i, got[i], exp[i]));
            end
 000001     check(ws_bad == 0, $sformatf("WS2812: %0d pulses out of spec", ws_bad));
 000001     $display("  2 frames of 5 LEDs, every pulse within +/-150 ns of the datasheet");
 000001     ws_en = 0;
        
            // ===== Test 9: SPI peripheral =====
        `ifdef PBE_SIGROK
            sigrok_phase = 9;
        `endif
 000001     $display("Test 9: SPI peripheral (engine 0, pins 0..3), mode 0, SCLK 2 MHz");
 000001     reg_write(7'h00, 8'b1100_0000);      // stop, flush FIFOs
 000001     load_program("spi_periph_image.hex");
 000001     reg_write(7'h10, 0);                 // tick = 1 clock
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h13, 3);                 // JMP pin = cs
 000001     reg_write(7'h14, 2'b11);             // MSB first both ways
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h1C, 64);                // timeout: 64 clocks without SCLK
 000001     reg_write(7'h1D, 0);
 000001     reg_write(7'h1E, 8'h01);             // timeout routine at word 1
 000001     spic_select(0);
 000001     reg_write(7'h00, 8'b0001_0001);
 000100     repeat (100) @(posedge clk);
~000001     check(!uio_oe[2], "SPI peripheral drives MISO while not selected");
 000001     spic_en = 1;
 000001     begin
 000001       logic [7:0] rx, sent[$], back[$];
              // 1: two replies queued, the controller clocks three bytes: the third reply is 0xFF
 000001       fifo_send(0, 8'h3C);
 000001       fifo_send(0, 8'hA5);
 000001       sent = '{8'h11, 8'h22, 8'h33};
 000001       spic_select(1);
~000003       foreach (sent[i]) begin
 000003         spic_byte(sent[i], rx);
 000003         back.push_back(rx);
              end
 000012       repeat (SPI_HALF) @(posedge clk);
 000001       spic_select(0);
~000001       check(back[0] == 8'h3C && back[1] == 8'hA5 && back[2] == 8'hFF,
 000001             $sformatf("SPI peripheral replies %02x %02x %02x, expected 3c a5 ff", back[0], back[1], back[2]));
 000100       repeat (100) @(posedge clk);       // > timeout: the transaction is over
~000001       check(!uio_oe[2], "SPI peripheral: MISO not released after CS went high");
~000003       foreach (sent[i]) begin
 000003         fifo_recv(0, rx);
 000003         check(rx === sent[i], $sformatf("SPI peripheral received %02x, controller sent %02x", rx, sent[i]));
              end
        
              // 2: a pause longer than the timeout in the middle of a transaction
 000001       back.delete();
 000001       fifo_send(0, 8'h5A);
 000001       fifo_send(0, 8'hC3);
 000001       spic_select(1);
 000001       spic_byte(8'h44, rx);
 000001       back.push_back(rx);
 000300       repeat (300) @(posedge clk);       // CS stays low, SCLK stops
 000001       spic_byte(8'h55, rx);
 000001       back.push_back(rx);
 000012       repeat (SPI_HALF) @(posedge clk);
 000001       spic_select(0);
~000001       check(back[0] == 8'h5A && back[1] == 8'hC3,
 000001             $sformatf("SPI peripheral after a pause: replies %02x %02x, expected 5a c3", back[0], back[1]));
 000001       fifo_recv(0, rx);
 000001       check(rx === 8'h44, $sformatf("SPI peripheral received %02x before the pause", rx));
 000001       fifo_recv(0, rx);
 000001       check(rx === 8'h55, $sformatf("SPI peripheral received %02x after the pause", rx));
 000100       repeat (100) @(posedge clk);
        
              // 3: nothing queued at all: the controller reads 0xFF from the first bit on
 000001       back.delete();
 000001       spic_select(1);
 000002       for (int i = 0; i < 2; i++) begin
 000002         spic_byte(8'h60 + i, rx);
 000002         back.push_back(rx);
              end
 000012       repeat (SPI_HALF) @(posedge clk);
 000001       spic_select(0);
~000001       check(back[0] == 8'hFF && back[1] == 8'hFF,
 000001             $sformatf("SPI peripheral with nothing queued replied %02x %02x, expected ff ff", back[0], back[1]));
 000002       for (int i = 0; i < 2; i++) begin
 000002         fifo_recv(0, rx);
 000002         check(rx === 8'h60 + i, $sformatf("SPI peripheral received %02x, controller sent %02x", rx, 8'h60 + i));
              end
 000100       repeat (100) @(posedge clk);
            end
 000001     spic_en = 0;
 000001     ext_drive = '0;
 000001     $display("  3 transactions: replies queued, default 0xFF, a pause inside a transaction");
        
            // ===== Test 10: I2C target =====
        `ifdef PBE_SIGROK
            sigrok_phase = 10;
        `endif
 000001     $display("Test 10: I2C target at 0x%02x (engines 0 + 1, pins 0-1), fast mode controller", TGT_ADDR);
 000001     reg_write(7'h00, 8'b1100_0000);
 000001     reg_write(7'h1C, 0);                 // timeout off
 000001     reg_write(7'h1E, 0);
 000001     reg_write(7'h04, 8'h00);
 000001     reg_write(7'h02, 8'h03);
 000001     load_program("i2c_target_image.hex");  // bit engine at word 0, watcher at word 64
 000001     reg_write(7'h03, 8'h00);             // both pins belong to E0
 000001     reg_write(7'h10, 0);                 // E0: bit engine
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h13, 0);                 // JMP pin = sda
 000001     reg_write(7'h14, 2'b11);
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h20, 0);                 // E1: watcher, same pins, same flags
 000001     reg_write(7'h21, 0);
 000001     reg_write(7'h22, 0);
 000001     reg_write(7'h23, 1);                 // JMP pin = scl
 000001     reg_write(7'h25, 64);
 000001     reg_write(7'h28, 0);                 // FLAG_BASE 0, like engine 0
 000001     ic_en = 1;
 000001     reg_write(7'h00, 8'b0011_0011);      // restart + run both
 000001     tgt_run = 1;
 000001     begin
 000001       bit ack;
 000001       logic [7:0] b;
              // 1: write the pointer 0x10 and 20 bytes (more than the 16-byte RX FIFO holds)
 000001       ic_start;
 000001       ic_write({TGT_ADDR, 1'b0}, ack); check(ack, "I2C target: address+W not ACKed");
 000001       ic_write(8'h10, ack); check(ack, "I2C target: pointer not ACKed");
 000001       exp = '{8'hDE, 8'hAD, 8'hBE, 8'hEF, 8'h01};
 000015       for (int i = 5; i < 20; i++) exp.push_back(8'(8'h30 + i));
~000020       foreach (exp[i]) begin
 000020         ic_write(exp[i], ack);
 000020         check(ack, $sformatf("I2C target: data byte %0d not ACKed", i));
              end
 000001       ic_stop;
 000001       tgt_wait_stops(1);
~000020       foreach (exp[i])
 000020         check(tgt_mem[8'h10 + i] === exp[i], $sformatf("I2C target write: mem[%02x] = %02x", 8'h10 + i, tgt_mem[8'h10 + i]));
        
              // 2: set the pointer, repeated START, read three bytes
 000001       ic_start;
 000001       ic_write({TGT_ADDR, 1'b0}, ack);
 000001       ic_write(8'h11, ack);
 000001       ic_start;
 000001       ic_write({TGT_ADDR, 1'b1}, ack); check(ack, "I2C target: address+R not ACKed");
 000001       got.delete();
 000003       for (int i = 0; i < 3; i++) begin
 000003         ic_read(i < 2, b);
 000003         got.push_back(b);
              end
 000001       ic_stop;
 000001       tgt_wait_stops(2);
~000001       check(got[0] == 8'hAD && got[1] == 8'hBE && got[2] == 8'hEF,
 000001             $sformatf("I2C target read %02x %02x %02x, expected ad be ef", got[0], got[1], got[2]));
        
              // 3: another device's address: the host NACKs it. That device ACKs and takes two bytes;
              // our target must stay off SDA and pass nothing to the host.
 000001       begin
 000001         int bytes_before;
 000001         bit sda_touched;
 000001         bytes_before = tgt_bytes;  // not an initializer: that would run once, at time 0
 000001         sda_touched = 0;
 000001         ic_other = 1;
 000001         fork
 000001           begin : watch_sda
 000001             @(negedge chip_lvl[0]) sda_touched = 1;
                  end
 000001           begin
 000001             ic_start;
 000001             ic_write({TGT_ADDR + 7'd1, 1'b0}, ack);
 000001             ic_write(8'h77, ack);
 000001             ic_write(8'h88, ack);
 000001             ic_stop;
 000001             disable watch_sda;
                  end
                join
 000001         ic_other = 0;
 000001         tgt_wait_stops(3);
~000001         check(!sda_touched, "I2C target drove SDA during another device's transaction");
 000001         check(tgt_bytes == bytes_before, $sformatf("I2C target passed %0d bytes of another device's transaction to the host",
 000001                                                  tgt_bytes - bytes_before));
              end
        
              // 4: and the target still answers: a read continues from the pointer (now 0x14)
 000001       ic_start;
 000001       ic_write({TGT_ADDR, 1'b1}, ack); check(ack, "I2C target: address+R not ACKed after a NACK");
 000001       ic_read(0, b);
 000001       ic_stop;
 000001       tgt_wait_stops(4);
 000001       check(b == 8'h01, $sformatf("I2C target read %02x after the NACK, expected 01", b));
            end
 000001     tgt_run = 0;
~000001     check(tgt_acks == 4 && tgt_nacks == 1 && tgt_reads == 4,
 000001           $sformatf("I2C target host: %0d ACKs, %0d NACKs, %0d reads", tgt_acks, tgt_nacks, tgt_reads));
 000001     check(ic_stretch > 0, "I2C target never stretched SCL");
 000001     check(ic_hold_min >= 300, $sformatf("I2C target: SDA hold %0d ns after SCL fell", ic_hold_min));
 000001     check(ic_setup_min >= 250, $sformatf("I2C target: SDA setup %0d ns before SCL release", ic_setup_min));
 000001     $display("  write 20 bytes, read 3 after a repeated START, ignore another device's transfer; hold >= %0d ns, setup >= %0d ns",
 000001              ic_hold_min, ic_setup_min);
 000001     ic_en = 0;
        
 000001     if (errors == 0) begin
 000001       $display("PASS");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          initial begin
            #100ms;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
