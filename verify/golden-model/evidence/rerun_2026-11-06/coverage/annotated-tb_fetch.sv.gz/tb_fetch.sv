//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // Instruction fetch (D50), end to end through the chip's pins and host port.
        //
        //  Timing: engine 0 runs fetch_timing.pbe at CLKDIV = 0, 1 and 3. Every edge of pin 0 is timed
        //  in clocks and checked against the rule at the top of pbe_engine.sv:
        //    an instruction takes (DLY + 1) * (CLKDIV + 1) clocks, plus 1 if it is a taken jump and
        //    CLKDIV = 0; after a WAIT completes, the next instruction is timed from that clock.
        //  Host writes: engine 1 runs fetch_host.pbe. The host rewrites
        //    (a) the word the stopped engine is parked on, then runs it again without a restart;
        //    (b) the first word, then restarts the engine;
        //    (c) the word a running engine is blocked on (WAIT FLAG 0, HIGH becomes LOW).
        //  Each time the engine must run the new word, not the copy in its instruction register.
        module tb_fetch;
          localparam real CLK_NS = 20.8333;  // 48 MHz
          localparam int HOST_HALF = 8;      // host SCK = clk / 16
        
~044964   logic clk = 0, rst_n = 0;
 089928   always #(CLK_NS / 2) clk = ~clk;
        
~002664   logic [7:0] ui_in = 8'b0000_0010;  // CS_n high
~000018   wire  [7:0] uo_out, uio_out, uio_oe;
 000003   logic       pin1 = 0;
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in({6'b0, pin1, 1'b0}), .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
        
          `include "tb_host.svh"
        
          // clock count; pin 0 changes after the edge that counted it
 000001   int cyc = 0;
 044964   always @(posedge clk) cyc++;
          int edges[$];
 000037   always @(uio_out[0]) edges.push_back(cyc);
        
          // ---------------- timing ----------------
          int k, j, t0, tj0, tj1, t1, t2, lat, rise;
          int exp_d[$];
 000003   task automatic timing(input int clkdiv);
 000003     int got;
 000003     logic [7:0] d;
 000003     k   = clkdiv + 1;             // clocks per tick
 000003     j   = (clkdiv == 0) ? 1 : 0;  // the bubble after a taken jump shows only at CLKDIV = 0
 000003     t0  = k;                      // DLY 0, 1 and 2
 000003     t1  = 2 * k;
 000003     t2  = 3 * k;
 000003     tj0 = k + j;                  // taken jumps, DLY 0 and 1
 000003     tj1 = 2 * k + j;
            // E1-E0 .. E8-E7: two passes of the loop, the first ending in a taken JMP X--
 000003     exp_d = '{t0, t2, t0 + tj1, t0 + tj0, t0, t2, t0 + tj1, t0 + t0};
 000003     reg_write(7'h00, 8'h00);      // stop
 000003     reg_write(7'h10, 8'(clkdiv));
 000003     reg_write(7'h11, 8'h00);
 000003     pin1 = 0;
 000003     edges.delete();
 000003     reg_write(7'h00, 8'h11);      // restart and run engine 0
 000094     while (edges.size() < 9) @(posedge clk);
 000150     repeat (50) @(posedge clk);
 000003     #1 pin1 = 1;
 000003     rise = cyc;                   // the chip's input synchronizer takes it at the next edge
 000040     while (edges.size() < 12) @(posedge clk);
 000024     for (int i = 0; i < 8; i++) begin
 000024       got = edges[i+1] - edges[i];
 000024       check(got == exp_d[i], $sformatf("CLKDIV %0d: E%0d-E%0d = %0d clocks, expected %0d",
 000024                                        clkdiv, i + 1, i, got, exp_d[i]));
            end
            // WAIT sees the pin 3 clocks after it changes (2 synchronizer flops, then the WAIT's
            // clock); the next instruction issues on the first tick after that.
 000003     lat = edges[9] - rise;
 000003     check(lat == 3 + k, $sformatf("CLKDIV %0d: pin 1 rise to E9 = %0d clocks, expected %0d",
 000003                                   clkdiv, lat, 3 + k));
 000003     check(edges[10] - edges[9] == t1, $sformatf("CLKDIV %0d: E10-E9 = %0d clocks, expected %0d",
 000003                                                clkdiv, edges[10] - edges[9], t1));
 000003     check(edges[11] - edges[10] == t0, $sformatf("CLKDIV %0d: E11-E10 = %0d clocks, expected %0d",
 000003                                                 clkdiv, edges[11] - edges[10], t0));
 000003     $display("  CLKDIV %0d: edge gaps %0d %0d %0d %0d %0d %0d %0d %0d, WAIT latency %0d", clkdiv,
 000003              edges[1] - edges[0], edges[2] - edges[1], edges[3] - edges[2], edges[4] - edges[3],
 000003              edges[5] - edges[4], edges[6] - edges[5], edges[7] - edges[6], edges[8] - edges[7], lat);
          endtask
        
          // ---------------- host writes ----------------
 000002   task automatic pm_write(input int word, input logic [15:0] v);
 000002     logic [7:0] d;
 000002     reg_write(7'h06, 8'(word * 2));
 000002     cs(0);
 000002     spi_byte({1'b1, 7'h07}, d);
 000002     spi_byte(v[15:8], d);
 000002     spi_byte(v[7:0], d);
 000002     cs(1);
          endtask
        
          // the bytes in engine 1's RX FIFO, after giving the engine time to push them
          logic [7:0] rx_got[$];
 000003   task automatic rx_take;
 000003     logic [7:0] n, d;
 000003     rx_got.delete();
 000600     repeat (200) @(posedge clk);
 000003     reg_read(7'h0B, n);
 000005     for (int i = 0; i < n; i++) begin
 000005       reg_read(7'h26, d);
 000005       rx_got.push_back(d);
            end
          endtask
        
 000003   task automatic expect_rx(input string what, input logic [7:0] a, input int n);
            // a, then 0x33 and 0x5A for case (b)
 000003     logic [7:0] want[$];
 000003     string s;
 000003     want = '{a, 8'h33, 8'h5A};
 000003     rx_take;
 000003     s = "";
 000005     foreach (rx_got[i]) s = {s, $sformatf(" %02x", rx_got[i])};
 000003     check(rx_got.size() == n, $sformatf("%s: %0d bytes (%s ), expected %0d", what, rx_got.size(), s, n));
 000005     for (int i = 0; i < n && i < rx_got.size(); i++)
 000005       check(rx_got[i] == want[i], $sformatf("%s: byte %0d is %02x, expected %02x", what, i,
 000005                                             rx_got[i], want[i]));
 000003     $display("  %s:%s", what, s);
          endtask
        
 000001   initial begin
 000001     logic [7:0] f;
 000001     $display("Test 12: instruction fetch: timing at CLKDIV 0, 1, 3 and host writes to the program memory");
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
 000001     load_program("fetch_image.hex");
        
 000001     timing(0);
 000001     timing(1);
 000001     timing(3);
        
 000001     reg_write(7'h00, 8'h00);
 000001     reg_write(7'h25, 8'd64);      // engine 1 runs fetch_host.pbe
 000001     reg_write(7'h00, 8'h22);      // restart and run engine 1
 000001     expect_rx("first run", 8'h11, 1);
        
            // (a) parked on PULL (word 3), stopped, word 3 becomes SET OSR, 0x33; run, no restart
 000001     reg_write(7'h00, 8'h00);
 000020     repeat (20) @(posedge clk);
 000001     pm_write(64 + 3, 16'h9330);
 000020     repeat (20) @(posedge clk);
 000001     reg_write(7'h00, 8'h02);
 000001     expect_rx("(a) stopped on a word the host rewrote, then run", 8'h33, 1);
        
            // (c) running, blocked on WAIT FLAG 0, HIGH (word 6); the host writes the low byte only
 000001     reg_write(7'h06, 8'((64 + 6) * 2 + 1));
 000001     reg_write(7'h07, 8'h00);      // 0x4280 -> 0x4200: WAIT FLAG 0, LOW, which holds at once
 000001     rx_got.delete();
 000200     repeat (200) @(posedge clk);
 000001     reg_read(7'h0B, f);
 000001     check(f == 1, $sformatf("(c) blocked on a word the host rewrote: %0d bytes, expected 1", f));
~000001     if (f == 1) begin
 000001       reg_read(7'h26, f);
 000001       check(f == 8'h5A, $sformatf("(c) byte is %02x, expected 5a", f));
 000001       $display("  (c) blocked on a word the host rewrote, running: %02x", f);
            end
 000001     reg_read(7'h04, f);
 000001     check(f == 8'h00, "(c) a flag changed");
        
            // (b) stopped, word 0 becomes SET OSR, 0x44; restart
 000001     reg_write(7'h00, 8'h00);
 000001     pm_write(64 + 0, 16'h9440);
 000001     reg_write(7'h00, 8'h22);
 000001     expect_rx("(b) first word rewritten, then restart", 8'h44, 3);
        
 000001     if (errors == 0) begin
 000001       $display("PASS");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          initial begin
            #5ms;
            $fatal(1, "time limit");
          end
        endmodule
        
