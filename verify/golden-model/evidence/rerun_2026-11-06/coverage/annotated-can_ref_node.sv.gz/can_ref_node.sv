//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // Reference classic-CAN node for tb_can, written from ISO 11898-1:2015 / Bosch CAN 2.0A, not
        // from the RTL. Behavioural: it runs on its own time quanta (16 per bit, sample point after 12,
        // SJW 4) derived from a nominal bit time and a clock error in ppm, so it drifts against the chip.
        //
        // Implemented: hard sync on recessive-to-dominant in bus idle; resync with SJW on
        // recessive-to-dominant edges (not while this node sends dominant); bit stuffing (SOF..CRC,
        // 5 equal bits); CRC-15 (x^15+x^14+x^10+x^8+x^7+x^4+x^3+1); bitwise arbitration over the
        // identifier and RTR; ACK; stuff, bit, form, CRC and ACK errors with active/passive error flags,
        // the error delimiter, intermission and suspend transmission; TEC/REC with fault-confinement
        // rules 1-10 (rule 3b and overload frames are not modelled; rule-6 counting as in the RTL's D68
        // reading of ISO: 14 / 8 dominant bits); bus-off and recovery after 128 x 11 recessive bits.
        // Automatic retransmission of the frame in tx_q[0] until it is sent.
        //
        // Test hooks: `ack_en` (0 = never acknowledge), `crc_corrupt` (flip the next transmitted CRC's
        // last bit), `skip_stuff_at` (drop the stuff bit after this transmitted-bit index), `form_corrupt`
        // (send a dominant CRC delimiter), each one shot.
        module can_ref_node #(parameter string NAME = "ref") (
 001945     input  wire  rx,     // the bus as this node's transceiver reports it
 000751     output logic tx = 1  // this node's TXD
        );
          // ---- configuration ----
 000001   real    bit_ns = 2000.0;
 000001   real    ppm = 0.0;
 000010   bit     enabled = 0;
~000002   bit     ack_en = 1;
~000001   bit     crc_corrupt = 0, form_corrupt = 0;
 000001   int     skip_stuff_at = -1;
~000001   bit     r0_bit = 0;   // test hook: send r0 recessive
~000002   bit     tx_ext = 0;
          localparam int TQ = 16, SAMPLE = 12, SJW = 4;
        
          // ---- frames ----
          // a frame: [79:69] ID, [68] RTR, [67:64] DLC, [63:0] data (byte b is [63-8*b -: 8])
          // [98] IDE (extended frame), [97:80] extended ID bits 17..0 (CAN 2.0B)
          typedef logic [98:0] frame_t;
          frame_t tx_q[$];
          frame_t rx_frames[$];       // frames received without error (own frames not included)
 000001   int     n_sent = 0, n_err_flags = 0, n_arb_lost = 0;
 000001   int     tec = 0, rec = 0;
~000001   bit     busoff = 0;
 000091   function automatic bit passive();
~000091     return tec >= 128 || rec >= 128;
          endfunction
        
          // ---- bit timing ----
 000001   int tqc = 0;
 001946   bit rx_prev = 1, sampled_bit = 1, drv_dom = 0;
          // ---- protocol state ----
          typedef enum {S_INTEG, S_IDLE, S_FRAME, S_EFLAG, S_EDELIM, S_BUSOFF} st_t;
 000001   st_t st = S_INTEG;
 000001   int  recessive_run = 0, idle_bits = 0, susp = 0;
 000010   bit  after_frame = 0;
          // frame being sent/received
          logic fbits[$];        // the frame's destuffed bits up to the end of the CRC (transmitter)
 000001   int  fpos = 0;         // destuffed bit index (SOF = 0)
 000001   int  tpos = 0;         // line bit index in this frame
 000037   bit  transmitting = 0, sending_tx = 0; // this node started the frame / still owns it
 001726   bit  stuff_next = 0, last_lvl = 1;
 000001   int  run = 0;
 000091   bit  in_tail = 0;
 000001   int  tail_i = 0;
 000751   bit  cur_bit = 1;       // what this node sends in the current bit
 000264   bit  cur_is_stuff = 0;
~000001   logic [14:0] crc = 0;
          logic rbits[$];        // destuffed received bits
 000001   int  dlc_n = -1, crc_end = -1;
~000002   bit  crc_ok_rx = 0;
          // error frame
 000001   int  ef_cnt = 0, ef_eq = 0, ed_cnt = 0, dom_after = 0;
~000052   bit  ef_passive = 0, ef_prev = 0, first_after = 0, ack_exc = 0, ef_tx = 0;
 000001   int  boff_seq = 0, boff_run = 0;
        
          // back to power-on: counters, queues, integration
 000011   function automatic void reset_node();
 000011     tx_q.delete(); rx_frames.delete();
 000011     tec = 0; rec = 0; busoff = 0; st = S_INTEG; recessive_run = 0; idle_bits = 0; susp = 0;
 000011     n_sent = 0; n_err_flags = 0; n_arb_lost = 0; enabled = 0; ack_en = 1;
 000011     crc_corrupt = 0; form_corrupt = 0; skip_stuff_at = -1; r0_bit = 0; tx = 1; drv_dom = 0;
          endfunction
        
 007434   function automatic logic [14:0] crc_step(input logic [14:0] c, input logic b);
 007434     logic fb;
 007434     fb = b ^ c[14];
 007434     crc_step = {c[13:0], 1'b0} ^ (fb ? 15'h4599 : 15'h0);
          endfunction
        
          // the destuffed bits SOF..CRC of a frame
 000040   function automatic void build(input frame_t f);
 000040     logic [14:0] c;
 000040     int n;
 000040     fbits.delete();
 000040     tx_ext = f[98];   // the arbitration field runs to RTR: bit 12, or bit 32 when extended
 000040     fbits.push_back(0);
 000440     for (int i = 10; i >= 0; i--) fbits.push_back(f[69 + i]);
~000034     if (f[98]) begin   // CAN 2.0B: SRR, IDE, ID 17..0, then RTR, r1
~000006       fbits.push_back(1);
~000006       fbits.push_back(1);
~000108       for (int i = 17; i >= 0; i--) fbits.push_back(f[80 + i]);
            end
 000040     fbits.push_back(f[68]);
 000040     fbits.push_back(0);        // IDE (standard) or r1 (extended): dominant
 000040     fbits.push_back(r0_bit);   // r0: receivers must accept either level
 000160     for (int i = 3; i >= 0; i--) fbits.push_back(f[64 + i]);
~000040     n = f[68] ? 0 : (f[67:64] > 8 ? 8 : f[67:64]);
 001040     for (int b = 0; b < n * 8; b++) fbits.push_back(f[63 - b]);
 000040     c = 0;
~001920     foreach (fbits[i]) c = crc_step(c, fbits[i]);
~000039     if (crc_corrupt) begin
~000001       c[0] = !c[0];
~000001       crc_corrupt = 0;
            end
 000600     for (int i = 14; i >= 0; i--) fbits.push_back(c[i]);
          endfunction
        
~000052   function automatic void start_error(input bit is_tx_err, input bit ack_error);
~000052     n_err_flags++;
~000052     ef_tx = is_tx_err;
~000052     ef_passive = passive();              // the flag of the state the error was detected in
~000052     ack_exc = is_tx_err && ack_error && ef_passive;
~000049     if (is_tx_err) begin
~000003       if (!ack_exc) tec += 8;
~000049     end else rec = rec >= 255 ? 255 : rec + 1;
~000052     if (tec > 255) begin
%000000       st = S_BUSOFF; busoff = 1; boff_seq = 0; boff_run = 0;
%000000       return;
            end
~000052     st = S_EFLAG; ef_cnt = 0; ef_eq = 0;
~000052     in_tail = 0;
          endfunction
        
          // called at the start of every bit (time quantum 0)
 013919   function automatic void bit_start();
 013919     drv_dom = 0;
 013919     cur_is_stuff = 0;
 013919     cur_bit = 1;
 013919     case (st)
 005341       S_IDLE: begin
~005302         if (enabled && tx_q.size() > 0 && !busoff && idle_bits >= (after_frame ? 3 : 11) + susp) begin
                  // start a frame: SOF
 000039           build(tx_q[0]);
 000039           st = S_FRAME; transmitting = 1; sending_tx = 1; fpos = 0; tpos = 0;
 000039           stuff_next = 0; run = 0; last_lvl = 1; in_tail = 0; rbits.delete();
 000039           dlc_n = -1; crc_end = -1; crc = 0;
 000039           cur_bit = 0;
                end
              end
 007746       S_FRAME: begin
 000781         if (in_tail) begin
 000781           tail_i++;
                  // 0 CRC delim, 1 ACK, 2 ACK delim, 3..9 EOF
 000781           cur_bit = 1;
~000781           if (tail_i == 0 && form_corrupt && sending_tx) begin cur_bit = 0; form_corrupt = 0; end
~000748           if (tail_i == 1 && !sending_tx && crc_ok_rx && ack_en) cur_bit = 0;
 000264         end else if (stuff_next) begin
 000264           cur_is_stuff = 1;
 000264           cur_bit = !last_lvl;
~000264           if (sending_tx && skip_stuff_at >= 0 && fpos - 1 == skip_stuff_at) begin
~000001             cur_bit = last_lvl;          // the injected stuff error: no stuff bit
~000001             skip_stuff_at = -1;
                  end
 000171           if (!sending_tx) cur_bit = 1;
~004307         end else if (sending_tx && fpos < fbits.size()) cur_bit = fbits[fpos];
 004307         else cur_bit = 1;
~007746         if (tpos == 0) cur_bit = sending_tx ? 0 : 1;   // SOF (already being sent)
              end
~000312       S_EFLAG: cur_bit = ef_passive;
 000520       default: cur_bit = 1;
            endcase
~013919     if (busoff) cur_bit = 1;
 013919     drv_dom = !cur_bit;
 013919     tx = cur_bit;
          endfunction
        
          // called at the sample point of every bit
 013970   function automatic void sample(input bit b);
 013970     case (st)
 000110       S_INTEG: begin
~000110         recessive_run = b ? recessive_run + 1 : 0;
 000100         if (recessive_run >= 11) begin st = S_IDLE; idle_bits = 11; after_frame = 0; end
              end
~009773       S_IDLE: idle_bits = b ? idle_bits + 1 : 0;
 007871       S_FRAME: frame_sample(b);
~000312       S_EFLAG: begin
~000312         if (!ef_passive) begin
~000312           if (b) begin
%000000             if (ef_tx) tec += 8; else rec = rec + 8 > 255 ? 255 : rec + 8;
                  end
~000312           ef_cnt++;
~000260           if (ef_cnt == 6) begin st = S_EDELIM; ed_cnt = 0; dom_after = 6; first_after = 1; end
%000000         end else begin
%000000           if (ack_exc && !b) begin tec += 8; ack_exc = 0; end
%000000           ef_eq = (ef_cnt > 0 && b == ef_prev) ? ef_eq + 1 : 1;
%000000           ef_prev = b;
%000000           ef_cnt++;
%000000           if (ef_eq == 6) begin st = S_EDELIM; ed_cnt = 0; dom_after = 0; first_after = 1; end
                end
~000312         if (tec > 255) begin st = S_BUSOFF; busoff = 1; boff_seq = 0; boff_run = 0; end
              end
~000417       S_EDELIM: begin
~000416         if (ed_cnt == 0 && !b) begin
                  // still waiting for the first recessive bit
~000001           if (first_after && !ef_tx) rec = rec + 8 > 255 ? 255 : rec + 8;
~000001           dom_after++;
~000001           if (dom_after == (ef_passive ? 8 : 14)) begin
%000000             if (ef_tx) tec += 8; else rec = rec + 8 > 255 ? 255 : rec + 8;
%000000             dom_after = ef_passive ? 0 : 6;
                  end
~000416         end else if (b) begin
~000416           ed_cnt++;
~000364           if (ed_cnt == 8) begin
~000052             st = S_IDLE; idle_bits = 0; after_frame = 1; susp = (ef_tx && passive()) ? 8 : 0;
                  end
%000000         end else start_error(ef_tx, 0);   // form error in the delimiter
~000417         first_after = 0;
~000417         if (tec > 255) begin st = S_BUSOFF; busoff = 1; boff_seq = 0; boff_run = 0; end
              end
%000000       S_BUSOFF: begin
%000000         boff_run = b ? boff_run + 1 : 0;
%000000         if (boff_run == 11) begin
%000000           boff_run = 0;
%000000           boff_seq++;
%000000           if (boff_seq == 128) begin
%000000             busoff = 0; tec = 0; rec = 0; st = S_IDLE; idle_bits = 11; after_frame = 0; susp = 0;
                  end
                end
              end
%000000       default: ;
            endcase
          endfunction
        
 007871   function automatic void frame_sample(input bit b);
 007871     bit role_tx;
 007871     int dl;
 007871     role_tx = sending_tx;
~007090     if (in_tail) begin
%000000       case (tail_i)
~000090         0: if (!b) begin start_error(role_tx, 0); return; end
~000089         1: if (role_tx && b) begin start_error(1, 1); return; end
 000073         2: begin
~000073           if (!b) begin start_error(role_tx, 0); return; end
~000073           if (!role_tx && !crc_ok_rx) begin start_error(0, 0); return; end
                end
%000000         9: begin
~000073           if (!b && role_tx) begin start_error(1, 0); return; end
                  // the frame is over
 000037           if (role_tx) begin
 000036             n_sent++;
 000036             void'(tx_q.pop_front());
~000033             if (tec > 0) tec--;
 000037           end else begin
~000030             if (rec > 127) rec = 119; else if (rec > 0) rec--;
 000037             rx_frames.push_back(decode());
                  end
~000073           st = S_IDLE; idle_bits = 0; after_frame = 1; susp = (role_tx && passive()) ? 8 : 0;
%000000           transmitting = 0; sending_tx = 0;
%000000           return;
                end
~000438         default: if (!b) begin start_error(role_tx, 0); return; end
              endcase
%000000       return;
            end
~007871     if (tpos == 0 && b) begin st = S_IDLE; return; end   // not a start of frame
~006826     if (cur_is_stuff) begin
~000230       if (b == last_lvl) begin start_error(role_tx, 0); return; end   // stuff error
%000000       last_lvl = b; run = 1; stuff_next = 0;
%000000       tpos++;
%000000       return;
            end
            // a data bit: arbitration (identifier and RTR: destuffed bits 1..12), bit error
~006825     if (sending_tx && cur_bit != b) begin
~000001       if (fpos >= 1 && fpos <= (tx_ext ? 32 : 12) && cur_bit == 1 && b == 0) begin
~000001         sending_tx = 0;   // lost arbitration: receive from here
~000001         n_arb_lost++;
%000000       end else begin start_error(1, 0); return; end
            end
 007871     rbits.push_back(b);
 007871     run = (b == last_lvl) ? run + 1 : 1;
 007871     last_lvl = b;
 007871     fpos++;
 007871     tpos++;
 007499     if (rbits.size() == (rbits.size() > 13 && rbits[13] ? 39 : 19)) begin
              // header complete: SOF ID(11) RTR IDE r0 DLC(4)
 000119       if (rbits[13]) begin   // extended: RTR at 32, DLC at 35..38
 000005         dl = {rbits[35], rbits[36], rbits[37], rbits[38]};
~000005         dlc_n = rbits[32] ? 0 : (dl > 8 ? 8 : dl);
 000005         crc_end = 39 + 8 * dlc_n + 15;
 000119       end else begin
 000119         dl = {rbits[15], rbits[16], rbits[17], rbits[18]};
~000119         dlc_n = rbits[12] ? 0 : (dl > 8 ? 8 : dl);
 000119         crc_end = 19 + 8 * dlc_n + 15;
              end
            end
~006999     if (crc_end > 0 && rbits.size() == crc_end) begin
%000000       logic [14:0] c;
%000000       c = 0;
~005514       foreach (rbits[i]) c = crc_step(c, rbits[i]);   // over the frame and its CRC: 0 if good
%000000       crc_ok_rx = c == 0;
              // a stuff bit may still follow the last CRC bit
%000000       stuff_next = run == 5;
~000091       if (!stuff_next) begin in_tail = 1; tail_i = -1; end
%000000       return;
            end
 007871     stuff_next = run == 5;
          endfunction
        
 000037   function automatic frame_t decode();
 000037     frame_t f;
 000037     f[79:69] = 0;
 000407     for (int i = 1; i <= 11; i++) f[80 - i] = rbits[i];
 000037     f[98:80] = 0;
~000037     if (rbits[13]) begin
~000001       f[98] = 1;
~000018       for (int i = 0; i < 18; i++) f[97 - i] = rbits[14 + i];
~000001       f[68] = rbits[32];
~000001       f[67:64] = {rbits[35], rbits[36], rbits[37], rbits[38]};
~000001       f[63:0] = 0;
~000008       for (int b = 0; b < dlc_n * 8; b++) f[63 - b] = rbits[39 + b];
 000037     end else begin
 000037       f[68] = rbits[12];
 000037       f[67:64] = {rbits[15], rbits[16], rbits[17], rbits[18]};
 000037       f[63:0] = 0;
 001040       for (int b = 0; b < dlc_n * 8; b++) f[63 - b] = rbits[19 + b];
            end
 000037     return f;
          endfunction
        
          // after a stuff bit that followed the last CRC bit, the tail begins
 007746   function automatic void after_stuff_check();
~007746     if (st == S_FRAME && !in_tail && crc_end > 0 && rbits.size() == crc_end && !stuff_next) begin
~000001       in_tail = 1; tail_i = -1;
            end
          endfunction
        
          // ---- the time-quantum loop ----
 001862   bit fall;
 244541   always begin
 244541     #(bit_ns * (1.0 + ppm * 1.0e-6) / TQ);
 223373     if (enabled) begin
~223373       fall = rx_prev && !rx;
 223373       rx_prev = rx;
~223287       if (fall && st == S_IDLE) begin
                // hard synchronization: this quantum is the sync segment of a start of frame
 000086         st = S_FRAME;
~000085         if (!(enabled && tx_q.size() > 0 && !busoff && idle_bits >= (after_frame ? 3 : 11) + susp)) begin
 000085           transmitting = 0; sending_tx = 0;
~000001         end else begin
~000001           build(tx_q[0]);   // a pending frame joins: its SOF coincides with this one
~000001           transmitting = 1; sending_tx = 1;
                end
 000086         fpos = 0; tpos = 0; stuff_next = 0; run = 0; last_lvl = 1; in_tail = 0; rbits.delete();
 000086         dlc_n = -1; crc_end = -1;
 000086         tqc = 1;
~000086         cur_bit = sending_tx ? 0 : 1;
~000086         drv_dom = !cur_bit;
 000086         tx = cur_bit;
 223287       end else begin
~222223         if (fall && !drv_dom && st != S_IDLE && tqc != 0) begin
                  // resynchronization, phase error limited to SJW
                  // late edge (before the sample point): lengthen phase segment 1 by the phase error,
                  // at most SJW; the edge then counts as the end of the sync segment (quantum 1)
~000111           if (tqc <= SAMPLE) tqc = (tqc <= SJW) ? 1 : tqc - SJW;
~000979           else if (TQ - tqc <= SJW) tqc = TQ;                     // early edge: next bit now
%000000           else tqc = tqc + SJW;
                end
 209369         if (tqc == TQ) tqc = 0;
 209368         if (tqc == 0) begin
 007521           if (st == S_FRAME && stuff_next == 0) after_stuff_check();
 013919           bit_start();
                end
 209317         if (tqc == SAMPLE) begin
 013970           sampled_bit = rx;
 013706           if (st == S_FRAME && cur_is_stuff) begin
 000264             sample(rx);
 000264             after_stuff_check();
 013706           end else sample(rx);
                end
 223287         tqc++;
              end
 221036     end else begin
 221036       tx = 1;
 221036       rx_prev = rx;
            end
          end
        endmodule
        
