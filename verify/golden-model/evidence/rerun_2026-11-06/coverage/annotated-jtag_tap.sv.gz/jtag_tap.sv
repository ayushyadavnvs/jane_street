//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // An IEEE 1149.1 test access port, written from the standard (not from jtag.pbe), for tb_debug.
        //
        // - The 16-state TAP controller, advanced by TMS at every rising edge of TCK; Test-Logic-Reset
        //   at power-up (there is no TRST*).
        // - Instruction register of IRLEN bits; Capture-IR loads ...0001 (1149.1 7.1.1: the two least
        //   significant bits are 01). Test-Logic-Reset selects IDCODE (the device has one, 1149.1 7.2.1).
        // - Instructions: IDCODE (32-bit device identification, bit 0 = 1), USER (a 32-bit data
        //   register: Capture-DR loads it, Update-DR writes it), BYPASS (all ones, 1 bit, captures 0);
        //   every other opcode selects BYPASS (1149.1 8.4.1: unused opcodes are BYPASS).
        // - Capture and shift happen at the rising edge of TCK in Capture-xR and Shift-xR; Update-xR
        //   latches at the falling edge; TDO changes at the falling edge (after TCO ns) and is driven
        //   only in Shift-DR and Shift-IR (1149.1 4.5.1), high-impedance otherwise.
        module jtag_tap #(
            parameter int          IRLEN   = 4,
            parameter logic [31:0] IDCODE  = 32'h4BA00477,
            parameter logic [31:0] USER0   = 32'h00000000,   // the USER register after power-up
            parameter logic [IRLEN-1:0] I_IDCODE = 'b1110,
            parameter logic [IRLEN-1:0] I_USER   = 'b1010,
            parameter real         TCO     = 8.0
        ) (
 000883     input  logic tck,
 000065     input  logic tms,
 000116     input  logic tdi,
 000120     output logic tdo,      // the value, meaningful while tdo_en
 000029     output logic tdo_en
        );
          typedef enum logic [3:0] {
            TLR, RTI, SEL_DR, CAP_DR, SH_DR, EX1_DR, PAU_DR, EX2_DR, UPD_DR,
            SEL_IR, CAP_IR, SH_IR, EX1_IR, PAU_IR, EX2_IR, UPD_IR
          } state_t;
        
 000099   state_t state = TLR;
~000012   logic [IRLEN-1:0] ir = I_IDCODE, ir_sr = '0;
~000111   logic [31:0] user = USER0, dr_sr = '0;
 000001   int unsigned updates_dr = 0, updates_ir = 0;
        
 000883   function automatic state_t next(input state_t s, input logic m);
 000883     case (s)
~000756       TLR:    return m ? TLR    : RTI;
~000756       RTI:    return m ? SEL_DR : RTI;
~000756       SEL_DR: return m ? SEL_IR : CAP_DR;
~000756       CAP_DR: return m ? EX1_DR : SH_DR;
~000756       SH_DR:  return m ? EX1_DR : SH_DR;
~000756       EX1_DR: return m ? UPD_DR : PAU_DR;
~000756       PAU_DR: return m ? EX2_DR : PAU_DR;
~000756       EX2_DR: return m ? UPD_DR : SH_DR;
~000756       UPD_DR: return m ? SEL_DR : RTI;
~000756       SEL_IR: return m ? TLR    : CAP_IR;
~000756       CAP_IR: return m ? EX1_IR : SH_IR;
~000756       SH_IR:  return m ? EX1_IR : SH_IR;
~000756       EX1_IR: return m ? UPD_IR : PAU_IR;
~000756       PAU_IR: return m ? EX2_IR : PAU_IR;
~000756       EX2_IR: return m ? UPD_IR : SH_IR;
~000756       default: return m ? SEL_DR : RTI;  // UPD_IR
            endcase
          endfunction
        
          // the data register the current instruction selects: its length
 000660   function automatic int dr_len();
~000436     if (ir == I_IDCODE || ir == I_USER) return 32;
 000660     return 1;  // BYPASS
          endfunction
        
 000883   always @(posedge tck) begin
~000883     case (state)
        // [FSM coverage]
 000023        // [fsm_state tb_debug.u_tap_a.state::CAP_DR]
 000006        // [fsm_state tb_debug.u_tap_a.state::CAP_IR]
 000023        // [fsm_state tb_debug.u_tap_a.state::EX1_DR]
 000006        // [fsm_state tb_debug.u_tap_a.state::EX1_IR]
%000000        // [fsm_state tb_debug.u_tap_a.state::EX2_DR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_a.state::EX2_IR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_a.state::PAU_DR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_a.state::PAU_IR] *** UNCOVERED ***
 000035        // [fsm_state tb_debug.u_tap_a.state::RTI]
 000035        // [fsm_state tb_debug.u_tap_a.state::SEL_DR]
 000012        // [fsm_state tb_debug.u_tap_a.state::SEL_IR]
 000023        // [fsm_state tb_debug.u_tap_a.state::SH_DR]
 000006        // [fsm_state tb_debug.u_tap_a.state::SH_IR]
 000006        // [fsm_state tb_debug.u_tap_a.state::TLR]
 000022        // [fsm_state tb_debug.u_tap_a.state::UPD_DR]
 000006        // [fsm_state tb_debug.u_tap_a.state::UPD_IR]
 000023        // [fsm_state tb_debug.u_tap_b.state::CAP_DR]
 000006        // [fsm_state tb_debug.u_tap_b.state::CAP_IR]
 000023        // [fsm_state tb_debug.u_tap_b.state::EX1_DR]
 000006        // [fsm_state tb_debug.u_tap_b.state::EX1_IR]
%000000        // [fsm_state tb_debug.u_tap_b.state::EX2_DR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_b.state::EX2_IR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_b.state::PAU_DR] *** UNCOVERED ***
%000000        // [fsm_state tb_debug.u_tap_b.state::PAU_IR] *** UNCOVERED ***
 000035        // [fsm_state tb_debug.u_tap_b.state::RTI]
 000035        // [fsm_state tb_debug.u_tap_b.state::SEL_DR]
 000012        // [fsm_state tb_debug.u_tap_b.state::SEL_IR]
 000023        // [fsm_state tb_debug.u_tap_b.state::SH_DR]
 000006        // [fsm_state tb_debug.u_tap_b.state::SH_IR]
 000006        // [fsm_state tb_debug.u_tap_b.state::TLR]
 000022        // [fsm_state tb_debug.u_tap_b.state::UPD_DR]
 000006        // [fsm_state tb_debug.u_tap_b.state::UPD_IR]
~000562       CAP_DR: dr_sr <= (ir == I_IDCODE) ? IDCODE : (ir == I_USER) ? user : 32'd0;
 000660       SH_DR:  dr_sr <= (dr_sr >> 1) | (32'(tdi) << (dr_len() - 1));
 000006       CAP_IR: ir_sr <= IRLEN'(1);
 000032       SH_IR:  ir_sr <= {tdi, ir_sr[IRLEN-1:1]};
 000162       default: ;
            endcase
 000883     state <= next(state, tms);
          end
        
 000883   always @(negedge tck) begin
 000883     case (state)
~000022       UPD_DR: begin if (ir == I_USER) user <= dr_sr; updates_dr++; end
 000006       UPD_IR: begin ir <= ir_sr; updates_ir++; end
 000023       TLR:    ir <= I_IDCODE;
 000832       default: ;
            endcase
 000883     tdo    <= #(TCO) (state == SH_IR) ? ir_sr[0] : dr_sr[0];
 000883     tdo_en <= #(TCO) (state == SH_DR || state == SH_IR);
          end
        
 000001   initial begin
 000001     tdo = 1'b1;
 000001     tdo_en = 1'b0;
          end
        endmodule
        
