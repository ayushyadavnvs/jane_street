`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_cs_n;
  reg [0:0] PI_mosi;
  reg [0:0] PI_sck;
  wire [0:0] PI_clk = clock;
  reg [2:0] PI_mosi_hi;
  reg [7:0] PI_rd_data;
  reg [0:0] PI_quad_req;
  pbe_host_spi UUT (
    .rst_n(PI_rst_n),
    .cs_n(PI_cs_n),
    .mosi(PI_mosi),
    .sck(PI_sck),
    .clk(PI_clk),
    .mosi_hi(PI_mosi_hi),
    .rd_data(PI_rd_data),
    .quad_req(PI_quad_req)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$773  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$791  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$809  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$821  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$845  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$851  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$857  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$863  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$759  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$765  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$771  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$777  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$783  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$789  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$795  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$801  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$807  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$813  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$819  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$825  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$831  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$837  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$843  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$849  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$855  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$861  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$867  = 1'b1;
    // UUT.$past$host_formal.\sv:200$1$0  = 1'b0;
    // UUT.$past$host_formal.\sv:203$2$0  = 1'b0;
    // UUT.$past$host_formal.\sv:204$3$0  = 1'b0;
    UUT._witness_.anyinit_procdff_679 = 1'b0;
    UUT._witness_.anyinit_procdff_684 = 1'b0;
    UUT._witness_.anyinit_procdff_689 = 7'b0000000;
    UUT._witness_.anyinit_procdff_694 = 1'b0;
    UUT._witness_.anyinit_procdff_699 = 7'b0000000;
    UUT._witness_.anyinit_procdff_704 = 8'b00000000;
    UUT._witness_.anyinit_procdff_709 = 1'b0;
    UUT._witness_.anyinit_procdff_714 = 7'b0000000;
    UUT._witness_.anyinit_procdff_719 = 1'b0;
    UUT._witness_.anyinit_procdff_724 = 3'b000;
    UUT._witness_.anyinit_procdff_729 = 8'b00000000;
    UUT._witness_.anyinit_procdff_734 = 8'b00000000;
    UUT._witness_.anyinit_procdff_739 = 1'b0;
    UUT._witness_.anyinit_procdff_744 = 1'b0;
    UUT._witness_.anyinit_procdff_749 = 2'b00;
    UUT._witness_.anyinit_procdff_754 = 3'b000;
    UUT.f_address = 7'b0000000;
    UUT.f_bit = 3'b000;
    UUT.f_command = 1'b0;
    UUT.f_expected_addr = 7'b0000000;
    UUT.f_expected_data = 8'b00000000;
    UUT.f_expected_rd = 1'b0;
    UUT.f_expected_wr = 1'b0;
    UUT.f_past_valid = 1'b0;
    UUT.f_prev_cs = 1'b1;
    UUT.f_prev_sck = 1'b0;
    UUT.f_read_shift = 4'b0000;
    UUT.f_read_wait = 2'b00;
    UUT.f_read_word = 8'b00000000;
    UUT.f_received = 8'b00000000;
    UUT.f_stable = 3'b111;
    UUT.f_write = 1'b0;

    // state 0
    PI_rst_n = 1'b0;
    PI_cs_n = 1'b1;
    PI_mosi = 1'b0;
    PI_sck = 1'b0;
    PI_mosi_hi = 3'b000;
    PI_rd_data = 8'b00000000;
    PI_quad_req = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_rst_n <= 1'b1;
      PI_cs_n <= 1'b1;
      PI_mosi <= 1'b0;
      PI_sck <= 1'b0;
      PI_mosi_hi <= 3'b000;
      PI_rd_data <= 8'b00000000;
      PI_quad_req <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_rst_n <= 1'b1;
      PI_cs_n <= 1'b0;
      PI_mosi <= 1'b0;
      PI_sck <= 1'b0;
      PI_mosi_hi <= 3'b000;
      PI_rd_data <= 8'b00000000;
      PI_quad_req <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_rst_n <= 1'b1;
      PI_cs_n <= 1'b0;
      PI_mosi <= 1'b1;
      PI_sck <= 1'b1;
      PI_mosi_hi <= 3'b010;
      PI_rd_data <= 8'b00000000;
      PI_quad_req <= 1'b0;
    end

    // state 4
    if (cycle == 3) begin
      PI_rst_n <= 1'b1;
      PI_cs_n <= 1'b1;
      PI_mosi <= 1'b0;
      PI_sck <= 1'b1;
      PI_mosi_hi <= 3'b000;
      PI_rd_data <= 8'b00000000;
      PI_quad_req <= 1'b0;
    end

    // state 5
    if (cycle == 4) begin
      PI_rst_n <= 1'b1;
      PI_cs_n <= 1'b1;
      PI_mosi <= 1'b0;
      PI_sck <= 1'b1;
      PI_mosi_hi <= 3'b000;
      PI_rd_data <= 8'b00000000;
      PI_quad_req <= 1'b0;
    end

    genclock <= cycle < 5;
    cycle <= cycle + 1;
  end
endmodule
