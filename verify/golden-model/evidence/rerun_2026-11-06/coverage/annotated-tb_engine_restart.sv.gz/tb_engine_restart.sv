//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // Unit test (BUG-012): when restart arrives in the same cycle an instruction completes,
        // the instruction must have no side effects (no FIFO pop or push, no flag change, no IRQ).
        module tb_engine_restart;
~000013   logic clk = 0, rst_n = 0, restart = 0;
 000026   always #5 clk = ~clk;
~000002   logic [15:0] instr;
~000005   logic [6:0]  pc;
%000000   logic [7:0]  pins_out, pins_oe, rx_data;
~000001   logic [3:0]  flag_set, flag_clr;
 000001   logic        tx_pop, rx_push, irq;
 000001   int errors = 0;
        
          pbe_engine dut (
              .clk, .rst_n,
              .run(1'b1), .restart,
              .clkdiv(16'd0), .pin_base(3'd0), .jmp_pin(3'd0),
              .out_msb_first(1'b0), .in_msb_first(1'b0), .start_pc(7'd0),
              .crc_poly(16'h0), .crc_cfg(8'h0), .timeout(16'h0), .line_cfg(8'h0),
              .coder_cfg(8'h0), .coder_cfg2(8'h0), .sync(8'h0), .crc_good(16'h0),
              .host_crc_init(1'b0), .host_tmo_clr(1'b0), .host_ovf_clr(1'b0), .host_lerr_clr(1'b0),
              .host_arb_clr(1'b0), .host_berr_clr(1'b0), .host_sent_clr(1'b0),
              .status(), .crc_now(), .can_tec(), .can_rec(), .can_state(),
        
              .pc, .instr,
              .pins_in(8'h00), .pins_out, .pins_oe,
              .tx_data(8'h5A), .tx_empty(1'b0), .tx_pop, .tx_mark(), .tx_rewind(),
              .rx_data, .rx_full(1'b0), .rx_push,
              .flags(4'h0), .flag_set, .flag_clr, .irq
          );
        
 000005   task automatic try(input logic [15:0] word, input string name);
 000005     instr = word;
 000005     @(negedge clk);
 000005     restart = 1;
 000005     #1;  // combinational strobes settle while restart is high
~000005     if (tx_pop || rx_push || flag_set != 0 || flag_clr != 0 || irq) begin
%000000       errors++;
%000000       $display("  FAIL: %s had side effects during restart (pop %b push %b set %b clr %b irq %b)",
%000000                name, tx_pop, rx_push, flag_set, flag_clr, irq);
            end
 000005     @(negedge clk);
 000005     restart = 0;
          endtask
        
 000001   initial begin
 000003     repeat (3) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000001     try(16'hA000, "PULL");
 000001     try(16'hB000, "PUSH");
 000001     try(16'hC000, "FLAG 0, SET");
 000001     try(16'hC800, "FLAG 0, CLR");
 000001     try(16'hD000, "FLAG 0, IRQ");
 000001     if (errors == 0) begin
 000001       $display("PASS: restart suppresses instruction side effects");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        endmodule
        
