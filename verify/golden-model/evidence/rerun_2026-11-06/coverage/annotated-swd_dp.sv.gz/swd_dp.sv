//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // An ARM ADIv5 SW-DP target (with the SWJ-DP JTAG-to-SWD switch and one MEM-AP-like access
        // port), written from the ADIv5.2 specification (IHI 0031), not from swd.pbe, for tb_debug.
        //
        // Wire protocol (ADIv5.2 B4.2), sampled at the rising edge of SWCLK; the target drives SWDIO
        // after a rising edge (TCO ns later):
        //   Request: Start (1), APnDP, RnW, A[2], A[3], Parity (even, over the 4 bits), Stop (0), Park (1)
        //   Trn (1 cycle), ACK[0..2] (OK = 1,0,0  WAIT = 0,1,0  FAULT = 0,0,1), then
        //   read OK:  RDATA[0..31], Parity, Trn            write OK: Trn, WDATA[0..31], Parity
        //   WAIT or FAULT: Trn, and no data phase (overrun detection, CTRL/STAT.ORUNDETECT, is not
        //   modelled: it stays 0).
        // Line reset: 50 or more cycles with SWDIO high; the next request needs 2 idle (low) cycles
        // first, and after a line reset the first request must read DPIDR (B4.3.3: otherwise a protocol
        // error). A protocol error (bad parity, stop or park in a request, or the above) makes the
        // target not respond (the host sees ACK = 1,1,1) until the next line reset (B4.2.5).
        // SWJ-DP (B5.2): the port starts in JTAG mode, where it ignores SWD; 50 or more ones followed by
        // the 16-bit sequence 0xE79E (LSB first) select SWD, which then needs a line reset. The port
        // watches for the sequence in SWD mode too (sending it again keeps SWD): a request read from
        // those 16 bits is ignored without counting a protocol error.
        //
        // Registers (DPv1): DP 0x0 R DPIDR, W ABORT; 0x4 CTRL/STAT; 0x8 W SELECT, R RESEND; 0xC R RDBUFF.
        //   CTRL/STAT: [5] STICKYERR, [7] WDATAERR, [28] CDBGPWRUPREQ -> [29] ACK,
        //   [30] CSYSPWRUPREQ -> [31] ACK. ABORT: [2] STKERRCLR, [3] WDERRCLR (others clear what they
        //   name or do nothing here). SELECT: [31:24] APSEL, [7:4] APBANKSEL.
        //   While STICKYERR or WDATAERR is set every access gets FAULT except a DPIDR read, a CTRL/STAT
        //   read and an ABORT write (B4.2.2). A write whose data parity is wrong is not done and sets
        //   WDATAERR (B4.2.4).
        //   AP 0 (APSEL = 0): 0x00 CSW, 0x04 TAR, 0x0C DRW (reads and writes mem[TAR[5:2]]), 0xFC IDR.
        //   AP reads are posted (B2.2.2): an AP read returns the result of the previous AP read, and its
        //   own result is in RDBUFF.
        // Test controls (set by the testbench): wait_n gives WAIT to the next wait_n AP accesses (and
        // RDBUFF reads); fault_next makes the next AP access fail (FAULT, STICKYERR set); bad_par_next
        // sends the next read's data with the wrong parity.
        module swd_dp #(
            parameter logic [31:0] DPIDR = 32'h2BA01477,
            parameter logic [31:0] AP_IDR = 32'h24770011,
            parameter real         TCO   = 8.0
        ) (
 003240     input  logic swclk,
 000487     input  logic swdio,     // the line level
 000067     output logic drive,     // the target drives SWDIO
 000236     output logic dout
        );
          typedef enum logic [2:0] {JTAG, LOCKOUT, RESET, IDLE, REQ, XFER} st_t;
 000077   st_t st = JTAG;
        
          // test controls and statistics
 000001   int wait_n = 0;
 000002   bit fault_next = 0, bad_par_next = 0;
 000001   int n_line_reset = 0, n_switch = 0, n_proto_err = 0, n_ok = 0, n_wait = 0, n_fault = 0;
 000001   int n_wdataerr = 0, n_writes = 0;
        
          // registers
~000009   logic [31:0] ctrl = '0, select = '0, rdbuff = '0, last_read = '0;
~000002   logic [31:0] csw = 32'h0300_0002, tar = '0;
          logic [31:0] mem[16];
 000004   bit need_dpidr = 1;
        
          // line state
 000001   int ones = 0;                    // consecutive sampled ones (while the host drives)
 000006   bit sw_armed = 0;                // collecting the 16 bits after >= 50 ones
 000001   int sw_k = 0;
~000002   logic [15:0] sw_seq;
 000001   int idle_zeros = 0;
~000071   logic [7:0] req;
 000001   int k = 0;                       // bit counter in REQ, cycle counter in XFER
 000019   bit apndp, rnw;
 000017   logic [1:0] a;                   // A[3:2]
 000009   logic [2:0] ack;                 // ACK bits, bit 0 first on the wire
~000021   logic [31:0] data;
 000009   logic dpar;
        
 001357   task automatic put(input logic en, input logic v);
 001357     drive <= #(TCO) en;
 001357     dout  <= #(TCO) v;
          endtask
        
 000067   function automatic bit sticky();
 000067     return ctrl[5] || ctrl[7];
          endfunction
        
          // the value a read returns, and its side effects (done when the request is accepted)
 000033   function automatic logic [31:0] do_read();
 000033     logic [31:0] v;
~000025     if (!apndp) begin
%000000       case (a)
 000011         2'd0: v = DPIDR;
 000008         2'd1: v = {ctrl[30], ctrl[30], ctrl[28], ctrl[28], 20'd0, ctrl[7:0]};
%000000         2'd2: v = last_read;   // RESEND
 000006         default: v = rdbuff;   // RDBUFF
              endcase
%000000       last_read = v;
%000000       return v;
            end
 000033     v = rdbuff;                // posted: the previous AP read's result
~000008     if (select[31:24] != 0) rdbuff = 32'd0;
 000008     else case ({select[7:4], a})
%000000       6'h00: rdbuff = csw;
 000002       6'h01: rdbuff = tar;
 000004       6'h03: rdbuff = mem[tar[5:2]];
 000002       6'h3F: rdbuff = AP_IDR;
%000000       default: rdbuff = 32'd0;
            endcase
 000033     last_read = v;
 000033     return v;
          endfunction
        
 000020   task automatic do_write(input logic [31:0] v);
 000020     n_writes++;
 000012     if (!apndp) begin
 000012       case (a)
 000004         2'd0: begin  // ABORT
 000002           if (v[2]) ctrl[5] = 1'b0;
 000002           if (v[3]) ctrl[7] = 1'b0;
                end
 000002         2'd1: ctrl = {v[31:8] & 24'h500000, ctrl[7:0]};  // the power-up requests
 000006         2'd2: select = v;
%000000         default: ;
              endcase
~000008     end else if (select[31:24] == 0) begin
 000008       case ({select[7:4], a})
%000000         6'h00: csw = v;
 000006         6'h01: tar = v;
 000002         6'h03: mem[tar[5:2]] = v;
%000000         default: ;
              endcase
            end
          endtask
        
 000067   function automatic logic [2:0] respond();
 000067     bit ap_like;
 000067     ap_like = apndp || (!apndp && rnw && a == 2'd3);  // AP accesses and RDBUFF reads can stall
~000063     if (sticky() && !(!apndp && rnw && a <= 2'd1) && !(!apndp && !rnw && a == 2'd0)) return 3'b100;
~000065     if (ap_like && wait_n > 0) begin
%000000       wait_n--;
%000000       return 3'b010;
            end
~000067     if (apndp && fault_next) begin
%000000       fault_next = 0;
%000000       ctrl[5] = 1'b1;  // STICKYERR
%000000       return 3'b100;
            end
 000067     return 3'b001;
          endfunction
        
 003240   always @(posedge swclk) begin
 003240     logic b;
 003240     b = swdio;
            // ones counted only while the host drives the line
 001950     if (!(st == XFER && drive)) begin
 001080       if (b) ones++;
 001080       else begin
 001074         if (ones >= 50) begin
 000006           sw_armed = 1;
 000006           sw_k = 0;
                end
 001080         ones = 0;
              end
            end
 003144     if (sw_armed) begin
 000096       sw_seq[sw_k] = b;
 000096       sw_k++;
            end
 000072     if (st == JTAG) begin
 000071       if (sw_armed && sw_k == 16 && sw_seq == 16'hE79E) begin
 000001         st = LOCKOUT;  // SWD selected; a line reset follows
 000001         n_switch++;
              end
~003163     end else if (ones >= 50 && st != RESET) begin
~000005       if (st == XFER) put(1'b0, 1'b1);
 000005       st = RESET;
 000005       idle_zeros = 0;
 000005       need_dpidr = 1;
 000005       n_line_reset++;
 003163     end else case (st)
 000054       RESET: begin
 000043         if (b) idle_zeros = 0;
 000011         else if (++idle_zeros >= 2) st = IDLE;
              end
 000249       IDLE: if (b) begin
 000071         req = 8'h01;
 000071         k = 1;
 000071         st = REQ;
              end
 000497       REQ: begin
 000497         req[k] = b;
 000497         k++;
 000426         if (k == 8) begin
 000071           apndp = req[1];
 000071           rnw   = req[2];
 000071           a     = req[4:3];
~000067           if (req[5] != ^req[4:1] || req[6] != 1'b0 || req[7] != 1'b1 ||
 000004               (need_dpidr && !(!apndp && rnw && a == 2'd0))) begin
                    // eight ones are the start of a line reset, and a request read from the bits of a
                    // selection sequence after one is part of that sequence: ignored the same way, but
                    // not host errors
~000004             if (req != 8'hFF && !(sw_armed && ((sw_seq ^ 16'hE79E) & ((16'd1 << sw_k) - 16'd1)) == 0))
%000000               n_proto_err++;
 000004             st = LOCKOUT;
 000067           end else begin
 000067             ack = respond();
 000055             if (ack == 3'b001) n_ok++;
 000006             else if (ack == 3'b010) n_wait++;
 000006             else n_fault++;
 000034             if (ack == 3'b001 && rnw) begin
 000033               data = do_read();
 000022               if (!apndp && a == 2'd0) need_dpidr = 0;
 000033               dpar = ^data ^ bad_par_next;
 000033               bad_par_next = 0;
                    end
 000067             k = 0;
 000067             st = XFER;
                  end
                end
              end
 002150       XFER: begin
 002150         k++;  // k = 1 at the turnaround's rising edge, the first after Park
 000201         if (k <= 3) put(1'b1, ack[k-1]);                         // ACK after edges 1..3
 001155         else if (ack == 3'b001 && rnw) begin
 001056           if (k <= 35) put(1'b1, data[k-4]);                     // RDATA after edges 4..35
 000033           else if (k == 36) put(1'b1, dpar);
 000033           else if (k == 37) put(1'b0, 1'b1);                     // release: Trn
 000033           else st = IDLE;                                        // edge 38 is the Trn edge
 000770         end else if (ack == 3'b001) begin
 000022           if (k == 4) put(1'b0, 1'b1);                           // release after ACK: Trn
 000704           else if (k >= 6 && k <= 37) data[k-6] = b;             // WDATA at edges 6..37
 000022           else if (k == 38) begin
 000020             if (b != ^data) begin
 000002               ctrl[7] = 1'b1;  // WDATAERR: the write is not done
 000002               n_wdataerr++;
 000020             end else do_write(data);
 000022             st = IDLE;
                  end
 000024         end else begin
 000012           if (k == 4) put(1'b0, 1'b1);                           // WAIT/FAULT: release, Trn
 000012           else st = IDLE;                                        // edge 5 is the Trn edge
                end
              end
 000213       default: ;  // LOCKOUT: only a line reset
            endcase
~003234     if (sw_armed && sw_k == 16) begin
 000006       sw_armed = 0;
~000006       if (st != JTAG && sw_seq == 16'hE79E && st != LOCKOUT) st = LOCKOUT;  // SWD stays selected
            end
          end
        
 000001   initial begin
 000001     drive = 1'b0;
 000001     dout = 1'b1;
 000016     foreach (mem[i]) mem[i] = 32'h1000_0000 + i;
          end
        endmodule
        
