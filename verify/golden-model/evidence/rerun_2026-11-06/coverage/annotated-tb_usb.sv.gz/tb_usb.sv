//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // End-to-end test of the USB low-speed device (programs/usb_dev.pbe on engine 0), through the
        // chip's pins only.
        //
        //  - A USB host model drives D- (pin 0) and D+ (pin 1), with its bit rate off by +-1.5 %, and
        //    decodes what the device sends (NRZI, unstuffing, CRC16 checked here, independently).
        //    Every device reply must start 2 to 7.5 bit times after the host's EOP, and host and
        //    device must never drive the bus at the same time.
        //  - A device firmware model on the host port answers the records the engine reports
        //    (IRQ-driven): descriptors, SET_ADDRESS (it rewrites the address in the program), a
        //    vendor write and read, and STALL for what it does not support. On a timer it queues an
        //    IN packet again when its ACK does not come, and handles a bus reset (SE0 >= 2.5 us).
        //  - The host enumerates the device: GET_DESCRIPTOR (device, configuration), SET_ADDRESS,
        //    SET_CONFIGURATION, an unsupported request, vendor requests; and checks that the device
        //    ignores a corrupted SETUP, a packet with a stuffing error, tokens for another address and a
        //    token with a bad CRC5, and keep-alive EOPs. Then a lost ACK (the device must resend the
        //    same DATA1 packet) and a 10 ms bus reset (the device must answer at address 0 again).
        module tb_usb;
          localparam real CLK_NS = 20.8333;  // 48 MHz: a USB low-speed bit is 32 clocks
          localparam int HOST_HALF = 8;
          localparam real BIT_NS = 1.0e9 / 1.5e6;
        
~937529   logic clk = 0, rst_n = 0;
 1875057   always #(CLK_NS / 2) clk = ~clk;
        
~021826   logic [7:0] ui_in = 8'b0000_0010;
~001229   wire  [7:0] uo_out, uio_out, uio_oe;
~002373   logic [7:0] ext_drive = '0, ext_val = '0;
          // D- (pin 0) has the device's 1.5 kohm pull-up, D+ (pin 1) the host's pull-down: idle is J
          localparam logic [7:0] PULL = 8'b1111_1101;
~003583   wire  [7:0] bus = (uio_oe & uio_out) | (~uio_oe & ext_drive & ext_val) | (~uio_oe & ~ext_drive & PULL);
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in(bus), .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
        
          // Verification-only scalar pins and phase markers; disabled for normal tests.
        `ifdef PBE_SIGROK
          integer sigrok_phase = 0;
          wire p0 = bus[0], p1 = bus[1], p2 = bus[2], p3 = bus[3];
          wire p4 = bus[4], p5 = bus[5], p6 = bus[6], p7 = bus[7];
          initial begin
            $dumpfile("tb_usb_pins.vcd");
            $dumpvars(0, p0, p1, p2, p3, p4, p5, p6, p7, sigrok_phase);
          end
        `endif
        
          `include "tb_host.svh"
        
 000001   int contention = 0;
~937529   always @(posedge clk) if ((uio_oe[1:0] & ext_drive[1:0]) != 0) contention++;
        
          // ---------------- USB helpers ----------------
          // CRC16 over u_data (the PID is not covered): returns the field, low byte sent first
          logic [7:0] u_data[$];
 000061   function automatic logic [15:0] usb_crc16();
 000061     logic [15:0] c, f;
 000061     logic [7:0] b;
 000061     c = 16'hFFFF;
 000302     foreach (u_data[i]) begin
 000302       b = u_data[i];
 002416       for (int k = 0; k < 8; k++) c = {c[14:0], 1'b0} ^ ((b[k] ^ c[15]) ? 16'h8005 : 16'h0);
            end
 000976     for (int k = 0; k < 16; k++) f[k] = ~c[15-k];
 000061     return f;
          endfunction
          // token bytes 2 and 3 for an address and endpoint (CRC5: poly 0x05, init all ones, inverted)
 000110   function automatic logic [15:0] usb_tok(input logic [6:0] addr, input logic [3:0] ep);
 000110     logic [10:0] v;
 000110     logic [4:0]  c, f;
 000110     v = {ep, addr};
 000110     c = 5'h1F;
 001210     for (int k = 0; k < 11; k++) c = {c[3:0], 1'b0} ^ ((v[k] ^ c[4]) ? 5'h05 : 5'h0);
 000550     for (int k = 0; k < 5; k++) f[k] = ~c[4-k];
 000110     return {f, v};
          endfunction
        
          // ---------------- USB host model: send ----------------
          logic [7:0] h_pkt[$];   // PID and the rest, without SYNC
 000001   real h_pct = 0;         // bit rate error in percent
 000001   int  h_bad_stuff = 0;   // the first stuffed bit: 1 leave it out, 2 send it as a 1 (wrong value)
          realtime t_host_j;      // when the host's last EOP turned to J
 006476   task automatic hs_line(input int st);  // 0 SE0, 1 J, 2 K
 006476     ext_drive[1:0] = 2'b11;
 006476     ext_val[0] = st == 1;
 006476     ext_val[1] = st == 2;
          endtask
 000168   task automatic hs_send;
 000168     real tb;
 000168     int k, ones;
 000168     logic [7:0] cur;
 000168     tb = BIT_NS / (1.0 + h_pct / 100.0);
 000168     k = 1;  // J
 000168     ones = 0;
 000763     for (int i = -1; i < h_pkt.size(); i++) begin
 000763       cur = (i < 0) ? 8'h80 : h_pkt[i];
 006104       for (int b = 0; b < 8; b++) begin
 004451         if (!cur[b]) k = 3 - k;
 006104         hs_line(k);
 006104         #(tb);
 006104         ones = cur[b] ? ones + 1 : 0;
 006075         if (ones == 6) begin
 000028           if (h_bad_stuff != 1) begin
 000024             if (h_bad_stuff != 2) k = 3 - k;  // a stuffed 0 changes the level, a wrong 1 keeps it
 000028             hs_line(k);
 000028             #(tb);
                  end
 000029           h_bad_stuff = 0;
 000029           ones = 0;
                end
              end
            end
 000168     hs_line(0);
 000168     #(2 * tb);
 000168     hs_line(1);
 000168     t_host_j = $realtime;
 000168     #(tb);
 000168     ext_drive[1:0] = 2'b00;
          endtask
 000002   task automatic hs_keepalive;  // a bare EOP, as a low-speed host sends every millisecond
 000002     hs_line(0);
 000002     #(2 * BIT_NS);
 000002     hs_line(1);
 000002     #(BIT_NS);
 000002     ext_drive[1:0] = 2'b00;
          endtask
        
          // ---------------- USB host model: receive ----------------
          // Waits up to 16 bit times for the device; decodes with the chip's clock (32 clocks a bit),
          // re-centring on every D- edge. r_pkt gets the bytes (PID first), r_ok says a packet came.
          logic [7:0] r_pkt[$];
 000099   bit r_ok;
 000001   real tt_min = 1e9, tt_max = 0;
 000001   int r_bad = 0;
 000112   task automatic hs_recv;
 000112     int phase, ones, nbits, wait_clk;
 000112     bit last, prev, in_sync, b, se0;
 000112     logic [7:0] sh;
 000112     real tt;
 000112     r_pkt.delete();
 000112     r_ok = 0;
 000112     wait_clk = 0;
 013787     while (!(bus[1] && !bus[0]) && wait_clk < 16 * 32) begin  // K starts the SYNC
 013787       @(posedge clk);
 013787       wait_clk++;
            end
~000112     if (bus[1] && !bus[0]) begin : got_k
 000099     tt = ($realtime - t_host_j) / BIT_NS;
 000096     if (tt < tt_min) tt_min = tt;
 000092     if (tt > tt_max) tt_max = tt;
 000099     phase = 0;
 000099     ones = 0;
 000099     nbits = 0;
 000099     last = 0;   // D- is low (K)
 000099     prev = 1;   // the level before SYNC: J
 000099     in_sync = 1;
 000099     se0 = 0;
 105232     while (!se0) begin
 105232       @(posedge clk);
 103012       if (bus[0] != last) begin
 002220         last = bus[0];
 002220         phase = 0;
 103012       end else phase++;
 101894       if (phase % 32 == 16) begin
 003239         if (!bus[0] && !bus[1]) se0 = 1;
 003239         else begin
 003239           b = (bus[0] == prev);
 003239           prev = bus[0];
 000792           if (in_sync) begin
 000693             if (b) begin
 000099               in_sync = 0;
 000099               ones = 1;
                    end
 002432           end else if (ones == 6) begin
~000015             if (b) begin
%000000               r_bad++;
%000000               $display("  FAIL: USB host: device sent no stuffed 0 after six 1s");
                    end
 000015             ones = 0;
 002432           end else begin
 002432             sh = {b, sh[7:1]};
 002432             nbits++;
 002432             ones = b ? ones + 1 : 0;
 002128             if (nbits % 8 == 0) r_pkt.push_back(sh);
                  end
                end
              end
            end
            // EOP: SE0 for 2 bits (we saw it at mid-bit), then J
 000099     wait_clk = 16;
~004752     while (!bus[0] && !bus[1]) begin
 004752       @(posedge clk);
 004752       wait_clk++;
            end
~000099     check(wait_clk >= 60 && wait_clk <= 68, $sformatf("USB host: device EOP SE0 lasted %0d clocks", wait_clk));
~000099     check(bus[0] && !bus[1], "USB host: no J after the device's SE0");
 000099     check(nbits % 8 == 0, $sformatf("USB host: device packet of %0d bits", nbits));
 003960     repeat (40) @(posedge clk);
 000099     check(uio_oe[1:0] == 2'b00, "USB host: device did not release the bus after its EOP");
 000099     r_ok = 1;
            end
          endtask
        
          // ---------------- transactions ----------------
~000002   logic [6:0] dev_addr = 0;
 000001   int n_timeouts = 0;
 000105   task automatic hs_token(input logic [7:0] pid, input logic [6:0] addr);
 000105     logic [15:0] t;
 000105     t = usb_tok(addr, 0);
 000105     h_pkt = '{pid, t[7:0], t[15:8]};
 000105     hs_send;
          endtask
 000031   task automatic hs_data(input logic [7:0] pid, input bit flip);  // u_data with its CRC16
 000031     logic [15:0] c;
 000031     c = usb_crc16();
 000031     h_pkt.delete();
 000031     h_pkt.push_back(pid);
 000147     foreach (u_data[i]) h_pkt.push_back(u_data[i]);
 000031     h_pkt.push_back(c[7:0]);
 000031     h_pkt.push_back(c[15:8]);
 000028     if (flip) h_pkt[1] = h_pkt[1] ^ 8'h04;
 000031     hs_send;
          endtask
 000064   task automatic gap;  // between transactions: a little time, sometimes a keep-alive
 012800     repeat (200) @(posedge clk);
          endtask
        
          // the request of the next control transfer (array ports are not supported by Icarus 12)
          logic [7:0] req[$];
        
          // SETUP stage: retried until the device ACKs (a host gives up after 3 errors)
 000014   task automatic hs_setup;
 000014     int tries;
 000014     tries = 0;
~000014     do begin
 000014       hs_token(8'h2D, dev_addr);
 000014       u_data.delete();
 000112       foreach (req[i]) u_data.push_back(req[i]);
 000014       hs_data(8'hC3, 0);
 000014       hs_recv;
 000014       tries++;
 000014       gap;
~000014     end while (!(r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'hD2) && tries < 3);
~000014     check(r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'hD2, "USB: SETUP not ACKed");
          endtask
        
          // IN: retried while the device NAKs. in_pkt gets the data, in_res: 0 data, 1 STALL, 2 nothing
          logic [7:0] in_pkt[$];
          int in_res;
~000009   logic [7:0] in_pid;
 000001   bit h_lose_ack = 0;  // the next IN data packet gets no ACK (as if the ACK were lost)
 000030   task automatic hs_in;
 000030     int tries;
 000030     logic [15:0] c, got;
 000030     tries = 0;
 000030     in_res = 2;
 000075     do begin
 000075       hs_token(8'h69, dev_addr);
 000075       hs_recv;
 000075       tries++;
~018000       if (r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'h5A) repeat (400) @(posedge clk);  // NAK
~000075     end while (r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'h5A && tries < 200);
~000029     if (r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'h1E) begin
 000001       in_res = 1;
 000001       gap;
~000029     end else if (r_ok) begin : data
~000029     check(r_pkt.size() >= 3 && (r_pkt[0] == 8'hC3 || r_pkt[0] == 8'h4B),
 000029           $sformatf("USB: IN answered with %0d bytes, PID %02x", r_pkt.size(), r_pkt.size() ? r_pkt[0] : 8'h00));
 000029     in_pid = r_pkt[0];
 000029     u_data.delete();
 000147     for (int i = 1; i + 2 < r_pkt.size(); i++) u_data.push_back(r_pkt[i]);
 000029     c = usb_crc16();
 000029     got = {r_pkt[r_pkt.size()-1], r_pkt[r_pkt.size()-2]};
 000029     check(got == c, $sformatf("USB: device DATA CRC16 %04x, expected %04x", got, c));
 000029     in_pkt.delete();
 000147     foreach (u_data[i]) in_pkt.push_back(u_data[i]);
 000029     in_res = 0;
 000028     if (h_lose_ack) h_lose_ack = 0;
 000028     else begin
 000028       h_pkt = '{8'hD2};  // ACK
 000028       hs_send;
            end
 000029     gap;
            end
          endtask
        
          // OUT: a data packet with out_data, retried until ACKed
          logic [7:0] out_data[$];
 000010   task automatic hs_out(input logic [7:0] pid);
 000010     int tries;
 000010     tries = 0;
~000010     do begin
 000010       hs_token(8'hE1, dev_addr);
 000010       u_data = out_data;  // (hs_setup uses u_data for the request: BUG-029)
 000010       hs_data(pid, 0);
 000010       hs_recv;
 000010       tries++;
 000010       gap;
~000010     end while (!(r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'hD2) && tries < 3);
~000010     check(r_ok && r_pkt.size() == 1 && r_pkt[0] == 8'hD2, "USB: OUT not ACKed");
          endtask
        
          // control read: SETUP, IN data stages until a short packet or wLength, OUT status
          logic [7:0] ctl_in[$];
          int ctl_stalled;
 000009   task automatic ctl_read;
 000009     int want;
 000009     logic [7:0] expect_pid;
 000009     want = {req[7], req[6]};
 000009     ctl_in.delete();
 000009     ctl_stalled = 0;
 000009     hs_setup;
 000009     expect_pid = 8'h4B;  // DATA1 first
 000009     begin : stages  // (Icarus 12 has no return in tasks: disable the block instead)
 000021       do begin
 000021         hs_in;
~000021         if (in_res == 1) begin
%000000           ctl_stalled = 1;
%000000           disable stages;
                end
 000021         check(in_res == 0, "USB: no answer to IN in a control read");
~000021         if (in_res != 0) disable stages;
 000021         check(in_pid == expect_pid, $sformatf("USB: data stage PID %02x, expected %02x", in_pid, expect_pid));
 000021         expect_pid = expect_pid ^ 8'h88;  // DATA1 <-> DATA0
 000121         foreach (in_pkt[i]) ctl_in.push_back(in_pkt[i]);
~000021       end while (in_pkt.size() == 8 && ctl_in.size() < want);
 000009       out_data.delete();
 000009       hs_out(8'h4B);  // status stage: OUT DATA1, zero length
            end
          endtask
        
          // control with no data stage, or a write: SETUP, OUT data, IN status (zero length)
 000004   task automatic ctl_write(input bit with_data);
 000004     hs_setup;
 000003     if (with_data) hs_out(8'h4B);  // out_data holds the data
 000004     hs_in;
~000004     check(in_res == 0 && in_pkt.size() == 0 && in_pid == 8'h4B, "USB: status stage is not a DATA1 ZLP");
          endtask
        
          // ---------------- device firmware model (on the host port) ----------------
          logic [7:0] dev_desc[$], cfg_desc[$], vendor_mem[$];
          logic [7:0] fw_tx[$], rec[$];
 000001   int  fw_want, fw_sent, fw_toggle, fw_setups = 0, fw_bad = 0, fw_acks = 0;
~000005   bit  fw_reading = 0, fw_zlp = 0, fw_writing = 0, fw_run = 0, fw_hold = 0;
~000001   logic [6:0] fw_addr_pending = 0;
 000002   bit  fw_set_addr = 0;
          int  fw_vlen;
 000001   int  fw_resends = 0, fw_resets = 0;  // IN packets queued again (BUG-041), bus resets seen (BUG-042)
        
 000008   task automatic pm_write_word(input int a, input logic [15:0] w);
 000008     logic [7:0] d;
 000008     reg_write(7'h06, 8'(2 * a));
 000008     cs(0);
 000008     spi_byte({1'b1, 7'h07}, d);
 000008     spi_byte(w[15:8], d);
 000008     spi_byte(w[7:0], d);
 000008     cs(1);
          endtask
          // The IN packet in the TX FIFO, kept until the host ACKs it: if the ACK does not come, the
          // firmware queues it again, same DATA PID (BUG-041)
          logic [7:0] fw_last[$];
 000028   bit  fw_unacked = 0;
 000001   realtime fw_drained_at = 0;  // when the TX FIFO was first seen empty with fw_unacked (0: not yet)
 000029   task automatic fw_put;  // fw_last into the TX FIFO, then FLAG0
 000029     logic [7:0] d;
 000029     cs(0);
 000029     spi_byte({1'b1, 7'h16}, d);
~000176     foreach (fw_last[i]) spi_byte(fw_last[i], d);
 000029     cs(1);
 000029     fw_unacked = 1;
 000029     fw_drained_at = 0;
 000029     flag_set(0, 0);
          endtask
 000028   task automatic fw_queue;  // the next IN packet of the reply
 000028     int n;
 000028     n = fw_tx.size() < 8 ? fw_tx.size() : 8;
 000028     fw_last.delete();
 000028     fw_last.push_back(fw_toggle ? 8'h4B : 8'hC3);
 000139     for (int i = 0; i < n; i++) fw_last.push_back(fw_tx.pop_front());
 000028     fw_sent += n;
 000028     fw_zlp = 0;
 000028     fw_toggle ^= 1;
 000028     fw_put;
          endtask
 000004   task automatic fw_status_zlp;  // the IN status stage of a no-data or write request
 000004     fw_tx.delete();
 000004     fw_toggle = 1;
 000004     fw_reading = 0;
 000004     fw_queue;
          endtask
 000014   task automatic fw_setup;  // rec holds [2D] [C3] [8 bytes] [crc] [crc] [count] [status]
 000014     logic [7:0] rt, rq, wvh, wvl;
 000014     rt = rec[2];
 000014     rq = rec[3];
 000014     wvl = rec[4];
 000014     wvh = rec[5];
 000014     fw_want = {rec[9], rec[8]};
 000014     fw_setups++;
 000014     reg_write(7'h0E, 8'h01);  // drop a stale reply; not the RX FIFO: an OUT may already be arriving
 000014     fw_unacked = 0;
 000014     flag_clear(0, 0);
 000014     flag_clear(0, 1);
 000014     fw_writing = 0;
 000014     fw_reading = 0;
 000008     if (rt == 8'h80 && rq == 8'h06 && (wvh == 8'h01 || wvh == 8'h02)) begin  // GET_DESCRIPTOR
 000008       fw_tx.delete();
 000108       if (wvh == 8'h01) foreach (dev_desc[i]) fw_tx.push_back(dev_desc[i]);
 000036       else foreach (cfg_desc[i]) fw_tx.push_back(cfg_desc[i]);
 000009       while (fw_tx.size() > fw_want) d_drop();
 000008       fw_reading = 1;
 000008       fw_sent = 0;
 000008       fw_toggle = 1;
 000008       fw_queue;
 000004     end else if (rt == 8'h00 && rq == 8'h05) begin  // SET_ADDRESS: takes effect after the status stage
 000002       fw_addr_pending = wvl[6:0];
 000002       fw_set_addr = 1;
 000002       fw_status_zlp;
 000003     end else if (rt == 8'h00 && rq == 8'h09) begin  // SET_CONFIGURATION
 000001       fw_status_zlp;
 000002     end else if (rt == 8'h40 && rq == 8'h01) begin  // vendor write: data follows
 000001       fw_writing = 1;
 000001       fw_vlen = fw_want;
 000001       vendor_mem.delete();
 000001     end else if (rt == 8'hC0 && rq == 8'h02) begin  // vendor read: what was written, reversed
 000001       fw_tx.delete();
 000003       for (int i = vendor_mem.size() - 1; i >= 0; i--) fw_tx.push_back(vendor_mem[i]);
 000001       fw_tx.push_back(8'h55);
%000000       while (fw_tx.size() > fw_want) d_drop();
 000001       fw_reading = 1;
 000001       fw_sent = 0;
 000001       fw_toggle = 1;
 000001       fw_queue;
 000001     end else flag_set(0, 1);  // not supported: STALL
          endtask
 000009   task automatic d_drop;
 000009     logic [7:0] d;
 000009     d = fw_tx.pop_back();
          endtask
          // One record from the RX FIFO, in rec: [D2], or [tag] [DATA PID] [n bytes] [255 - n] [status]
 000058   task automatic fw_record;
 000058     logic [7:0] st;
 000030     if (rec.size() == 1 && rec[0] == 8'hD2) begin  // the host ACKed our IN packet
 000028       fw_acks++;
 000028       fw_unacked = 0;
 000028       flag_clear(0, 0);
 000002       if (fw_set_addr) begin                        // SET_ADDRESS status stage done: switch
 000002         logic [15:0] t;
 000002         t = usb_tok(fw_addr_pending, 0);
 000002         pm_write_word(6, 16'h9000 | {4'h0, t[7:0], 4'h0});
 000002         pm_write_word(9, 16'h9000 | {4'h0, t[15:8], 4'h0});
 000002         fw_set_addr = 0;
~000019       end else if (fw_reading && (fw_tx.size() > 0 || (fw_sent % 8 == 0 && fw_sent < fw_want && !fw_zlp)))
 000015         fw_queue;
 000030     end else begin
 000030       st = rec[rec.size()-1];
 000023       if (!st[1] || st[4]) fw_bad++;                // bad CRC or line error: not ACKed, sent again
 000014       else if (rec[0] == 8'h2D && rec.size() == 14) fw_setup;
~000009       else if (rec[0] == 8'hE1 && fw_writing) begin
 000003         for (int k = 2; k < rec.size() - 4; k++) vendor_mem.push_back(rec[k]);
~000001         if (vendor_mem.size() >= fw_vlen) begin
 000001           fw_writing = 0;
 000001           fw_status_zlp;
                end
              end
            end
          endtask
        
          // Bus reset (BUG-042): SE0 for 2.5 us or more. The firmware puts the device back at address
          // 0 (program words 6 and 9), drops the reply and the flags, and forgets its state.
 000002   bit fw_in_reset = 0;
 000002   task automatic fw_bus_reset;
 000002     pm_write_word(6, 16'h9000);  // SET OSR, 0x00: address 0
 000002     pm_write_word(9, 16'h9100);  // SET OSR, 0x10: endpoint 0 and the CRC5 for address 0
 000002     reg_write(7'h0E, 8'h01);     // flush the TX FIFO
 000002     reg_write(7'h09, 8'h07);     // clear FLAG0 (IN queued), FLAG1 (STALL) and FLAG2
 000002     fw_tx.delete();
 000002     fw_reading = 0;
 000002     fw_writing = 0;
 000002     fw_zlp = 0;
 000002     fw_set_addr = 0;
 000002     fw_unacked = 0;
 000002     fw_resets++;
          endtask
        
          // The firmware's timer, every 50 us when no record waits: a bus reset, and an IN packet that
          // has left the TX FIFO (TX_COUNT = 0) without an ACK record for 100 us is queued again.
          // One register read takes about 6 us, so two reads that both see SE0 are 2.5 us apart; EOPs
          // (1.33 us of SE0) are at least ~12 us apart, so two of them cannot pass for a reset.
 000336   task automatic fw_poll;
 000336     logic [7:0] p, cnt;
 000336     realtime t;
 000336     reg_read(7'h05, p);  // PINS: D- is pin 0, D+ pin 1
 000208     if (p[1:0] == 2'b00) begin
 000208       t = $realtime;
 000208       reg_read(7'h05, p);
 000201       if (p[1:0] == 2'b00 && $realtime - t >= 2500) begin
~000201         if (!fw_in_reset) fw_bus_reset;
 000201         fw_in_reset = 1;
              end
 000128     end else fw_in_reset = 0;
 000267     if (fw_unacked) begin
 000069       reg_read(7'h0C, cnt);  // TX_COUNT
 000038       if (cnt != 0) fw_drained_at = 0;
 000029       else if (fw_drained_at == 0) fw_drained_at = $realtime;
 000001       else if ($realtime - fw_drained_at >= 100000 && !uo_out[1]) begin  // no record waiting
 000001         fw_resends++;
 000001         fw_put;
              end
            end
          endtask
        
          // IRQ-driven: read how many bytes wait (RX_COUNT), read exactly those in one burst, split
          // them into records from the end (a status byte is below 0x20, an ACK record is 0xD2), and
          // handle the records in order. Otherwise the timer (fw_poll). One process, like a firmware
          // main loop, so the two never race.
          logic [7:0] fw_buf[$];
          int fw_ends[$];
 000001   int fw_records = 0, fw_max_pile = 0;
 000001   realtime fw_next_poll = 0;
~593930   initial forever begin
 593930     @(posedge clk);
 000336     if (fw_run && !fw_hold && !uo_out[1] && $realtime >= fw_next_poll) begin
 000336       fw_next_poll = $realtime + 50000;
 000336       fw_poll;
~593537     end else if (fw_run && !fw_hold && uo_out[1]) begin
 000057       logic [7:0] cnt, d, b;
 000057       int j, c, from;
 000057       reg_write(7'h02, 8'h01);  // clear the IRQ first: a record arriving meanwhile raises it again
 000057       reg_read(7'h0A, cnt);
 000057       fw_buf.delete();
~000057       if (cnt != 0) begin
 000057         cs(0);
 000057         spi_byte({1'b0, 7'h16}, d);
 000356         for (int i = 0; i < cnt; i++) begin
 000356           spi_byte(8'h00, d);
 000356           fw_buf.push_back(d);
                end
 000057         cs(1);
              end
 000057       flag_clear(0, 2);
              // record boundaries, found from the end
 000057       fw_ends.delete();
 000057       j = fw_buf.size() - 1;
 000058       while (j >= 0) begin
 000058         fw_ends.push_front(j);
 000058         b = fw_buf[j];
 000030         if (b == 8'hD2) j = j - 1;
 000030         else begin
 000030           c = 255 - fw_buf[j-1];
 000030           j = j - 1 - c - 3;  // [tag] [pid] [c bytes] [count] [status]
                end
              end
 000055       if (fw_ends.size() > fw_max_pile) fw_max_pile = fw_ends.size();
 000057       check(j == -1, $sformatf("USB firmware: %0d bytes do not split into records", fw_buf.size()));
 000057       from = 0;
~000058       foreach (fw_ends[k]) begin
 000058         rec.delete();
 000355         for (int i = from; i <= fw_ends[k]; i++) rec.push_back(fw_buf[i]);
 000058         from = fw_ends[k] + 1;
 000058         fw_records++;
 000058         fw_record;
              end
            end
          end
        
          // ---------------- the test ----------------
        `ifdef PBE_PROTOCOL_REFERENCE
          `include "usb_reference.svh"
        `endif
        
 000001   initial begin
        `ifndef PBE_SIGROK
~000001     if ($test$plusargs("vcd")) begin
%000000       $dumpfile("tb_usb.vcd");
%000000       $dumpvars(0, tb_usb);
            end
        `endif
 000001     dev_desc = '{8'h12, 8'h01, 8'h10, 8'h01, 8'hFF, 8'h00, 8'h00, 8'h08, 8'h34, 8'h12,
 000001                  8'h78, 8'h56, 8'h00, 8'h01, 8'h00, 8'h00, 8'h00, 8'h01};
 000001     cfg_desc = '{8'h09, 8'h02, 8'h12, 8'h00, 8'h01, 8'h01, 8'h00, 8'h80, 8'h32,
 000001                  8'h09, 8'h04, 8'h00, 8'h00, 8'h00, 8'hFF, 8'h00, 8'h00, 8'h00};
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
        
            // CRC helpers against the known values (docs/USB_NOTES.md)
 000001     begin
 000001       logic [15:0] c, t;
 000001       u_data = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h40, 8'h00};
 000001       c = usb_crc16();
 000001       t = usb_tok(0, 0);
~000001       check(c == 16'h94DD && t == 16'h1000, $sformatf("testbench CRCs: %04x %04x", c, t));
            end
        
        `ifdef PBE_SIGROK
            sigrok_phase = 11;
        `endif
 000001     $display("Test 11: USB low-speed device (engine 0, D- pin 0, D+ pin 1) enumerated by a host model");
 000001     load_program("usb_image.hex");
 000001     reg_write(7'h03, 8'h00);
 000001     reg_write(7'h10, 31);               // bit time 32 clocks
 000001     reg_write(7'h11, 0);
 000001     reg_write(7'h12, 0);
 000001     reg_write(7'h14, 2'b00);            // LSB first
 000001     reg_write(7'h15, 0);
 000001     reg_write(7'h19, 8'h05);            // CRC16 0x8005, all ones, reversed, fed by OUT and IN
 000001     reg_write(7'h1A, 8'h80);
 000001     reg_write(7'h1B, 8'hFF);
 000001     reg_write(7'h1E, 8'h40);            // no parity
 000001     reg_write(7'h30, 8'h36);            // line coder: bytes, pair, stuff after 6 ones, NRZI
 000001     reg_write(7'h31, 8'h80);            // SYNC
 000001     reg_write(7'h32, 8'h0D);            // CRC good value 0x800d (CRC16 sent inverted)
 000001     reg_write(7'h33, 8'h80);
 000001     reg_write(7'h00, 8'b0001_0001);     // restart + run E0
 000001     fw_run = 1;
 000100     repeat (100) @(posedge clk);
~000001     check(bus[0] && !bus[1] && uio_oe[1:0] == 0, "USB: bus not idle in J with the device released");
        
        `ifdef PBE_PROTOCOL_REFERENCE
            usb_reference;
            $finish;
        `endif
        
            // bus reset and a keep-alive: nothing must come back
 000001     hs_line(0);
 000001     #(20000);
 000001     hs_line(1);
 000001     t_host_j = $realtime;
 000001     #(BIT_NS);
 000001     ext_drive[1:0] = 0;
 000001     hs_recv;
~000001     check(!r_ok, "USB: device answered a bus reset");
 000001     hs_keepalive;
 000001     hs_recv;
~000001     check(!r_ok, "USB: device answered a keep-alive");
        
            // GET_DESCRIPTOR(device, 64) at address 0, host at +1.5 %
 000001     h_pct = 1.5;
 000001     req = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h40, 8'h00};
 000001     ctl_read;
 000001     check(ctl_in.size() == 18, $sformatf("USB: device descriptor %0d bytes", ctl_in.size()));
~000018     foreach (ctl_in[i]) if (i < 18) check(ctl_in[i] === dev_desc[i], $sformatf("USB: device descriptor byte %0d", i));
 000001     $display("  GET_DESCRIPTOR(device) at address 0: 18 bytes in 3 packets");
        
        `ifdef PBE_SIGROK
            sigrok_phase = 110;
        `endif
            // a corrupted SETUP is not ACKed (the host model retries it), a stuffing error neither
 000001     h_pct = -1.5;
 000001     begin
 000001       int bad0;
 000001       bad0 = fw_bad;
 000001       hs_token(8'h2D, 0);
 000001       u_data = '{8'h80, 8'h06, 8'h00, 8'h02, 8'h00, 8'h00, 8'h09, 8'h00};
 000001       hs_data(8'hC3, 1);                  // a flipped bit
 000001       hs_recv;
~000001       check(!r_ok, "USB: device ACKed a SETUP with a bad CRC");
 000001       gap;
 000001       hs_token(8'h2D, 0);
 000001       u_data = '{8'hFF, 8'hFF, 8'h00, 8'h02, 8'h00, 8'h00, 8'h09, 8'h00};
 000001       h_bad_stuff = 1;                    // six 1s and no stuffed 0
 000001       hs_data(8'hC3, 0);
 000001       hs_recv;
~000001       check(!r_ok, "USB: device ACKed a packet with a stuffing error");
 000001       gap;
              // a stuff bit with the wrong value: the data and the CRC16 arrive intact (BUG-040)
 000001       hs_token(8'h2D, 0);
 000001       u_data = '{8'hFF, 8'hFF, 8'h00, 8'h02, 8'h00, 8'h00, 8'h09, 8'h00};
 000001       h_bad_stuff = 2;                    // six 1s, then a 1 where the stuffed 0 belongs
 000001       hs_data(8'hC3, 0);
 000001       hs_recv;
~000001       check(!r_ok, "USB: device ACKed a packet with a wrong stuff bit (data and CRC intact)");
 000001       gap;
 015000       repeat (15000) @(posedge clk);  // the firmware reads 14-byte records: ~2000 clocks each
 000001       check(fw_bad == bad0 + 3, $sformatf("USB: firmware saw %0d bad records, expected 3", fw_bad - bad0));
 000001       $display("  a SETUP with a flipped bit, one with a missing and one with a wrong stuff bit: not ACKed, reported as bad");
              // the firmware busy: two (corrupted) OUT records pile up in the RX FIFO and are split apart
 000001       bad0 = fw_bad;
 000001       fw_hold = 1;
 000002       for (int k = 0; k < 2; k++) begin
 000002         hs_token(8'hE1, 0);
 000002         u_data.delete();
 000002         hs_data(8'h4B, 1);
 000002         hs_recv;
~000002         check(!r_ok, "USB: device ACKed an OUT with a bad CRC");
 000002         gap;
              end
 000001       fw_hold = 0;
 006000       repeat (6000) @(posedge clk);
 000001       check(fw_max_pile >= 2, $sformatf("USB: records did not pile up (%0d at most)", fw_max_pile));
 000001       check(fw_bad == bad0 + 2, $sformatf("USB: firmware split %0d bad records out of the pile, expected 2", fw_bad - bad0));
 000001       $display("  two records piled up while the firmware was busy: split apart from the end");
            end
        
        `ifdef PBE_SIGROK
            sigrok_phase = 111;
        `endif
            // SET_ADDRESS(0x15), then everything at the new address
 000001     req = '{8'h00, 8'h05, 8'h15, 8'h00, 8'h00, 8'h00, 8'h00, 8'h00};
 000001     ctl_write(0);
 006000     repeat (6000) @(posedge clk);       // the firmware switches the address (USB allows 2 ms)
 000001     dev_addr = 7'h15;
 000001     $display("  SET_ADDRESS(0x15)");
        
        `ifdef PBE_SIGROK
            sigrok_phase = 112;
        `endif
            // tokens for the old address and with a bad CRC5 are ignored
 000001     hs_token(8'h69, 0);
 000001     hs_recv;
~000001     check(!r_ok, "USB: device answered an IN for address 0 after SET_ADDRESS");
 000001     gap;
 000001     begin
 000001       logic [15:0] t;
 000001       t = usb_tok(dev_addr, 0) ^ 16'h0800;  // a CRC5 bit flipped
 000001       h_pkt = '{8'h69, t[7:0], t[15:8]};
 000001       hs_send;
 000001       hs_recv;
~000001       check(!r_ok, "USB: device answered a token with a bad CRC5");
 000001       gap;
            end
 000001     $display("  tokens for address 0 and with a bad CRC5: ignored");
        
        `ifdef PBE_SIGROK
            sigrok_phase = 113;
        `endif
 000001     h_pct = 0;
 000001     req = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h12, 8'h00};
 000001     ctl_read;
 000001     check(ctl_in.size() == 18, $sformatf("USB: device descriptor at the new address: %0d bytes", ctl_in.size()));
 000001     h_pct = 1.5;
 000001     req = '{8'h80, 8'h06, 8'h00, 8'h02, 8'h00, 8'h00, 8'h09, 8'h00};
 000001     ctl_read;
 000001     check(ctl_in.size() == 9, $sformatf("USB: configuration descriptor (9): %0d bytes", ctl_in.size()));
 000001     req = '{8'h80, 8'h06, 8'h00, 8'h02, 8'h00, 8'h00, 8'hFF, 8'h00};
 000001     ctl_read;
 000001     check(ctl_in.size() == 18, $sformatf("USB: configuration descriptor (all): %0d bytes", ctl_in.size()));
~000018     foreach (ctl_in[i]) if (i < 18) check(ctl_in[i] === cfg_desc[i], $sformatf("USB: configuration byte %0d", i));
 000001     $display("  GET_DESCRIPTOR(device, configuration 9 and 18 bytes) at the new address");
        
        `ifdef PBE_SIGROK
            sigrok_phase = 114;
        `endif
 000001     hs_keepalive;
 000001     hs_recv;
~000001     check(!r_ok, "USB: device answered a keep-alive");
        
 000001     req = '{8'h00, 8'h09, 8'h01, 8'h00, 8'h00, 8'h00, 8'h00, 8'h00};
 000001     ctl_write(0);
 000001     $display("  SET_CONFIGURATION(1)");
        
 000001     h_pct = -1.5;
 000001     req = '{8'h80, 8'h06, 8'h02, 8'h03, 8'h09, 8'h04, 8'h40, 8'h00};  // a string: not supported
 000001     ctl_read;
 000001     check(ctl_stalled == 1, "USB: unsupported request not STALLed");
 000001     $display("  an unsupported request: STALL");
        
            // vendor write of 3 bytes, then read them back (the firmware reverses them, adds 0x55)
 000001     req = '{8'h40, 8'h01, 8'h00, 8'h00, 8'h00, 8'h00, 8'h03, 8'h00};
 000001     out_data = '{8'hAA, 8'hBB, 8'hCC};
 000001     ctl_write(1);
~000001     check(vendor_mem.size() == 3 && vendor_mem[0] == 8'hAA && vendor_mem[2] == 8'hCC, "USB: vendor write data");
 000001     h_pct = 1.5;
 000001     req = '{8'hC0, 8'h02, 8'h00, 8'h00, 8'h00, 8'h00, 8'h04, 8'h00};
 000001     ctl_read;
~000001     check(ctl_in.size() == 4 && ctl_in[0] == 8'hCC && ctl_in[1] == 8'hBB && ctl_in[2] == 8'hAA && ctl_in[3] == 8'h55,
 000001           "USB: vendor read did not return the written data");
 000001     $display("  vendor write (OUT data) and read back");
        
        `ifdef PBE_SIGROK
            sigrok_phase = 115;
        `endif
            // the host's ACK for an IN data packet is lost (BUG-041): the firmware queues the same
            // packet again, and the device sends the same DATA1 packet when the host asks again
 000001     begin
 000001       logic [7:0] first[$];
 000001       int resends0;
 000001       resends0 = fw_resends;
 000001       h_pct = 0;
 000001       req = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h12, 8'h00};
 000001       ctl_in.delete();
 000001       hs_setup;
 000001       h_lose_ack = 1;
 000001       hs_in;
~000001       check(in_res == 0 && in_pid == 8'h4B && in_pkt.size() == 8, "USB: first DATA1 packet of the descriptor");
 000001       first.delete();
 000008       foreach (in_pkt[i]) first.push_back(in_pkt[i]);
 000001       hs_in;                              // NAKed until the firmware has queued it again
~000001       check(in_res == 0 && in_pid == 8'h4B, $sformatf("USB: after a lost ACK the device sent PID %02x (res %0d), expected DATA1 again", in_pid, in_res));
 000001       check(in_pkt.size() == first.size(), $sformatf("USB: after a lost ACK the device sent %0d bytes, first %0d", in_pkt.size(), first.size()));
~000008       foreach (first[i]) if (i < in_pkt.size()) check(in_pkt[i] === first[i], $sformatf("USB: resent byte %0d differs", i));
 000001       check(fw_resends == resends0 + 1, $sformatf("USB: firmware resent %0d packets, expected 1", fw_resends - resends0));
 000008       foreach (in_pkt[i]) ctl_in.push_back(in_pkt[i]);
 000001       hs_in;
~000001       check(in_res == 0 && in_pid == 8'hC3, "USB: second packet after the resend is not DATA0");
 000008       foreach (in_pkt[i]) ctl_in.push_back(in_pkt[i]);
 000001       hs_in;
~000001       check(in_res == 0 && in_pid == 8'h4B, "USB: third packet after the resend is not DATA1");
 000002       foreach (in_pkt[i]) ctl_in.push_back(in_pkt[i]);
 000001       out_data.delete();
 000001       hs_out(8'h4B);
 000001       check(ctl_in.size() == 18, $sformatf("USB: descriptor after a lost ACK: %0d bytes", ctl_in.size()));
~000018       foreach (ctl_in[i]) if (i < 18) check(ctl_in[i] === dev_desc[i], $sformatf("USB: descriptor byte %0d after a lost ACK", i));
 000001       $display("  a lost ACK: the firmware queued the packet again, the device resent the same DATA1");
            end
        
        `ifdef PBE_SIGROK
            sigrok_phase = 116;
        `endif
            // bus reset (BUG-042): 10 ms of SE0 puts the device back at address 0
 000001     begin
 000001       int resets0;
 000001       resets0 = fw_resets;
 000001       hs_line(0);
 000001       #(10ms);
 000001       hs_line(1);
 000001       #(BIT_NS);
 000001       ext_drive[1:0] = 0;
 000200       repeat (200) @(posedge clk);
 000001       check(fw_resets == resets0 + 1, $sformatf("USB: firmware saw %0d bus resets, expected 1", fw_resets - resets0));
 000001       dev_addr = 0;
 000001       req = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h40, 8'h00};
 000001       ctl_read;
 000001       check(ctl_in.size() == 18, $sformatf("USB: device descriptor at address 0 after a bus reset: %0d bytes", ctl_in.size()));
~000018       foreach (ctl_in[i]) if (i < 18) check(ctl_in[i] === dev_desc[i], $sformatf("USB: descriptor byte %0d after a bus reset", i));
 000001       $display("  a 10 ms bus reset: back at address 0, GET_DESCRIPTOR works again");
            end
        
        `ifdef PBE_SIGROK
            sigrok_phase = 117;
        `endif
            // A token with a wrong stuff bit but intact bytes is ignored (BUG-101). USB 1.1 §7.1.9: seven
            // 1s in a row are a bit stuffing error and the packet is ignored; §8.7.1: a corrupted packet
            // (bit stuffing is one of the token's checks, besides the PID check and CRC5) is ignored with
            // any data or field that came with it, so the function sends no handshake and no data.
            // Address 0x3F puts six 1s into the token's second byte (a stuffed 0 follows them).
 000001     begin
 000001       logic [15:0] t;
 000001       int bad0, setups0;
 000001       req = '{8'h00, 8'h05, 8'h3F, 8'h00, 8'h00, 8'h00, 8'h00, 8'h00};  // SET_ADDRESS(0x3F)
 000001       ctl_write(0);
 006000       repeat (6000) @(posedge clk);
 000001       dev_addr = 7'h3F;
 000001       req = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h12, 8'h00};
 000001       ctl_read;                           // tokens with a correct stuff bit work
 000001       check(ctl_in.size() == 18, $sformatf("USB: device descriptor at address 0x3F: %0d bytes", ctl_in.size()));
 000001       t = usb_tok(dev_addr, 0);
              // IN: no NAK, no data
 000001       h_pkt = '{8'h69, t[7:0], t[15:8]};
 000001       h_bad_stuff = 2;                    // six 1s, then a 1 where the stuffed 0 belongs
 000001       hs_send;
 000001       hs_recv;
~000001       check(!r_ok, $sformatf("USB: device answered an IN token with a wrong stuff bit (%0d bytes, PID %02x)",
 000001                              r_pkt.size(), r_pkt.size() ? r_pkt[0] : 8'h00));
 000001       gap;
              // SETUP with a wrong stuff bit, then an intact DATA0: no ACK, the record reported bad
 000001       bad0 = fw_bad;
 000001       setups0 = fw_setups;
 000001       h_pkt = '{8'h2D, t[7:0], t[15:8]};
 000001       h_bad_stuff = 2;
 000001       hs_send;
 000001       u_data = '{8'h80, 8'h06, 8'h00, 8'h01, 8'h00, 8'h00, 8'h12, 8'h00};
 000001       hs_data(8'hC3, 0);
 000001       hs_recv;
~000001       check(!r_ok, "USB: device ACKed a SETUP whose token had a wrong stuff bit");
 000001       gap;
              // OUT with a wrong stuff bit, then an intact zero-length DATA1: no ACK either
 000001       h_pkt = '{8'hE1, t[7:0], t[15:8]};
 000001       h_bad_stuff = 2;
 000001       hs_send;
 000001       u_data.delete();
 000001       hs_data(8'h4B, 0);
 000001       hs_recv;
~000001       check(!r_ok, "USB: device ACKed an OUT whose token had a wrong stuff bit");
 000001       gap;
 015000       repeat (15000) @(posedge clk);
 000001       check(fw_setups == setups0, $sformatf("USB: firmware took %0d SETUP(s) from a token with a wrong stuff bit", fw_setups - setups0));
 000001       check(fw_bad == bad0 + 2, $sformatf("USB: firmware saw %0d bad records after the bad tokens, expected 2", fw_bad - bad0));
 000001       ctl_read;                           // and the device still works
 000001       check(ctl_in.size() == 18, $sformatf("USB: device descriptor after the bad tokens: %0d bytes", ctl_in.size()));
 000001       $display("  address 0x3F: IN, SETUP and OUT tokens with a wrong stuff bit (bytes intact) ignored");
            end
        
 000001     fw_run = 0;
 000001     check(contention == 0, $sformatf("USB: host and device drove the bus at the same time for %0d clocks", contention));
 000001     check(r_bad == 0, "USB: stuffing errors in the device's packets");
~000001     check(tt_min >= 2.0 && tt_max <= 7.5, $sformatf("USB: device turnaround %0.2f to %0.2f bit times, allowed 2 to 7.5", tt_min, tt_max));
 000001     $display("  %0d SETUPs, %0d IN packets ACKed, %0d records (up to %0d at once); turnaround %0.2f to %0.2f bit times",
 000001              fw_setups, fw_acks, fw_records, fw_max_pile, tt_min, tt_max);
        
 000001     if (errors == 0) begin
 000001       $display("PASS");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          initial begin
            #60ms;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
