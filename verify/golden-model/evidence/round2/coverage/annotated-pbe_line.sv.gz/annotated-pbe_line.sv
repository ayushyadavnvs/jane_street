//      // verilator_coverage annotation
        // Line coder: an optional stage between an engine's shift registers and its line pin(s).
        //
        // It owns the bit timing (one bit every period_m1 + 1 clocks), because bits it inserts or
        // removes (stuffing) must not cost the program anything (v2 lesson, docs/USB_NOTES.md).
        //
        //   cfg[1:0]  mode       0 off, 1 NRZ (the bit is the level), 2 NRZI (0 = change level, 1 = keep)
        //   cfg[3:2]  stuffing   0 none, 1 after 6 ones (USB), 2 after 5 ones (HDLC), 3 after 5 equal (CAN)
        //   cfg[4]    pair       pin a carries the line, pin b its complement; both low (SE0) ends a frame
        //   cfg[5]    bytes      the engine transfers whole bytes (else single bits)
        //
        // Transmit: tx_put queues a byte (or a bit in tx_data[0]), tx_end queues "end of frame"; one
        // entry is buffered (tx_ready). A frame starts with 2 idle bit times (an inter-packet gap) and
        // then sends the sync byte (if not zero), the queued data, and on tx_end: in pair mode SE0, SE0,
        // one bit of idle level, then it lets go of the line; otherwise it lets go at once.
        // Receive: a frame starts when the line leaves the idle level (1). Sampling is mid-bit, and
        // every edge re-centres the bit timer, so clock errors do not add up over a frame. Decoded bits
        // are unstuffed (a stuff bit with the wrong value is an error) and, if sync is not zero,
        // dropped until the last 8 bits equal sync. Then bytes (or bits) are delivered in rx_data.
        // The frame ends on SE0 followed by the idle level (pair mode); otherwise after 8 bit times at
        // the idle level, or when a run at the idle level breaks the stuffing rule. frame_end pulses, and
        // a byte of that frame the engine has not taken is dropped.
        //
        // Cycle contract clarified by the round-2 model audit (existing behavior):
        // - clear/reset empties queues/state, releases drive, sets a_out/b_out=1/0 and previous
        //   level=1, and clears data/valid/event outputs. The engine asserts clear while mode=off;
        //   standalone callers must do so too. Mode 3 is reserved, with no promised behavior.
        // - Transfers observe tx_ready before the edge. A newly queued item is considered on a
        //   later edge; tx_end wins if asserted with tx_put. Producers must not enqueue while
        //   !tx_ready. END without an active frame is consumed without driving. The gap leaves
        //   drive low; after two bit periods, the following clock emits the first sync/data bit.
        // - TX/RX timers are 16 bits and compare the old count. TX boundaries use == period_m1;
        //   RX sample is old_count == floor(period_m1/2)+1. An input edge resets the NEXT count
        //   but does not cancel a sample already due on that edge. At period_m1=0 RX cannot
        //   sample (its count remains 0); there is no universal receive guarantee at that rate.
        // - Sync and payload share stuffing/run state across entry boundaries. Stuffed bits pass
        //   through NRZI too. Initial previous bit/level=1, run=0; inserted ones-style bits reset
        //   run to 0, inserted equal-style bits start a new run of length 1. A TX underrun pulses
        //   err at each empty bit boundary and holds the driven level until new data/end arrives.
        // - RX is suppressed throughout non-idle TX states, including gap and end sequence. A low
        //   level starts RX even without a new edge; SE0 takes priority. Initial NRZI previous
        //   sampled level=1. The sync window is zero-filled, so it can match before 8 received
        //   bits. Transfer bit order follows in_msb_first/out_msb_first, including sync.
        // - A receive stuff violation advances run/sample state; in single mode an idle-high
        //   violation ends the frame without err. Pair SE0 length is not checked: the first later
        //   sampled non-SE0 returns idle, and pulses frame_end only if a_in=1. Single mode's 8th
        //   idle-high sample can also deliver data. Arbitrary data with no sync or long idle runs
        //   is therefore not guaranteed to round-trip without framing restrictions.
        // - RX overrun replaces the unread unit and pulses err; coincident rx_take allows the
        //   replacement without err. frame_end/err are registered one-clock indications. On the
        //   NEXT edge, old frame_end clears rx_valid, winning over a new unit/take that edge.
        // - Release clears drive but keeps output latches. Configuration is read live; changing
        //   mode/period/width/shift direction mid-frame has no protocol-validity guarantee.
        module pbe_line (
 25164486     input  logic        clk,
~000004     input  logic        rst_n,
~000160     input  logic        clear,
~000032     input  logic [7:0]  cfg,
~000031     input  logic [7:0]  sync,
~000032     input  logic [15:0] period_m1,
~000070     input  logic        out_msb_first,
~000070     input  logic        in_msb_first,
            // line pins
~005560     input  logic        a_in,        // synchronized levels
~005356     input  logic        b_in,
~000903     output logic        drive,       // the coder owns the line pin(s)
~004419     output logic        a_out,
~004221     output logic        b_out,
            // transmit
~003536     input  logic        tx_put,
~001048     input  logic        tx_end,
~020161     input  logic [7:0]  tx_data,
~004584     output logic        tx_ready,
            // receive
~000457     output logic        rx_valid,
~000126     output logic [7:0]  rx_data,
~010131     input  logic        rx_take,
~000132     output logic        frame_end,   // pulse
~003595     output logic        err          // pulse: stuff error, receive overrun or transmit underrun
        );
~000016   wire       nrzi  = cfg[1:0] == 2'd2;
~25164488   wire       _unused = &{cfg[7:6], 1'b0};  // reserved
~000008   wire [1:0] st    = cfg[3:2];
~000008   wire       pair  = cfg[4];
~000016   wire       bytes = cfg[5];
~000004   wire       ones  = st != 2'd3;                    // stuff after ones, else after equal bits
~25164488   wire [2:0] run_n = (st == 2'd1) ? 3'd6 : 3'd5;
~25164488   wire [3:0] width = bytes ? 4'd8 : 4'd1;
        
          // ---------------- transmit ----------------
          localparam logic [2:0] T_IDLE = 3'd0, T_GAP = 3'd1, T_RUN = 3'd2, T_SE0A = 3'd3, T_SE0B = 3'd4,
                                 T_J = 3'd5;
~001657   logic [2:0]  ts;
~045552   logic [15:0] tcnt;
~000910   logic        gap2, kick;           // second gap bit; emit a bit now (frame start)
~004584   logic        q_valid, q_end;
~002418   logic [7:0]  q_data, tsh;
~006558   logic [3:0]  tbits;                // bits left in tsh
~004330   logic        level;                // line level, 1 = idle (USB J)
~005049   logic [2:0]  trun;
~004306   logic        tlast, tstuff;        // stuff bit due in the next slot
        
~25164488   assign tx_ready = !q_valid;
~013252   wire boundary = tcnt == period_m1;
        
          // what the next bit slot sends
~25164488   wire        n_load = !tstuff && tbits == 4'd0 && q_valid && !q_end;
~22527749   wire [7:0]  q_bits = (!bytes && out_msb_first) ? {q_data[0], 7'b0} : q_data;
~25164488   wire [7:0]  n_src  = n_load ? q_bits : tsh;
~25164488   wire        n_bit  = tstuff ? (ones ? 1'b0 : !tlast) : (out_msb_first ? n_src[7] : n_src[0]);
~25164488   wire        n_have = tstuff || tbits != 4'd0 || n_load;
~25164488   wire        n_end  = !tstuff && tbits == 4'd0 && q_valid && q_end;
~25164488   wire [3:0]  n_left = n_load ? width - 4'd1 : tbits - 4'd1;
~22527749   wire [7:0]  n_rest = out_msb_first ? {n_src[6:0], 1'b0} : {1'b0, n_src[7:1]};
          // stuffing state after this bit
~005289   logic [2:0] n_run;
~004891   logic       n_last;
 25164488   always_comb begin
~002860     if (tstuff) begin
~002860       n_run  = ones ? 3'd0 : 3'd1;
~002860       n_last = n_bit;
~25164488     end else if (ones) begin
~25164488       n_run  = n_bit ? trun + 3'd1 : 3'd0;
 25164488       n_last = n_bit;
~098254     end else begin
~098254       n_run  = (n_bit == tlast) ? trun + 3'd1 : 3'd1;
~098254       n_last = n_bit;
            end
          end
~25164488   wire n_stuff = !tstuff && st != 2'd0 && n_run == run_n;
~25164488   wire n_level = nrzi ? (n_bit ? level : !level) : n_bit;
        
          // ---------------- receive ----------------
          localparam logic [1:0] R_IDLE = 2'd0, R_RUN = 2'd1, R_SE0 = 2'd2;
~000550   logic [1:0]  rs;
~395353   logic [15:0] rcnt;
~003188   logic        a_d, rprev, rlast, rstuff, hunting;
~001874   logic [2:0]  rrun, ridle;
~000709   logic [7:0]  win, rsh;
~001828   logic [3:0]  rbits;
        
~25164488   wire        se0    = pair && !a_in && !b_in;
~024761   wire        sample = rcnt == {1'b0, period_m1[15:1]} + 16'd1;
~25164488   wire        r_bit  = nrzi ? (a_in == rprev) : a_in;
~25164488   wire        r_exp  = ones ? 1'b0 : !rlast;           // value a stuff bit must have
~007634   logic [2:0] r_run;
 25164488   always_comb begin
~004254     if (rstuff)    r_run = ones ? 3'd0 : 3'd1;
~25164488     else if (ones) r_run = r_bit ? rrun + 3'd1 : 3'd0;
~100169     else           r_run = (r_bit == rlast) ? rrun + 3'd1 : 3'd1;
          end
~22527749   wire [7:0] win_n = in_msb_first ? {win[6:0], r_bit} : {r_bit, win[7:1]};
~22527749   wire [7:0] rsh_n = in_msb_first ? {rsh[6:0], r_bit} : {r_bit, rsh[7:1]};
        
 25164486   always_ff @(posedge clk or negedge rst_n) begin
~25164478     if (!rst_n) begin
~000014       ts <= T_IDLE; tcnt <= '0; gap2 <= 1'b0; kick <= 1'b0;
~000014       q_valid <= 1'b0; q_end <= 1'b0; q_data <= '0; tsh <= '0; tbits <= '0;
~000014       level <= 1'b1; trun <= '0; tlast <= 1'b1; tstuff <= 1'b0;
~000014       drive <= 1'b0; a_out <= 1'b1; b_out <= 1'b0;
~000014       rs <= R_IDLE; rcnt <= '0; a_d <= 1'b1; rprev <= 1'b1; rlast <= 1'b1; rstuff <= 1'b0;
~000014       hunting <= 1'b0; rrun <= '0; ridle <= '0; win <= '0; rsh <= '0; rbits <= '0;
~000014       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0;
~25164478     end else if (clear) begin
~25164478       ts <= T_IDLE; tcnt <= '0; gap2 <= 1'b0; kick <= 1'b0;
~25164478       q_valid <= 1'b0; q_end <= 1'b0; q_data <= '0; tsh <= '0; tbits <= '0;
~25164478       level <= 1'b1; trun <= '0; tlast <= 1'b1; tstuff <= 1'b0;
~25164478       drive <= 1'b0; a_out <= 1'b1; b_out <= 1'b0;
~25164478       rs <= R_IDLE; rcnt <= '0; a_d <= 1'b1; rprev <= 1'b1; rlast <= 1'b1; rstuff <= 1'b0;
~25164478       hunting <= 1'b0; rrun <= '0; ridle <= '0; win <= '0; rsh <= '0; rbits <= '0;
~25164478       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0;
~792106     end else begin
~792106       frame_end <= 1'b0;
~792106       err       <= 1'b0;
        
              // ---- transmit ----
~791799       if (tx_put || tx_end) begin
~004584         q_valid <= 1'b1;
~004584         q_end   <= tx_end;
~004584         q_data  <= tx_data;
              end
~792106       tcnt <= (ts == T_IDLE || boundary || kick) ? 16'd0 : tcnt + 16'd1;
~792106       kick <= 1'b0;
~792106       case (ts)
~700926         T_IDLE:
~700850           if (q_valid) begin
~000915             if (q_end) q_valid <= 1'b0;  // end with no frame: nothing to do
~000915             else begin
~000915               ts   <= T_GAP;
~000915               gap2 <= 1'b0;
                    end
                  end
~007455         T_GAP:
~005642           if (boundary) begin
~001813             gap2 <= 1'b1;
~000910             if (gap2) begin             // the gap is over: start the frame
~000903               ts     <= T_RUN;
~000903               kick   <= 1'b1;
~000903               level  <= 1'b1;
~000903               trun   <= '0;
~000903               tlast  <= 1'b1;
~000903               tstuff <= 1'b0;
~000903               tsh    <= sync;
~000903               tbits  <= (sync != 8'd0) ? 4'd8 : 4'd0;
                    end
                  end
~079020         T_RUN:
~789183           if (boundary || kick) begin
~015437             if (n_have) begin
~015437               level  <= n_level;
~015437               a_out  <= n_level;
~015437               b_out  <= !n_level;
~015437               drive  <= 1'b1;
~015437               trun   <= n_run;
~015437               tlast  <= n_last;
~015437               tstuff <= n_stuff;
~015251               if (!tstuff) begin
~015251                 tsh   <= n_rest;
~015251                 tbits <= n_left;
                      end
~011981               if (n_load) q_valid <= 1'b0;
~008012             end else if (n_end) begin
~000777               q_valid <= 1'b0;
~000402               if (pair) begin
~000375                 ts    <= T_SE0A;
~000375                 a_out <= 1'b0;
~000375                 b_out <= 1'b0;
~000402               end else begin
~000402                 ts    <= T_IDLE;
~000402                 drive <= 1'b0;
                      end
~008012             end else err <= 1'b1;       // underrun: the line keeps its level
                  end
~002432         T_SE0A: if (boundary) ts <= T_SE0B;
~002432         T_SE0B:
~002356           if (boundary) begin
~000367             ts    <= T_J;
~000367             a_out <= 1'b1;
~000367             b_out <= 1'b0;
                  end
~002432         default:                        // T_J: one bit of idle level, then let go
~002356           if (boundary) begin
~000365             ts    <= T_IDLE;
~000365             drive <= 1'b0;
~000365             level <= 1'b1;
                  end
              endcase
        
              // ---- receive (off while transmitting: half duplex) ----
~792106       a_d <= a_in;
~791650       if (rx_take) rx_valid <= 1'b0;
~792106       rcnt <= (a_in != a_d || rcnt == period_m1) ? 16'd0 : rcnt + 16'd1;
~700926       if (ts != T_IDLE) rs <= R_IDLE;
~700926       else case (rs)
~059810         R_IDLE:
~000014           if (se0) rs <= R_SE0;
~059678           else if (!a_in) begin         // the line left the idle level: a frame starts
~000550             rs      <= R_RUN;
~000550             rprev   <= 1'b1;
~000550             rlast   <= 1'b1;
~000550             rrun    <= '0;
~000550             rstuff  <= 1'b0;
~000550             ridle   <= '0;
~000550             hunting <= sync != 8'd0;
~000550             win     <= '0;
~000550             rbits   <= '0;
                  end
~151816         R_RUN:
~147002           if (sample) begin
~004686             if (se0) rs <= R_SE0;
~004686             else begin
~004686               rprev <= a_in;
~004686               rlast <= rstuff ? r_exp : r_bit;
~004686               rrun  <= r_run;
                      // without SE0, a frame ends after 8 bit times at the idle level
~004686               ridle <= a_in ? ridle + 3'd1 : 3'd0;
~004686               if (!pair && a_in && ridle == 3'd7) begin
%000000                 rs        <= R_IDLE;
%000000                 frame_end <= 1'b1;
                      end
~004680               if (rstuff) begin
~000022                 rstuff <= 1'b0;
~000016                 if (r_bit != r_exp) begin
                          // Without SE0, a run too long for stuffing at the idle level is how a frame
                          // ends (HDLC flag or abort, CAN end of frame); anywhere else it is an error.
~000006                   if (!pair && a_in) begin
~000002                     rs        <= R_IDLE;
~000002                     frame_end <= 1'b1;
~000006                   end else err <= 1'b1;
                        end
~004680               end else begin
~004680                 rstuff <= st != 2'd0 && r_run == run_n;
~001024                 if (hunting) begin
~001024                   win <= win_n;
~000896                   if (win_n == sync) hunting <= 1'b0;
~003199                 end else if (rbits == width - 4'd1) begin
~000457                   rx_data  <= bytes ? rsh_n : {7'b0, r_bit};
~000457                   if (rx_valid && !rx_take) err <= 1'b1;  // the engine missed one
~000457                   rx_valid <= 1'b1;
~000457                   rbits    <= '0;
~000457                   rsh      <= rsh_n;
~003199                 end else begin
~003199                   rbits <= rbits + 4'd1;
~003199                   rsh   <= rsh_n;
                        end
                      end
                    end
                  end
~489300         default:                        // R_SE0: wait for the idle level
~679012           if (sample && !se0) begin
~000132             rs        <= R_IDLE;
~000132             frame_end <= a_in;
                  end
              endcase
              // A byte the engine has not taken when its frame ends belongs to that frame: drop it,
              // so it cannot be read as the start of the next frame (BUG-028).
~791974       if (frame_end) rx_valid <= 1'b0;
            end
          end
~25164486   always @(posedge clk) if (rst_n && !clear && (drive || rx_valid || ts != T_IDLE || rs != R_IDLE)) begin
~732297     pbe_cov_line_1_0_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_1_0_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_1_0_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_1_0_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_1_1_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_1_1_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_1_1_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_1_1_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_1_2_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_1_2_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_1_2_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_1_2_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_1_3_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_1_3_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_1_3_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_1_3_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_2_0_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_2_0_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_2_0_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_2_0_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_2_1_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_2_1_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_2_1_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_2_1_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_2_2_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_2_2_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_2_2_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_2_2_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 1);
~732297     pbe_cov_line_2_3_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 0);
~732297     pbe_cov_line_2_3_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 1);
~732297     pbe_cov_line_2_3_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 0);
~732297     pbe_cov_line_2_3_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 1);
          end
        
 000002   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
