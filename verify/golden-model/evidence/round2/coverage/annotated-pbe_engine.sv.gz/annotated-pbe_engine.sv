//      // verilator_coverage annotation
        // One Programmable Bit Engine.
        //
        // Instruction word (16 bits):  [15:13] OP | [12:4] ARG | [3:0] DLY
        // Each instruction issues on a tick and then idles DLY more ticks before the next one.
        // A tick is one clock every (clkdiv + 1) clocks.
        //
        // Instruction fetch (D50): the instruction runs from a register (instr_q), not straight from
        // the program memory, which cuts the clock's worst path in two. The memory is read at `pc`,
        // the word after the current instruction, so the next word is always ready when the current
        // one executes. A taken jump (JMP, JCRCBAD, JEQ, JNE, JLINE, the timeout) must fetch its target
        // first: one clock with no instruction (a bubble). A tick that falls on a bubble is held for
        // that clock, so it is late, never lost. Instruction times:
        //   CLKDIV >= 1: (DLY + 1) * (CLKDIV + 1) clocks, exactly as without the register (the next
        //                tick is at least 2 clocks away, and the bubble fits in between).
        //   CLKDIV = 0, and the line coder (instructions run every clock): DLY + 1 clocks, plus 1 for
        //                a taken jump. The first instruction after a restart starts 1 clock later.
        // A host write to any program word invalidates the next-to-run instruction (one bubble).
        // It does not cancel an instruction already ready to execute on that same edge: that
        // instruction uses the old registered word. If blocked/stopped, the current word is fetched
        // again; after an executing instruction, its successor (or taken target) is fetched again.
        // The memory write commits at the edge, so the subsequent refill sees the updated word.
        //
        //  OP   name        ARG
        //  000  PIN p, act  [8:6] pin, [5:3] act: 0 DRV0, 1 DRV1, 2 REL, 3 TOG, 4 OUT, 5 OUTOD, 6 OUTPAR,
        //                   7 END (line coder: end the frame); [0] NOCRC (OUT/OUTOD): leave this bit out
        //                   of the CRC
        //  001  IN p        [8:6] pin, [5] NOCRC       shift pin into ISR
        //  010  WAIT        [8:6] pin (or flag in [7:6]), [5] 1 = flag, [4:3] 0 LOW, 1 HIGH, 2 RISE, 3 FALL
        //  011  JMP         [8:6] cond, [5:0] addr    cond: 0 ALWAYS, 1 X-- != 0, 2 PIN_HI, 3 PIN_LO,
        //                                             4 TX_EMPTY, 5 TX_READY, 6 FLAG0, 7 FLAG1
        //  100  SET         [8] 0 = X, 1 = OSR; [7:0] value
        //  101  PULL/PUSH   [8] 0 = PULL (TX FIFO -> OSR), 1 = PUSH (ISR -> RX FIFO, then clear ISR)
        //  110  FLAG        [8:7] 0 SET, 1 CLR, 2 IRQ, 3 MOV; [1:0] flag
        //                   MOV: [5:4] destination, [3:2] source: 1 X, 2 OSR, 3 ISR (source 0: zero);
        //                   destination 0 does nothing (0xD800 is the assembler's NOP)
        //  111  EXT         [8:6] sub-op, [5:0] param
        //                   0 CRCRST      load the CRC's initial value and clear the line error: a new
        //                                 checked packet starts
        //                   1 OSRCRC      OSR <= CRC byte (param[0]: 0 low, 1 high; param[1]: inverted)
        //                   2 STAT        ISR <= {3'b0, line error, RX overflow, timeout happened, CRC ok,
        //                                 parity error}; then clears parity and timeout (not the line
        //                                 error: a JCRCBAD after STAT must still see it)
        //                   3 JCRCBAD a   jump to a if the packet is bad: the CRC is not ok (not at its
        //                                 good value) or the line coder saw an error since the last CRCRST
        //                   4 JEQ a       jump to a if ISR == OSR
        //                   5 JNE a       jump to a if ISR != OSR
        //                   6 JLINE a     jump to a if the line coder saw the end of a frame; clears it
        //                   7             reserved, executes as nothing
        //
        // Parity: OUT/OUTOD bits since the last OSR load make the send parity; OUTPAR drives it
        // (inverted for odd parity). IN bits since the last STAT make the receive parity; with the
        // parity bit included it must come out 0 (even) or 1 (odd), otherwise STAT reports an error.
        // With line_cfg[6] (no parity) OUTPAR sends 1 (a second stop bit) and no parity error is reported.
        // RX overflow: a PUSH that finds the RX FIFO full sets a sticky status bit and raises IRQ.
        // CRC: OUT/OUTOD and IN bits feed the CRC unit when enabled in crc_cfg, unless marked NOCRC.
        // "CRC ok" means the register equals crc_good (0 for CRCs sent plain; the residual, e.g. USB's
        // 0x800d, for CRCs sent inverted).
        //
        // Line coder (coder_cfg[1:0] != 0, see pbe_line): it drives pin_base (and pin_base + 1 in pair
        // mode) and sets the bit timing: clkdiv is then the bit time minus 1, and instructions run
        // every clock. OUT/OUTOD hand the coder a byte (or one bit) and wait while it is busy; END ends
        // the frame; IN takes a received byte (or bit) and waits for one, or for the end of the frame
        // (then ISR is unchanged and JLINE jumps). In byte mode the 8 bits of each OUT/IN feed the CRC
        // one per clock afterwards; the next instruction waits until they are in.
        // Timeout: if WAIT, PULL or PUSH stays blocked for timeout ticks (0 = never), the engine
        // abandons it, jumps to timeout_pc and sets the "timeout happened" status bit.
        //
        // WAIT, PULL and PUSH block until they can complete. While blocked the engine checks
        // every clock (not every tick), and when it unblocks the tick divider restarts, so
        // following instructions are timed from the moment the condition was met.
        //
        // Pin numbers are relative to pin_base (mod 8); the JMP pin is jmp_pin + pin_base.
        // Program addresses are relative to start_pc: a program starts at its own word 0, and every
        // jump (JMP, JCRCBAD, JEQ, JNE, JLINE, the timeout) goes to (start_pc + target) mod 128.
        // A target is 6 bits; this is a branch-offset window, not a memory-protection boundary.
        // Sequential execution increments the full 7-bit PC and can leave that window or wrap 127->0.
        //
        // Cycle contract, clarified by the round-2 model audit (existing behavior, no RTL change):
        // - All decisions use pre-edge inputs/state. Reset zeros engine state and CRC; restart
        //   cancels execution, resets registers/counters/status/parity, releases all enables,
        //   preserves the output latch and previous sampled pins/flags, and initializes CRC.
        //   The 16-bit divider is due when count >= clkdiv; changing CLKDIV live can make a tick
        //   immediately due. Delay counts are 4 bits, timeout and divider counts are 16 bits.
        // - An empty fetch register fills even while stopped. run=0 freezes instruction/divider/
        //   timeout execution, but previous pins/flags, host clears, line events, byte CRC feed,
        //   and the line coder continue. A restart/disabled coder clears the line coder.
        // - WAIT RISE/FALL compares this clock's synchronized value with the preceding clock,
        //   including clocks while stopped or fetching; edges are not latched until a WAIT sees them.
        // - X-- tests old X and decrements only if nonzero. OUTOD latches 0 and enables only for a
        //   zero bit. REL preserves the latch. END with coder off and reserved EXT7 do nothing.
        //   Byte-mode OUT/OUTOD do not shift OSR. Every OSR load resets transmit parity; MOV/PUSH
        //   writes to ISR do not reset receive parity. An IN released by frame end keeps ISR but
        //   still XORs the coder data bit into receive parity (CRC is not fed without valid data).
        // - Timeout counts ticks after the first blocked issue, tests the old count every clock,
        //   and can affect any not-ready instruction (including coder/CRC stalls). Ready completion
        //   wins over timeout. A fetch bubble cannot time out. Bounds require run to stay set,
        //   no restart/PM writes/config changes, and a permanently unmet condition.
        // - RX-full IRQ pulses only on the first observed overflow until overflow is cleared.
        //   Host overflow/line-error clears win over their corresponding new events. A new line
        //   end wins over JLINE consumption. Without a host clear, CRCRST preserves a coincident
        //   coder error; STAT reads
        //   old status then clears parity/timeout. Host CRC init wins over CRC feed but does not
        //   cancel an already pending byte-feed queue. Byte feeds advance while stopped.
        // - Restart wins over PM invalidation; a taken branch/timeout retains its target on a PM
        //   write. Other writes refetch pc-1 if valid and not executing, else pc. Delays survive
        //   PM invalidation. Fetch validity describes a snapshot, not equality to live RAM after
        //   a write; a host write does not suppress same-edge instruction/FIFO/flag side effects.
        module pbe_engine (
 25164486     input  logic        clk,
~000004     input  logic        rst_n,
~000020     input  logic        run,
~000064     input  logic        restart,  // 1-cycle pulse
            // configuration
~000006     input  logic [15:0] clkdiv,
~000003     input  logic [2:0]  pin_base,
~000004     input  logic [2:0]  jmp_pin,
~000003     input  logic        out_msb_first,
~000003     input  logic        in_msb_first,
~000002     input  logic [6:0]  start_pc,     // where this engine's program starts (its word 0)
~000004     input  logic [15:0] crc_poly,
~000004     input  logic [7:0]  crc_cfg,      // [3:0] width-1, [4] init ones, [5] reversed, [6] feed OUT, [7] feed IN
~000002     input  logic [15:0] timeout,      // ticks a blocked instruction may wait (0 = forever)
~000004     input  logic [7:0]  line_cfg,     // [5:0] timeout_pc, [6] no parity, [7] odd parity
~000032     input  logic [7:0]  coder_cfg,    // line coder, see pbe_line (0 = off)
~000001     input  logic [7:0]  sync,         // line coder frame start pattern
~000001     input  logic [15:0] crc_good,     // the CRC value that means "ok"
~000006     input  logic        host_crc_init,
~000002     input  logic        host_tmo_clr,
~000001     input  logic        host_ovf_clr,
~000001     input  logic        host_lerr_clr,
~001014     output logic [4:0]  status,       // {line error, RX overflow, timeout happened, CRC ok, parity error}
~000641     output logic [15:0] crc_now,      // the CRC unit's current value, for the host
            // program memory
~123001     output logic [6:0]  pc,           // program memory read address (absolute): the next word
~123001     output logic [20:0] pc_copy,      // three more copies of pc, to share out its fan-out
~093109     input  logic [15:0] instr,        // the program memory word at pc
~004096     input  logic        pm_wr,        // the host is writing the program memory (any word)
            // pins
~008690     input  logic [7:0]  pins_in,  // synchronized
~000921     output logic [7:0]  pins_out,
~004344     output logic [7:0]  pins_oe,  // (the line coder's pins are merged in combinationally)
            // TX FIFO (host to engine)
~000599     input  logic [7:0]  tx_data,
~001797     input  logic        tx_empty,
~001860     output logic        tx_pop,
            // RX FIFO (engine to host)
~001039     output logic [7:0]  rx_data,
~000003     input  logic        rx_full,
~001966     output logic        rx_push,
            // shared flags
~000219     input  logic [3:0]  flags,
~000129     output logic [3:0]  flag_set,
~000217     output logic [3:0]  flag_clr,
~000045     output logic        irq
        );
          localparam logic [2:0] OP_PIN = 3'd0, OP_IN = 3'd1, OP_WAIT = 3'd2, OP_JMP = 3'd3,
                                 OP_SET = 3'd4, OP_FIFO = 3'd5, OP_FLAG = 3'd6, OP_EXT = 3'd7;
          localparam logic [2:0] E_CRCRST = 3'd0, E_OSRCRC = 3'd1, E_STAT = 3'd2, E_JCRCBAD = 3'd3,
                                 E_JEQ = 3'd4, E_JNE = 3'd5, E_JLINE = 3'd6;
        
~7368274   logic [15:0] div_cnt;
~064017   logic [3:0]  dly_cnt;
~001011   logic        blocked;
~003730   logic [7:0]  x, osr, isr;
~008690   logic [7:0]  pins_prev;
~000219   logic [3:0]  flags_prev;
~002184   logic        par_out, par_in, tmo_seen, rx_ovf;
~389549   logic [15:0] tmo_cnt;
~004344   logic [7:0]  pout, poe;   // the pin unit's own drive; the line coder can take over its pins
~000132   logic        line_ev, line_err;
~001096   logic [3:0]  cf_cnt;      // byte mode: CRC bits still to feed
~000258   logic [7:0]  cf_sh;
~058463   logic [15:0] instr_q;     // the current instruction
 060987   logic        iv;          // instr_q holds the word at pc - 1 (else it is being fetched from pc)
        
          // ---- decode ----
~016367   wire [2:0] op  = instr_q[15:13];
~058463   wire [8:0] arg = instr_q[12:4];
~009556   wire [3:0] dly = instr_q[3:0];
        
~058463   wire [2:0] arg_pin  = arg[8:6];
~055508   wire [2:0] pin_act  = arg[5:3];
~055508   wire [1:0] wait_cnd = arg[4:3];
~058463   wire [2:0] jmp_cnd  = arg[8:6];
~050625   wire [1:0] flag_act = arg[8:7];
~050625   wire       arg_hi   = arg[8];
        
~058464   wire [2:0] pin_idx = pin_base + arg_pin;
~000004   wire [2:0] jmp_idx = pin_base + jmp_pin;
~019792   wire       pin_now = pins_in[pin_idx];
~019396   wire       pin_was = pins_prev[pin_idx];
        
~22527749   wire       out_bit = out_msb_first ? osr[7] : osr[0];
~22527749   wire [7:0] osr_shifted = out_msb_first ? {osr[6:0], 1'b0} : {1'b0, osr[7:1]};
~22527749   wire [7:0] isr_shifted = in_msb_first ? {isr[6:0], pin_now} : {pin_now, isr[7:1]};
        
~058463   wire [2:0] ext_op   = arg[8:6];
%000000   wire       odd      = line_cfg[7];
~000004   wire       no_par   = line_cfg[6];
~000003   wire [5:0] tmo_pc   = line_cfg[5:0];
~14348481   wire       par_err  = !no_par && (par_in ^ odd);
~15287933   wire       par_bit  = no_par || (par_out ^ odd);  // what OUTPAR sends
        
          // ---- line coder ----
~000016   wire       coder_on = coder_cfg[1:0] != 2'd0;
~000001   wire       coder_bytes = coder_cfg[5];
~000002   wire       coder_pair = coder_cfg[4];
~000004   wire [2:0] base1 = pin_base + 3'd1;
~25164488   wire       is_txop = coder_on && op == OP_PIN && (pin_act == 3'd4 || pin_act == 3'd5 || pin_act == 3'd7);
~000923   logic       l_drive, l_a, l_b, l_ready, l_rxv, l_end, l_err;
~000126   logic [7:0] l_rxd;
        
          // ---- issue and readiness ----
~24702803   wire tick_due = coder_on || (div_cnt >= clkdiv);
~24702803   wire tick     = tick_due && iv;  // a tick that falls on a fetch bubble waits for it
~18024001   wire issue    = run && iv && (blocked || (tick && dly_cnt == 4'd0));
        
~17590522   wire now = arg[5] ? flags[arg[7:6]] : pin_now;
~17590522   wire was = arg[5] ? flags_prev[arg[7:6]] : pin_was;
        
~018455   logic wait_ok;
 25164488   always_comb begin
 25164488     case (wait_cnd)
~14266623       2'd0:    wait_ok = !now;
~1457580       2'd1:    wait_ok = now;
~14265403       2'd2:    wait_ok = !was && now;
~14266623       default: wait_ok = was && !now;
            endcase
          end
        
~004634   logic ready;
 25164488   always_comb begin
 25164488     case (op)
~1695352       OP_WAIT: ready = wait_ok;
~14979410       OP_FIFO: ready = arg_hi ? !rx_full : !tx_empty;
~25164488       OP_PIN:  ready = !is_txop || l_ready;
~25164488       OP_IN:   ready = !coder_on || l_rxv || line_ev;
 19783639       default: ready = 1'b1;
            endcase
~25164488     if (cf_cnt != 4'd0) ready = 1'b0;  // byte-mode CRC feed still running
          end
        
          // A restart in the same cycle cancels the instruction, so it has no side effects.
~23359518   wire exec = issue && ready && !restart;
        
          // A blocked instruction that has waited `timeout` ticks is abandoned.
~23467849   wire tmo_hit = run && !restart && iv && blocked && !ready && timeout != 16'd0 && tmo_cnt >= timeout;
        
          // ---- CRC unit, fed by the bits the engine shifts ----
~24974376   wire is_out = exec && op == OP_PIN && (pin_act == 3'd4 || pin_act == 3'd5);
~24974376   wire is_in  = exec && op == OP_IN && (!coder_on || l_rxv);  // not an IN ended by end of frame
~25164488   wire in_bit = coder_on ? l_rxd[0] : pin_now;
~25158051   wire crc_out = is_out && !arg[0] && crc_cfg[6];
~25157992   wire crc_in  = is_in && !arg[5] && crc_cfg[7];
~000641   logic [15:0] crc_value;
~000023   logic        crc_ok;
        
          // byte mode: the CRC takes the byte's bits in wire order, one per clock
~25164008   wire [7:0] cf_byte = crc_out ? osr : l_rxd;
~25164008   wire       cf_msb  = crc_out ? out_msb_first : in_msb_first;
~22527749   wire [7:0] cf_load = cf_msb ? {cf_byte[0], cf_byte[1], cf_byte[2], cf_byte[3],
~22527749                                  cf_byte[4], cf_byte[5], cf_byte[6], cf_byte[7]} : cf_byte;
~25164488   wire       cf_start = coder_on && coder_bytes && (crc_out || crc_in);
        
          pbe_crc u_crc (
              .clk, .rst_n,
              .init     (host_crc_init || restart || (exec && op == OP_EXT && ext_op == E_CRCRST)),
              .step     (cf_cnt != 4'd0 || (!cf_start && (crc_out || crc_in))),
              .bit_in   (cf_cnt != 4'd0 ? cf_sh[0] : is_out ? out_bit : in_bit),
              .poly     (crc_poly),
              .width_m1 (crc_cfg[3:0]),
              .init_ones(crc_cfg[4]),
              .out_rev  (crc_cfg[5]),
              .good     (crc_good),
              .value    (crc_value),
              .ok       (crc_ok)
          );
        
          assign status  = {line_err, rx_ovf, tmo_seen, crc_ok, par_err};
          assign crc_now = crc_value;
        
          pbe_line u_line (
              .clk, .rst_n,
              .clear        (restart || !coder_on),
              .cfg          (coder_cfg),
              .sync,
              .period_m1    (clkdiv),
              .out_msb_first,
              .in_msb_first,
              .a_in         (pins_in[pin_base]),
              .b_in         (pins_in[base1]),
              .drive        (l_drive),
              .a_out        (l_a),
              .b_out        (l_b),
              .tx_put       (exec && is_txop && pin_act != 3'd7),
              .tx_end       (exec && is_txop && pin_act == 3'd7),
              .tx_data      (coder_bytes ? osr : {7'b0, out_bit}),
              .tx_ready     (l_ready),
              .rx_valid     (l_rxv),
              .rx_data      (l_rxd),
              .rx_take      (exec && coder_on && op == OP_IN && l_rxv),
              .frame_end    (l_end),
              .err          (l_err)
          );
        
          // the coder's pins override the pin unit while it drives them
~25164488   wire [7:0] l_mask = l_drive ? ((8'd1 << pin_base) | (coder_pair ? 8'd1 << base1 : 8'd0)) : 8'd0;
~000923   wire [7:0] l_val  = ({7'd0, l_a} << pin_base) | ({7'd0, l_b} << base1);
          assign pins_out = (pout & ~l_mask) | (l_val & l_mask);
          assign pins_oe  = poe | l_mask;
        
          // A PUSH that finds the RX FIFO full: the host is not keeping up.
~25106361   wire ovf_now = run && !restart && issue && op == OP_FIFO && arg_hi && rx_full;
        
~052878   logic jmp_take;
 25164488   always_comb begin
 25164488     case (jmp_cnd)
 4927787       3'd0:    jmp_take = 1'b1;
~4840526       3'd1:    jmp_take = (x != 8'd0);
~148870       3'd2:    jmp_take = pins_in[jmp_idx];
~21430617       3'd3:    jmp_take = !pins_in[jmp_idx];
~212920       3'd4:    jmp_take = tx_empty;
~23353344       3'd5:    jmp_take = !tx_empty;
~12870489       3'd6:    jmp_take = flags[0];
~741854       default: jmp_take = flags[1];
            endcase
          end
        
          // MOV: FLAG action 3 with a destination
~22647853   wire       is_mov  = op == OP_FLAG && flag_act == 2'd3 && arg[5:4] != 2'd0;
~006796   logic [7:0] mov_val;
 25164488   always_comb begin
 25164488     case (arg[3:2])
~1321511       2'd1:    mov_val = x;
~3549362       2'd2:    mov_val = osr;
~739455       2'd3:    mov_val = isr;
 19554160       default: mov_val = 8'd0;
            endcase
          end
~25164488   wire jline_take = exec && op == OP_EXT && ext_op == E_JLINE && line_ev;
        
          // a jump the current instruction takes if it executes: the next word must be fetched again
~054796   logic jump;
 25164488   always_comb begin
 25164488     case (op)
~17004538       OP_JMP: jump = jmp_take;
~052349       OP_EXT:
~052349         case (ext_op)
~13969327           E_JCRCBAD: jump = !crc_ok || line_err;
~001350           E_JEQ:     jump = isr == osr;
~000177           E_JNE:     jump = isr != osr;
~004543           E_JLINE:   jump = line_ev;
~052349           default:   jump = 1'b0;
                endcase
 8107601       default: jump = 1'b0;
            endcase
          end
~055067   wire [6:0] jump_pc = start_pc + {1'b0, arg[5:0]};
        
          // ---- fetch address ----
~123002   logic [6:0] pc_next;
 25164488   always_comb begin
 25164488     pc_next = pc;
~25164468     if (restart) pc_next = start_pc;
 25164468     else begin
 25103472       if (!iv) pc_next = pc + 1'b1;  // the fetch fills instr_q: read on
~24974356       if (exec) pc_next = jump ? jump_pc : pc + 1'b1;
~25164427       if (tmo_hit) pc_next = start_pc + {1'b0, tmo_pc};
              // A host write to the program memory may change the current or the next word: fetch the
              // instruction that runs next again (a jump fetches its target anyway). pm_wr appears only
              // in `if`s: the unit testbenches leave it unconnected, and z must read as no write.
~25160372       if (pm_wr && !(exec && jump) && !tmo_hit) pc_next = (iv && !exec) ? pc - 1'b1 : pc;
            end
          end
        
          // pc drives the read multiplexers of all 16 bits of the program memory: thousands of inputs,
          // which place and route had to reach through long buffer chains (D50). Four copies each read
          // 4 bits. `keep` stops synthesis from merging them back into one register.
          (* keep *)
 25164486   always_ff @(posedge clk or negedge rst_n) begin
 25164478     if (!rst_n) begin
 000014       pc      <= '0;
 000014       pc_copy <= '0;
 25164478     end else begin
 25164478       pc      <= pc_next;
 25164478       pc_copy <= {3{pc_next}};
            end
          end
        
          // ---- side-effect pulses (combinational, valid in the exec cycle) ----
~24974376   assign tx_pop   = exec && op == OP_FIFO && !arg_hi;
~24974376   assign rx_push  = exec && op == OP_FIFO && arg_hi;
          assign rx_data  = isr;
~25164339   assign flag_set = (exec && op == OP_FLAG && flag_act == 2'd0) ? (4'b0001 << arg[1:0]) : 4'b0000;
~25164131   assign flag_clr = (exec && op == OP_FLAG && flag_act == 2'd1) ? (4'b0001 << arg[1:0]) : 4'b0000;
~24957829   assign irq      = (exec && op == OP_FLAG && flag_act == 2'd2) || (ovf_now && !rx_ovf);
        
          // ---- state ----
 25164486   always_ff @(posedge clk or negedge rst_n) begin
 25164478     if (!rst_n) begin
 000014       instr_q    <= '0;
 000014       iv         <= 1'b0;
 000014       div_cnt    <= '0;
 000014       dly_cnt    <= '0;
 000014       blocked    <= 1'b0;
 000014       x          <= '0;
 000014       osr        <= '0;
 000014       isr        <= '0;
 000014       pout       <= '0;
 000014       poe        <= '0;
 000014       line_ev    <= 1'b0;
 000014       line_err   <= 1'b0;
 000014       cf_cnt     <= '0;
 000014       cf_sh      <= '0;
 000014       pins_prev  <= '0;
 000014       flags_prev <= '0;
 000014       par_out    <= 1'b0;
 000014       par_in     <= 1'b0;
 000014       tmo_seen   <= 1'b0;
 000014       tmo_cnt    <= '0;
 000014       rx_ovf     <= 1'b0;
~25164458     end else if (restart) begin
~000064       iv       <= 1'b0;
~000064       div_cnt  <= '0;
~000064       dly_cnt  <= '0;
~000064       blocked  <= 1'b0;
~000064       x        <= '0;
~000064       osr      <= '0;
~000064       isr      <= '0;
~000064       poe      <= '0;  // release every pin; keep pout so a line held high cannot glitch low
~000064       line_ev  <= 1'b0;
~000064       line_err <= 1'b0;
~000064       cf_cnt   <= '0;
~000064       par_out  <= 1'b0;
~000064       par_in   <= 1'b0;
~000064       tmo_seen <= 1'b0;
~000064       tmo_cnt  <= '0;
~000064       rx_ovf   <= 1'b0;
 25164458     end else begin
 25164458       pins_prev  <= pins_in;
 25164458       flags_prev <= flags;
~25164458       if (host_tmo_clr) tmo_seen <= 1'b0;
~000001       if (host_ovf_clr) rx_ovf <= 1'b0;
~25147910       else if (ovf_now) rx_ovf <= 1'b1;
~25164458       line_ev <= (line_ev && !jline_take) || l_end;
~000001       if (host_lerr_clr) line_err <= 1'b0;
~25164458       else if (l_err) line_err <= 1'b1;
~002192       if (cf_cnt != 4'd0) begin
~002192         cf_cnt <= cf_cnt - 4'd1;
~002192         cf_sh  <= {1'b0, cf_sh[7:1]};
~25164458       end else if (cf_start) begin
~000274         cf_cnt <= 4'd8;
~000274         cf_sh  <= cf_load;
              end
        
              // fetch: fill an empty instruction register (also while stopped)
~25103471       if (!iv) begin
 060987         instr_q <= instr;
 060987         iv      <= 1'b1;
              end
        
~14752269       if (run) begin
                // tick divider; restarts when a blocked instruction completes
~14562116         if ((exec && blocked) || tmo_hit) div_cnt <= '0;
~786545         else if (tick) div_cnt <= '0;
~14433443         else if (!tick_due) div_cnt <= div_cnt + 1'b1;
        
~14636394         if (tick && dly_cnt != 4'd0 && !blocked) dly_cnt <= dly_cnt - 1'b1;
        
~13137411         if (issue && !ready) blocked <= 1'b1;
        
                // timeout counter: ticks spent blocked
~13137466         if (!blocked) tmo_cnt <= '0;
~1602796         else if (tick) tmo_cnt <= tmo_cnt + 1'b1;
        
~14562157         if (exec) begin
~190112           blocked <= 1'b0;
~190112           dly_cnt <= dly;
~133283           if (jump) iv <= 1'b0;
~133283           else instr_q <= instr;  // the next word, already read at pc
        
~190112           case (op)
~019399             OP_PIN: begin
~019399               if (coder_on && is_txop) begin
~000307                 if (!coder_bytes && pin_act != 3'd7) osr <= osr_shifted;  // bit mode shifts
~019399               end else case (pin_act)
~006373                 3'd0: begin pout[pin_idx] <= 1'b0;                 poe[pin_idx] <= 1'b1;     end
~000240                 3'd1: begin pout[pin_idx] <= 1'b1;                 poe[pin_idx] <= 1'b1;     end
~006357                 3'd2: begin                                            poe[pin_idx] <= 1'b0;     end
~000036                 3'd3: begin pout[pin_idx] <= ~pout[pin_idx];   poe[pin_idx] <= 1'b1;     end
~000744                 3'd4: begin pout[pin_idx] <= out_bit;              poe[pin_idx] <= 1'b1;
~000744                             osr <= osr_shifted;                                                      end
~005693                 3'd5: begin pout[pin_idx] <= 1'b0;                 poe[pin_idx] <= !out_bit;
~005693                             osr <= osr_shifted;                                                      end
~000080                 3'd6: begin pout[pin_idx] <= par_bit;              poe[pin_idx] <= 1'b1;     end
~000019                 default: ;
                      endcase
                    end
~006496             OP_IN: begin
~006496               if (!coder_on) isr <= isr_shifted;
~000456               else if (l_rxv) isr <= coder_bytes ? l_rxd
%000000                                                  : (in_msb_first ? {isr[6:0], l_rxd[0]} : {l_rxd[0], isr[7:1]});
~006496               par_in <= par_in ^ in_bit;
                    end
~150152             OP_JMP: begin
~143300               if (jmp_cnd == 3'd1 && x != 8'd0) x <= x - 1'b1;
                    end
~001668             OP_SET: begin
~001668               if (arg_hi) begin
~000438                 osr     <= arg[7:0];
~000438                 par_out <= 1'b0;
~001668               end else x <= arg[7:0];
                    end
~003890             OP_FLAG: if (is_mov)
~000445               case (arg[5:4])
~000149                 2'd1: x <= mov_val;
~000148                 2'd2: begin
~000148                   osr     <= mov_val;
~000148                   par_out <= 1'b0;
                        end
~000148                 default: isr <= mov_val;
                      endcase
~003826             OP_FIFO: begin
~001966               if (arg_hi) isr <= '0;
~001860               else begin
~001860                 osr     <= tx_data;
~001860                 par_out <= 1'b0;
                      end
                    end
~003629             OP_EXT: begin
~003629               case (ext_op)
~000053                 E_OSRCRC: begin
~000053                   osr     <= (arg[0] ? crc_value[15:8] : crc_value[7:0]) ^ {8{arg[1]}};
~000053                   par_out <= 1'b0;
                        end
~003629                 E_CRCRST:  if (!l_err) line_err <= 1'b0;  // an error in this very clock stays
~000079                 E_STAT: begin
~000079                   isr      <= {3'b0, line_err, rx_ovf, tmo_seen, crc_ok, par_err};
~000079                   par_in   <= 1'b0;
~000079                   tmo_seen <= 1'b0;
                        end
~003515                 default: ;  // the jumps are above
                      endcase
                    end
~004562             default: ;
                  endcase
~183675           if (is_out) par_out <= par_out ^ out_bit;
                end
        
                // timeout: abandon the blocked instruction and jump to the timeout routine
~14752228         if (tmo_hit) begin
~000103           iv       <= 1'b0;
~000103           blocked  <= 1'b0;
~000103           dly_cnt  <= '0;
~000103           tmo_seen <= 1'b1;
                end
              end
        
~25160362       if (pm_wr) iv <= 1'b0;  // see pc_next
            end
          end
~001014   reg [4:0] pbe_cov_previous_status;
 25164486   always @(posedge clk) begin
 25164478     if (!rst_n) pbe_cov_previous_status <= 0;
 25164478     else pbe_cov_previous_status <= status;
 25164478     if (rst_n) begin
~25164478     pbe_cov_opcode_0: cover (exec && op == 3'd0);
~25164478     pbe_cov_opcode_1: cover (exec && op == 3'd1);
~25164478     pbe_cov_opcode_2: cover (exec && op == 3'd2);
~25164478     pbe_cov_opcode_3: cover (exec && op == 3'd3);
~25164478     pbe_cov_opcode_4: cover (exec && op == 3'd4);
~25164478     pbe_cov_opcode_5: cover (exec && op == 3'd5);
~25164478     pbe_cov_opcode_6: cover (exec && op == 3'd6);
~25164478     pbe_cov_opcode_7: cover (exec && op == 3'd7);
~25164478     pbe_cov_sub_0_0: cover (exec && op == 3'd0 && pin_act == 0);
~25164478     pbe_cov_sub_0_1: cover (exec && op == 3'd0 && pin_act == 1);
~25164478     pbe_cov_sub_0_2: cover (exec && op == 3'd0 && pin_act == 2);
~25164478     pbe_cov_sub_0_3: cover (exec && op == 3'd0 && pin_act == 3);
~25164478     pbe_cov_sub_0_4: cover (exec && op == 3'd0 && pin_act == 4);
~25164478     pbe_cov_sub_0_5: cover (exec && op == 3'd0 && pin_act == 5);
~25164478     pbe_cov_sub_0_6: cover (exec && op == 3'd0 && pin_act == 6);
~25164478     pbe_cov_sub_0_7: cover (exec && op == 3'd0 && pin_act == 7);
~25164478     pbe_cov_sub_5_0: cover (exec && op == 3'd5 && arg_hi == 0);
~25164478     pbe_cov_sub_5_1: cover (exec && op == 3'd5 && arg_hi == 1);
~25164478     pbe_cov_sub_6_0: cover (exec && op == 3'd6 && flag_act == 0);
~25164478     pbe_cov_sub_6_1: cover (exec && op == 3'd6 && flag_act == 1);
~25164478     pbe_cov_sub_6_2: cover (exec && op == 3'd6 && flag_act == 2);
~25164478     pbe_cov_sub_6_3: cover (exec && op == 3'd6 && flag_act == 3);
~25164478     pbe_cov_sub_7_0: cover (exec && op == 3'd7 && ext_op == 0);
~25164478     pbe_cov_sub_7_1: cover (exec && op == 3'd7 && ext_op == 1);
~25164478     pbe_cov_sub_7_2: cover (exec && op == 3'd7 && ext_op == 2);
~25164478     pbe_cov_sub_7_3: cover (exec && op == 3'd7 && ext_op == 3);
~25164478     pbe_cov_sub_7_4: cover (exec && op == 3'd7 && ext_op == 4);
~25164478     pbe_cov_sub_7_5: cover (exec && op == 3'd7 && ext_op == 5);
~25164478     pbe_cov_sub_7_6: cover (exec && op == 3'd7 && ext_op == 6);
~25164478     pbe_cov_sub_7_7: cover (exec && op == 3'd7 && ext_op == 7);
~25164478     pbe_cov_jump_0: cover (exec && op == OP_JMP && jmp_cnd == 0);
~25164478     pbe_cov_jump_1: cover (exec && op == OP_JMP && jmp_cnd == 1);
~25164478     pbe_cov_jump_2: cover (exec && op == OP_JMP && jmp_cnd == 2);
~25164478     pbe_cov_jump_3: cover (exec && op == OP_JMP && jmp_cnd == 3);
~25164478     pbe_cov_jump_4: cover (exec && op == OP_JMP && jmp_cnd == 4);
~25164478     pbe_cov_jump_5: cover (exec && op == OP_JMP && jmp_cnd == 5);
~25164478     pbe_cov_jump_6: cover (exec && op == OP_JMP && jmp_cnd == 6);
~25164478     pbe_cov_jump_7: cover (exec && op == OP_JMP && jmp_cnd == 7);
~25164478     pbe_cov_wait_0_0: cover (exec && op == OP_WAIT && arg[5] == 0 && wait_cnd == 0);
~25164478     pbe_cov_wait_0_1: cover (exec && op == OP_WAIT && arg[5] == 0 && wait_cnd == 1);
~25164478     pbe_cov_wait_0_2: cover (exec && op == OP_WAIT && arg[5] == 0 && wait_cnd == 2);
~25164478     pbe_cov_wait_0_3: cover (exec && op == OP_WAIT && arg[5] == 0 && wait_cnd == 3);
~25164478     pbe_cov_wait_1_0: cover (exec && op == OP_WAIT && arg[5] == 1 && wait_cnd == 0);
~25164478     pbe_cov_wait_1_1: cover (exec && op == OP_WAIT && arg[5] == 1 && wait_cnd == 1);
~25164478     pbe_cov_wait_1_2: cover (exec && op == OP_WAIT && arg[5] == 1 && wait_cnd == 2);
~25164478     pbe_cov_wait_1_3: cover (exec && op == OP_WAIT && arg[5] == 1 && wait_cnd == 3);
~25164478     pbe_cov_timeout_taken: cover (tmo_hit);
~25164478     pbe_cov_rx_overflow: cover (ovf_now);
~25164478     pbe_cov_d50_refetch: cover (run && pm_wr && iv);
~25164478     pbe_cov_status_0_set: cover (status[0] && !pbe_cov_previous_status[0]);
~25164478     pbe_cov_status_0_clear: cover (!status[0] && pbe_cov_previous_status[0]);
~25164478     pbe_cov_status_1_set: cover (status[1] && !pbe_cov_previous_status[1]);
~25164478     pbe_cov_status_1_clear: cover (!status[1] && pbe_cov_previous_status[1]);
~25164478     pbe_cov_status_2_set: cover (status[2] && !pbe_cov_previous_status[2]);
~25164478     pbe_cov_status_2_clear: cover (!status[2] && pbe_cov_previous_status[2]);
~25164478     pbe_cov_status_3_set: cover (status[3] && !pbe_cov_previous_status[3]);
~25164478     pbe_cov_status_3_clear: cover (!status[3] && pbe_cov_previous_status[3]);
~25164478     pbe_cov_status_4_set: cover (status[4] && !pbe_cov_previous_status[4]);
~25164478     pbe_cov_status_4_clear: cover (!status[4] && pbe_cov_previous_status[4]);
            end
          end
        
 000002   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
