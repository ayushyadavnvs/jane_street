//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // End-to-end test of programs/can_node.pbe through the chip's pins (D72).
        //
        // Bus: a wired-AND CAN bus. Each node has its own transceiver model: TXD reaches the bus after
        // TXD_NS, the bus reaches RXD after RXD_NS (loop delay 200 ns at the chip's pins, plus the
        // chip's 2-clock input synchronizer). Nodes: engine 0 (TXD pin 0, RXD pin 1), engine 1 (TXD pin
        // 2, RXD pin 3), and two reference nodes (can_ref_node.sv, written from ISO 11898-1) with clock
        // errors of +0.5 % and -0.5 %. A disturber can force the bus dominant to inject errors.
        // The host model talks to the chip over SPI only; it reads each record at the IRQ.
        //
        // Scenarios (each checked against what the reference nodes saw and against the expected
        // records and error counters):
        //   1. DLC 0..8 and a remote frame, chip -> reference and reference -> chip, at 125k, 250k,
        //      500k and 1M (fewer frames at the slow rates); every bit the chip sends is a whole
        //      number of bit times long (no resync on its own edges), and both engines receive.
        //   2. Arbitration: a reference node (ID 0x100) and engine 0 (ID 0x200) start together after
        //      a frame; the reference wins, engine 0 receives its frame intact (status: arbitration
        //      lost), then sends its own.
        //   3. ACK missing: the only other running node does not acknowledge. Engine 0 repeats the
        //      frame; TEC rises by 8 per attempt to 128 (error-passive) and stays there (the passive
        //      ACK-error exception); when ACKs come back the frame goes out and TEC drops to 127.
        //   4. Injected errors with the chip receiving: a CRC error, a stuff error and a form error
        //      from a reference node; the chip's error flag starts in the right bit; the reference
        //      retransmits and the chip receives the frame.
        //   5. A bit error with the chip transmitting: flag from the next bit, retransmission, TEC 8-1.
        //   6. Error-passive and bus-off: every attempt of engine 0 is hit by a bit error. Flags 1-16
        //      active, from 17 passive (checked on the chip's TXD), bus-off when TEC passes 255 (no
        //      more drive), recovery after 128 x 11 recessive bits, then the frame goes out.
        //   7. Engines 0 and 1 as two nodes: frames both ways and arbitration between them.
        module tb_can;
          localparam real CLK_NS = 20.8333;   // 48 MHz
          localparam int HOST_HALF = 3;
          localparam real TXD_NS = 80.0, RXD_NS = 120.0;
        
 1524638   logic clk = 0, rst_n = 0;
 3049275   always #(CLK_NS / 2) clk = ~clk;
        
~066296   logic [7:0] ui_in = 8'b0000_0010;
~003843   wire  [7:0] uo_out, uio_out, uio_oe;
        
          // ---- the bus ----
 1341871   wire  e0_txd = uio_oe[0] ? uio_out[0] : 1'b1;
 820566   wire  e1_txd = uio_oe[2] ? uio_out[2] : 1'b1;
 000751   wire  ra_txd, rb_txd;
 000033   logic force_dom = 0;
 001107   wire  e0_t, e1_t, ra_t, rb_t;
          assign #(TXD_NS) e0_t = e0_txd;
          assign #(TXD_NS) e1_t = e1_txd;
          assign #(TXD_NS) ra_t = ra_txd;
          assign #(TXD_NS) rb_t = rb_txd;
 7046428   wire  bus = e0_t & e1_t & ra_t & rb_t & !force_dom;
 001945   wire  bus_rx;
          assign #(RXD_NS) bus_rx = bus;
~001945   wire [7:0] uio_in = {4'b1111, bus_rx, 1'b1, bus_rx, 1'b1};
        
          tt_um_ayushyadavnvs_pbe dut (
              .ui_in, .uo_out, .uio_in, .uio_out, .uio_oe, .ena(1'b1), .clk, .rst_n
          );
          can_ref_node #(.NAME("A")) ra (.rx(bus_rx), .tx(ra_txd));
          can_ref_node #(.NAME("B")) rb (.rx(bus_rx), .tx(rb_txd));
        
        `ifdef PBE_SIGROK
          // the bus for sigrok's can decoder (verify/golden-model/sigrok)
          integer sigrok_phase = 0;
          wire can_bus = bus;
          initial begin
            $dumpfile("tb_can_bus.vcd");
            $dumpvars(0, can_bus, sigrok_phase);
          end
        `endif
        
          `include "tb_host.svh"
        
          // ---------------- frames ----------------
          // a frame: [79:69] ID, [68] RTR, [67:64] DLC, [63:0] data (byte b is [63-8*b -: 8])
          // [98] IDE (extended), [97:80] extended ID 17..0 (as in can_ref_node.sv)
          typedef logic [98:0] frame_t;
 000149   function automatic int nbytes(input frame_t f);
~000149     return f[68] ? 0 : (f[67:64] > 8 ? 8 : int'(f[67:64]));
          endfunction
 000075   function automatic frame_t mkf(input logic [10:0] id, input bit rtr, input logic [3:0] dlc, input int seed);
 000075     frame_t f;
 000075     f = '0;
 000075     f[79:69] = id; f[68] = rtr; f[67:64] = dlc; f[63:0] = 0;
 000600     for (int b = 0; b < 8; b++) f[63 - 8 * b -: 8] = 8'((seed * 37 + b * 91 + 5) ^ (b * 16));
~000251     if (!rtr) for (int b = dlc > 8 ? 8 : dlc; b < 8; b++) f[63 - 8 * b -: 8] = 0;
 000010     else f[63:0] = 0;
 000075     return f;
          endfunction
 000157   function automatic bit same(input frame_t a, input frame_t b);
~000157     return a[98:80] == b[98:80] && a[79:69] == b[79:69] && a[68] == b[68] && a[67:64] == b[67:64] && a[63:0] == b[63:0];
          endfunction
 000314   function automatic string fs(input frame_t f);
 000314     return $sformatf("id %03x rtr %0d dlc %0d data %016x", f[79:69], f[68], f[67:64], f[63:0]);
          endfunction
        
          // ---------------- host: send a frame on engine e ----------------
 000035   task automatic chip_send(input int e, input frame_t f);
 000035     fifo_send(e, {1'b0, f[79:73]});
 000035     fifo_send(e, {f[72:69], 4'b0});
 000035     fifo_send(e, {f[68], 2'b00, f[67], 4'b0});
 000035     fifo_send(e, {f[66:64], 5'b0});
 000114     for (int b = 0; b < nbytes(f); b++) fifo_send(e, f[63 - 8 * b -: 8]);
 000035     flag_set(e, 0);
          endtask
        
          // ---------------- host: records, read at the IRQ ----------------
          // a record: [111:13] frame, [12:5] status, [4:0] bytes in the record
          typedef logic [111:0] rec_t;
          rec_t recs0[$], recs1[$];
 000008   function automatic logic [7:0] st0(input int i);   // status of engine 0's record i
 000008     rec_t r;
 000008     r = recs0[i];
 000008     return r[12:5];
          endfunction
 000006   function automatic bit st0b(input int i, input int k);
 000006     logic [7:0] x;
 000006     x = st0(i);
 000006     return x[k];
          endfunction
 000011   bit   reader_on = 0;
~000028   logic [7:0] rbuf[16];   // the record being read (Icarus 12: no array task arguments)
 000204   task automatic burst_read(input logic [6:0] addr, input int n);
 000204     logic [7:0] d;
 000204     cs(0);
 000204     spi_byte({1'b0, addr}, d);
 001568     for (int i = 0; i < n; i++) begin
 001568       spi_byte(8'h00, d);   // (an array element as an output argument crashes Icarus 12)
 001568       rbuf[i] = d;
            end
 000204     cs(1);
          endtask
 000204   task automatic parse(input int e, input int n);
 000204     rec_t r;
 000204     frame_t rf;
 000204     rf = 0;
 000202     if (n >= 4) begin
 000202       rf[79:69] = {rbuf[0][6:0], rbuf[1][3:0]};
 000202       rf[68] = rbuf[2][3];
 000202       rf[98] = rbuf[2][2];   // IDE: an extended frame's record ends after this unit (D74)
 000202       rf[67:64] = {rbuf[2][0], rbuf[3][2:0]};
 000568       for (int i = 4; i < n - 1 && i < 12; i++) rf[63 - 8 * (i - 4) -: 8] = rbuf[i];
            end
 000204     r = {rf, rbuf[n - 1], 5'(n)};
 000130     if (e == 0) recs0.push_back(r); else recs1.push_back(r);
          endtask
          // At the IRQ: read the RX_COUNT of every engine that raised it first, then exactly that many
          // bytes. The count must be read before the engine's next record starts (at least about 16
          // bit times after the IRQ: intermission, start of frame, the first unit); reading one FIFO
          // in full before the other's count let engine 1's next record leak into this one.
%000000   initial begin : reader
%000000     logic [7:0] irq, cnt;
%000000     logic [7:0] cnts[2];
 1383700     forever begin
 1383700       @(posedge clk);
~1383700       if (reader_on && uo_out[1]) begin
 000130         reg_read(7'h02, irq);
 000130         reg_write(7'h02, irq);
 000260         for (int e = 0; e < 2; e++) if (irq[e]) begin
 000204           reg_read(e ? 7'h0B : 7'h0A, cnt);
 000204           cnts[e] = cnt;
                end
 000260         for (int e = 0; e < 2; e++) if (irq[e]) begin
 000204           cnt = cnts[e];
~000204           if (cnt != 0) begin
 000204             burst_read(e ? 7'h26 : 7'h16, cnt);
 000204             parse(e, cnt);
                  end
                end
              end
            end
          end
        
          // ---------------- chip setup ----------------
 000001   int bit_clk = 96;
 000011   task automatic setup(input int clocks_per_bit, input logic [7:0] line2);
 000011     logic [7:0] d;
 000011     bit_clk = clocks_per_bit;
            // a full chip reset: the CAN error counters survive an engine restart (D68), and each
            // scenario starts error-active; the reference nodes start afresh too
 000011     reader_on = 0;
 000220     repeat (20) @(posedge clk);
 000011     rst_n = 0;
 000055     repeat (5) @(posedge clk);
 000011     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000055     repeat (5) @(posedge clk);
 000011     load_program("can_image.hex");
 000011     ra.reset_node();
 000011     rb.reset_node();
 000011     recs0.delete(); recs1.delete();
 000011     reader_on = 1;
 000011     reg_write(7'h00, 8'hF0);     // stop, restart and flush both engines
 000022     for (int e = 0; e < 2; e++) begin
 000022       logic [6:0] b, p;
 000022       b = e ? 7'h20 : 7'h10;
 000022       p = e ? 7'h40 : 7'h30;
 000022       reg_write(b + 0, 8'(clocks_per_bit - 1));
 000022       reg_write(b + 1, 8'((clocks_per_bit - 1) >> 8));
 000022       reg_write(b + 2, e ? 8'd2 : 8'd0);   // PIN_BASE
 000022       reg_write(b + 3, 8'd1);              // JMP_PIN = RXD
 000022       reg_write(b + 4, 8'h03);             // MSB first
 000022       reg_write(b + 5, e ? 8'd64 : 8'd0);  // START_PC
 000022       reg_write(b + 9, 8'h99);             // CRC_POLY 0x4599
 000022       reg_write(b + 10, 8'h45);
 000022       reg_write(b + 11, 8'h8E);            // CRC-15, fed by received bits
 000022       reg_write(b + 12, 8'h00);
 000022       reg_write(b + 13, 8'h00);
 000022       reg_write(b + 14, 8'h40 | 8'd45);    // no parity, TIMEOUT_PC = done
 000022       reg_write(p + 0, 8'h2D);             // LINE
 000022       reg_write(p + 1, 8'h00);
 000022       reg_write(p + 2, 8'h00);
 000022       reg_write(p + 3, 8'h00);
 000022       reg_write(p + 4, line2 | 8'h80);     // LINE2, with the CAN frame follower (D74) as can_node wants
            end
 000011     reg_write(7'h03, 8'b0000_1100);      // pins 2, 3 belong to engine 1
 000011     reg_write(7'h00, 8'h30);             // restart both
          endtask
 000011   task automatic run_engines(input logic [1:0] which);
 000011     reg_write(7'h00, {6'b0, which});
          endtask
 000011   task automatic ref_cfg(input real bitns);
 000011     ra.bit_ns = bitns; ra.ppm = 5000.0;
 000011     rb.bit_ns = bitns; rb.ppm = -5000.0;
          endtask
 005438   task automatic wait_bits(input int n);
 1076976     repeat (n * bit_clk) @(posedge clk);
          endtask
 000037   task automatic read_tec(input int e, output int tec, output logic [7:0] state);
 000037     logic [7:0] lo;
 000037     reg_read(e ? 7'h45 : 7'h35, lo);
 000037     reg_read(e ? 7'h47 : 7'h37, state);
 000037     tec = {state[0], lo};
          endtask
        
          // ---------------- bit-time check of what engine 0 drives ----------------
          // While engine 0 alone drives the bus (no foreign edges), every interval between its TXD
          // edges is a whole number of bit times.
 000022   bit   timing_on = 0;
 000001   int   t_last_edge = -1, clk_n = 0, bad_timing = 0, timing_edges = 0;
 000001   int   e0_dom_start = -1, e0_runs[$];
 001107   logic e0_prev = 1;
 1524638   always @(posedge clk) begin
 1524638     clk_n++;
~1524638     if (timing_on && e0_txd != e0_prev) begin
~000792       if (t_last_edge >= 0 && (clk_n - t_last_edge) % bit_clk != 0) bad_timing++;
 000792       timing_edges++;
 000792       t_last_edge = clk_n;
            end
 1524638     e0_prev = e0_txd;
            // ---- error-flag observation on engine 0's TXD ----
            // A dominant run of exactly 6 bits on engine 0's TXD after an error is an active flag.
            // In the same process as clk_n++, so it reads clk_n after the increment in every
            // simulator; a second always block would race it (BUG-102).
~1523532     if (!e0_txd && e0_dom_start < 0) e0_dom_start = clk_n;
~1523532     if (e0_txd && e0_dom_start >= 0) begin
 001106       e0_runs.push_back((clk_n - e0_dom_start + bit_clk / 2) / bit_clk);
 001106       e0_dom_start = -1;
            end
          end
        
          // ---------------- scenarios ----------------
 000125   task automatic expect_rec(input int e, input frame_t f, input logic [7:0] status, input string what);
 000125     rec_t r;
 000125     int tries = 0;
~002827     while ((e ? recs1.size() : recs0.size()) == 0 && tries < 4000) begin wait_bits(1); tries++; end
~000125     if ((e ? recs1.size() : recs0.size()) == 0) check(0, $sformatf("%s: engine %0d gave no record", what, e));
 000125     else begin
 000125       r = e ? recs1.pop_front() : recs0.pop_front();
 000125       check(r[12:5] == status, $sformatf("%s: engine %0d status %02x, expected %02x", what, e, r[12:5], status));
 000125       check(same(r[111:13], f), $sformatf("%s: engine %0d got %s, expected %s", what, e, fs(r[111:13]), fs(f)));
        `ifdef PBE_SIGROK
              // every frame on the bus is one record of engine 0: the list sigrok must decode
              if (e == 0 && (status == 8'h82 || status == 8'h02 || status == 8'h22))
                $display("SIGROK_EXPECT %03x %0d %0d %016x", f[79:69], f[68], f[67:64], f[63:0]);
        `endif
            end
          endtask
        
 000032   task automatic ref_expect(input int which, input frame_t f, input string what);
 000032     frame_t g;
 000032     int tries = 0;
%000000     while ((which ? rb.rx_frames.size() : ra.rx_frames.size()) == 0 && tries < 4000) begin wait_bits(1); tries++; end
~000032     if ((which ? rb.rx_frames.size() : ra.rx_frames.size()) == 0)
%000000       check(0, $sformatf("%s: reference %s received nothing", what, which ? "B" : "A"));
 000032     else begin
 000032       g = which ? rb.rx_frames.pop_front() : ra.rx_frames.pop_front();
 000032       check(same(g, f), $sformatf("%s: reference got %s, expected %s", what, fs(g), fs(f)));
            end
          endtask
        
          // wait until engine e has at least n records (the reader takes them at the IRQ)
 000013   task automatic wait_recs(input int e, input int n);
 000013     int tries = 0;
~000502     while ((e ? recs1.size() : recs0.size()) < n && tries < 2000) begin wait_bits(1); tries++; end
          endtask
        
 000035   task automatic wait_flag_clear(input int e, input string what);
 000035     bit v;
 000035     int tries = 0;
~000332     do begin wait_bits(8); flag_get(e, 0, v); tries++; end while (v && tries < 600);
~000035     check(!v, $sformatf("%s: engine %0d never finished sending", what, e));
          endtask
        
 000001   task automatic scenario_rates();
 000001     frame_t f;
 000001     int nf, rate;
 000001     string name;
 000001     int r_only, sp_sel;
~000001     if (!$value$plusargs("RATE=%d", r_only)) r_only = -1;
~000001     if (!$value$plusargs("SP=%d", sp_sel)) sp_sel = 2;   // LINE2 sample point: 2 = 75 %, 3 = 87.5 %
~000004     for (int r = (r_only >= 0 ? r_only : 0); r < (r_only >= 0 ? r_only + 1 : 4); r++) begin
 000004       rate = r == 0 ? 384 : r == 1 ? 192 : r == 2 ? 96 : 48;
 000004       name = r == 0 ? "125k" : r == 1 ? "250k" : r == 2 ? "500k" : "1M";
 000004       setup(rate, 8'h70 | 8'(sp_sel));
 000004       ref_cfg(rate * CLK_NS);
 000004       ra.enabled = 1; rb.enabled = 0;
 000004       ra.rx_frames.delete(); recs0.delete(); recs1.delete();
 000004       run_engines(2'b11);
 000004       wait_bits(24);
 000004       nf = (r < 2) ? 3 : 10;
              // chip -> reference
 000026       for (int i = 0; i < nf; i++) begin
 000026         f = (i == nf - 1) ? mkf(11'h7EF - i, 1, 4'd3, i) : mkf(11'h0A5 + i * 77, 0, nf == 3 ? 4'(i * 4) : 4'(i), i + r);
 000026         timing_on = 1; t_last_edge = -1;
 000026         chip_send(0, f);
 000026         wait_flag_clear(0, {name, " chip->ref"});
 000026         timing_on = 0;
 000026         ref_expect(0, f, $sformatf("%s chip->ref #%0d", name, i));
 000026         expect_rec(0, f, 8'h82, $sformatf("%s chip->ref own record #%0d", name, i));
 000026         expect_rec(1, f, 8'h02, $sformatf("%s chip->ref engine 1 #%0d", name, i));
              end
 000004       check(bad_timing == 0, $sformatf("%s: %0d of engine 0's bits were not a whole number of bit times", name, bad_timing));
 000004       bad_timing = 0;
              // reference -> chip
 000026       for (int i = 0; i < nf; i++) begin
 000026         f = (i == nf - 1) ? mkf(11'h123, 1, 4'd5, i) : mkf(11'h311 - i * 13, 0, nf == 3 ? 4'(8 - i * 4) : 4'(8 - i), i * 3);
 000026         ra.tx_q.push_back(f);
 000026         expect_rec(0, f, 8'h02, $sformatf("%s ref->chip engine 0 #%0d", name, i));
 000026         expect_rec(1, f, 8'h02, $sformatf("%s ref->chip engine 1 #%0d", name, i));
              end
~000004       check(ra.tec == 0 && ra.rec == 0 && ra.n_err_flags == 0, $sformatf("%s: the reference saw errors (TEC %0d REC %0d flags %0d)", name, ra.tec, ra.rec, ra.n_err_flags));
 000004       $display("1: %s: %0d frames each way (DLC 0-8 and remote), records and reference frames match, bits on the grid",
 000004                name, nf);
            end
          endtask
        
 000001   task automatic scenario_arbitration();
 000001     frame_t fa, fb, f0;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 1;
 000001     ra.rx_frames.delete(); rb.rx_frames.delete(); recs0.delete(); recs1.delete();
 000001     run_engines(2'b11);
 000001     wait_bits(24);
            // B sends first; while it is on the bus, A (0x100) and engine 0 (0x200) get their frames
 000001     fb = mkf(11'h050, 0, 4'd8, 7);
 000001     fa = mkf(11'h100, 0, 4'd4, 8);
 000001     f0 = mkf(11'h200, 0, 4'd6, 9);
 000001     rb.tx_q.push_back(fb);
 000001     wait_bits(10);
 000001     ra.tx_q.push_back(fa);
 000001     chip_send(0, f0);
 000001     wait_flag_clear(0, "arbitration");
 000001     expect_rec(0, fb, 8'h02, "arbitration: B's frame");
 000001     expect_rec(0, fa, 8'h22, "arbitration: A wins, engine 0 lost (status arbitration lost)");
 000001     expect_rec(0, f0, 8'h82, "arbitration: engine 0's frame after A's");
 000001     ref_expect(1, fa, "arbitration: B sees A first");
 000001     ref_expect(1, f0, "arbitration: then engine 0");
 000001     check(ra.n_arb_lost == 0, "arbitration: the reference with the lower ID lost");
 000001     $display("2: arbitration: ID 0x100 beat engine 0's 0x200; engine 0 received it intact, then sent its own");
          endtask
        
 000001   task automatic scenario_ack();
 000001     frame_t f;
 000001     int tec;
 000001     logic [7:0] st;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 0;
 000001     ra.ack_en = 0;
 000001     ra.rx_frames.delete(); recs0.delete(); recs1.delete();
 000001     run_engines(2'b01);
 000001     wait_bits(24);
 000001     f = mkf(11'h345, 0, 4'd2, 3);
 000001     chip_send(0, f);
 000001     wait_bits(25 * 60);   // ~25 attempts
 000001     read_tec(0, tec, st);
~000001     check(tec == 128 && st[1] && !st[2], $sformatf("ACK missing: TEC %0d state %b, expected 128, passive, not bus-off", tec, st[2:0]));
 000001     check(recs0.size() >= 16, $sformatf("ACK missing: only %0d attempts reported", recs0.size()));
 000020     for (int i = 0; i < recs0.size(); i++) begin
 000020       rec_t r;
 000020       r = recs0[i];
~000020       check(r[9] && !r[12], $sformatf("ACK missing: attempt %0d status %02x", i, r[12:5]));
            end
 000001     recs0.delete();
 000001     ra.ack_en = 1;
 000001     wait_flag_clear(0, "ACK back");
 000001     wait_recs(0, 1);
 000001     read_tec(0, tec, st);
~000001     check(tec == 127 && !st[1], $sformatf("ACK back: TEC %0d state %b, expected 127, active", tec, st[2:0]));
%000000     while (recs0.size() > 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h82, "ACK back: the frame went out");
 000001     $display("3: ACK missing: TEC rose by 8 per attempt to 128 (passive) and stayed; with an ACK the frame went out, TEC 127");
          endtask
        
          // the time engine 0 starts driving dominant after `t0`
 000001   task automatic first_e0_dom(input int t0, output int t);
 000001     t = -1;
~000107     for (int i = 0; i < 400 * bit_clk && t < 0; i++) begin
 000107       @(negedge clk);  // after the edge's clk_n++ (BUG-102)
~000106       if (clk_n > t0 && !e0_txd) t = clk_n;
            end
          endtask
        
          int ra_bit_t[$];  // clock numbers of reference A's bit starts in the tail (tail_i 0..9)
 223341   always @(ra.tqc) if (ra.tqc == 1 && ra.st == 2 /* S_FRAME */ && ra.in_tail) ra_bit_t.push_back(clk_n);
        
 000001   task automatic scenario_injected();
 000001     frame_t f;
 000001     int t, d, rec;
 000001     logic [7:0] st, lo;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 0;
 000001     recs0.delete(); recs1.delete();
 000001     run_engines(2'b11);
 000001     wait_bits(24);
            // CRC error: the chip's flag starts in the bit after the ACK delimiter (EOF bit 1)
 000001     f = mkf(11'h0F0, 0, 4'd3, 1);
 000001     ra.crc_corrupt = 1;
 000001     ra_bit_t.delete();
 000001     ra.tx_q.push_back(f);
 013588     while (ra_bit_t.size() < 3) @(posedge clk);
 000001     first_e0_dom(ra_bit_t[2], t);
 000001     d = t - (ra_bit_t[2] + bit_clk);   // the start of EOF bit 1, as reference A timed it
~000001     check(d > -bit_clk / 4 && d < bit_clk / 4, $sformatf("CRC error: engine 0's flag began %0d clocks from the bit after the ACK delimiter", d));
            // the chip's records: an error record, then the retransmitted frame
 000001     wait_bits(200);
~000001     check(recs0.size() >= 2 && st0b(0, 4) && !st0b(0, 1), $sformatf("CRC error: first record status %02x", recs0.size() ? st0(0) : 0));
~000001     if (recs0.size() >= 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h02, "CRC error: the retransmitted frame");
 000001     reg_read(7'h36, lo);
 000001     rec = lo;
            // stuff error and form error
 000001     recs0.delete(); recs1.delete();
 000001     f = mkf(11'h000, 0, 4'd1, 2);   // ID 0: a long dominant run, stuffed early
 000001     ra.skip_stuff_at = 4;
 000001     ra.tx_q.push_back(f);
 000001     wait_bits(150);
~000001     check(recs0.size() >= 2 && st0b(0, 4), "stuff error: no error record");
~000001     if (recs0.size() >= 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h02, "stuff error: the retransmitted frame");
 000001     recs0.delete(); recs1.delete();
 000001     f = mkf(11'h3AA, 0, 4'd2, 3);
 000001     ra.form_corrupt = 1;
 000001     ra.tx_q.push_back(f);
 000001     wait_bits(150);
~000001     check(recs0.size() >= 2 && st0b(0, 4), "form error: no error record");
~000001     if (recs0.size() >= 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h02, "form error: the retransmitted frame");
 000001     check(ra.n_sent >= 3, "injected errors: the reference did not get its frames out");
 000001     $display("3b: injected CRC, stuff and form errors: error records, the CRC error flag in EOF bit 1, frames received on retransmission");
          endtask
        
          // the disturber: force dominant for one bit where engine 0 sends recessive, `nth` data bit
          // after its SOF (counted at engine 0's TXD) - a bit error for engine 0
 000002   bit disturb = 0;
 000001   int disturb_after = 30, n_disturbed = 0;
%000000   initial begin : disturber
 1329311     forever begin
 1329311       @(posedge clk);
 1329278       if (disturb && !e0_txd) begin
                // engine 0 started a frame: wait into it, then hit the next recessive bit it sends
 095040         repeat (disturb_after * bit_clk) @(posedge clk);
 001683         while (!e0_txd || !bus) @(posedge clk);
 000396         repeat (bit_clk / 8) @(posedge clk);
 000033         force_dom = 1;            // a whole bit: the chip resyncs on this edge and still samples it
 003168         repeat (bit_clk) @(posedge clk);
 000033         force_dom = 0;
 000033         n_disturbed++;
                // let the error frame and intermission pass
 095040         repeat (30 * bit_clk) @(posedge clk);
              end
            end
          end
        
 000001   task automatic scenario_bit_error();
 000001     frame_t f;
 000001     int tec;
 000001     logic [7:0] st;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 0;
 000001     recs0.delete(); recs1.delete();
 000001     run_engines(2'b01);
 000001     wait_bits(24);
 000001     f = mkf(11'h0FF, 0, 4'd8, 4);   // data with recessive bits after the arbitration field
 000001     n_disturbed = 0;
 000001     disturb = 1;
 000001     chip_send(0, f);
 000032     while (n_disturbed == 0) wait_bits(1);
 000001     disturb = 0;
 000001     wait_flag_clear(0, "bit error");
 000001     wait_recs(0, 2);
 000001     read_tec(0, tec, st);
 000001     check(tec == 7, $sformatf("bit error: TEC %0d after one error and one success, expected 7", tec));
~000001     check(recs0.size() >= 2 && st0b(0, 6) && st0b(0, 4), $sformatf("bit error: first record status %02x, expected bit error", recs0.size() ? st0(0) : 0));
 000001     while (recs0.size() > 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h82, "bit error: the retransmitted frame");
 000001     ref_expect(0, f, "bit error: reference");
 000001     $display("4: bit error as transmitter: error record (bit error), retransmitted, TEC 8 - 1 = 7");
          endtask
        
 000001   task automatic scenario_passive_busoff();
 000001     frame_t f;
 000001     int tec, t_off, t_back, expect_tec, n_flags_active, idx;
 000001     logic [7:0] st;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 0;
 000001     recs0.delete(); recs1.delete();
 000001     run_engines(2'b01);
 000001     wait_bits(24);
 000001     f = mkf(11'h0F7, 0, 4'd8, 6);
 000001     e0_runs.delete();
 000001     n_disturbed = 0;
 000001     disturb = 1;
 000001     chip_send(0, f);
            // each disturbed attempt adds 8; TEC passes 255 at the 32nd
 000032     for (int k = 1; k <= 32; k++) begin
 001691       while (n_disturbed < k) wait_bits(1);
 000032       wait_bits(4);
 000032       read_tec(0, tec, st);
 000032       expect_tec = 8 * k;
~000031       if (k < 32) check(tec == expect_tec && st[1] == (expect_tec >= 128) && !st[2],
 000031                         $sformatf("error %0d: TEC %0d state %b, expected %0d", k, tec, st[2:0], expect_tec));
 000001       else begin
 000001         check(st[2], $sformatf("error 32: TEC %0d state %b, expected bus-off", tec, st[2:0]));
 000001         t_off = clk_n;
              end
            end
 000001     disturb = 0;
            // engine 0's error flags: 16 active (6 dominant bits on its TXD), then passive
 000001     n_flags_active = 0;
 000270     foreach (e0_runs[i]) if (e0_runs[i] == 6) n_flags_active++;
 000001     check(n_flags_active == 16, $sformatf("error flags: %0d active flags on engine 0's TXD, expected 16 (errors 1-16)", n_flags_active));
            // bus-off: no drive until recovery (128 x 11 recessive bits), then the frame goes out
 000001     t_back = -1;
~135454     while (t_back < 0 && clk_n - t_off < 2000 * bit_clk) begin
 135454       @(negedge clk);  // after the edge's clk_n++ (BUG-102)
 135453       if (!e0_txd) t_back = clk_n;
            end
~000001     check(t_back > 0 && t_back - t_off >= 128 * 11 * bit_clk - 2 * bit_clk,
 000001           $sformatf("bus-off: engine 0 drove again %0d bit times after bus-off, expected >= %0d", (t_back - t_off) / bit_clk, 128 * 11));
 000001     wait_flag_clear(0, "after recovery");
 000001     wait_bits(30);
 000001     read_tec(0, tec, st);
~000001     check(tec == 0 && st[2:1] == 0, $sformatf("after recovery: TEC %0d state %b", tec, st[2:0]));
 000032     while (recs0.size() > 1) void'(recs0.pop_front());
 000001     expect_rec(0, f, 8'h82, "after recovery: the frame went out");
 000001     $display("5: error-passive after 16 errors (flags 1-16 active, then passive), bus-off at TEC 256, recovery after %0d bit times",
 000001              (t_back - t_off) / bit_clk);
          endtask
        
 000001   task automatic scenario_two_engines();
 000001     frame_t f0, f1, fb, first0;
 000001     setup(96, 8'h72);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 0; rb.enabled = 1;
 000001     rb.rx_frames.delete(); recs0.delete(); recs1.delete();
 000001     run_engines(2'b11);
 000001     wait_bits(24);
 000001     f0 = mkf(11'h111, 0, 4'd5, 11);
 000001     first0 = f0;
 000001     chip_send(0, f0);
 000001     wait_flag_clear(0, "two engines 0->1");
 000001     expect_rec(1, f0, 8'h02, "two engines: engine 1 receives engine 0's frame");
 000001     expect_rec(0, f0, 8'h82, "two engines: engine 0's own record");
 000001     f1 = mkf(11'h222, 1, 4'd0, 12);
 000001     chip_send(1, f1);
 000001     wait_flag_clear(1, "two engines 1->0");
 000001     expect_rec(0, f1, 8'h02, "two engines: engine 0 receives engine 1's frame");
 000001     expect_rec(1, f1, 8'h82, "two engines: engine 1's own record");
            // arbitration between the engines: both queued while B sends
 000001     fb = mkf(11'h010, 0, 4'd8, 13);
 000001     f0 = mkf(11'h401, 0, 4'd1, 14);
 000001     f1 = mkf(11'h400, 0, 4'd2, 15);
 000001     rb.tx_q.push_back(fb);
 000001     wait_bits(8);
 000001     chip_send(0, f0);
 000001     chip_send(1, f1);
 000001     wait_flag_clear(0, "engine arbitration");
 000001     wait_flag_clear(1, "engine arbitration");
 000001     expect_rec(0, fb, 8'h02, "engine arbitration: B's frame (engine 0)");
 000001     expect_rec(1, fb, 8'h02, "engine arbitration: B's frame (engine 1)");
 000001     expect_rec(0, f1, 8'h22, "engine arbitration: engine 1 (0x400) wins over engine 0 (0x401)");
 000001     expect_rec(1, f1, 8'h82, "engine arbitration: engine 1's own record");
 000001     expect_rec(0, f0, 8'h82, "engine arbitration: engine 0 sends after");
 000001     expect_rec(1, f0, 8'h02, "engine arbitration: engine 1 receives it");
 000001     ref_expect(1, first0, "two engines: B saw engine 0's first frame");
 000001     $display("6: engines 0 and 1 as two nodes: frames both ways, arbitration 0x400 over 0x401");
          endtask
        
          // an extended (CAN 2.0B) frame: base ID, extended ID, RTR, DLC
 000005   function automatic frame_t mkx(input logic [10:0] base, input logic [17:0] ext, input bit rtr, input logic [3:0] dlc, input int seed);
 000005     frame_t f;
 000005     f = mkf(base, rtr, dlc, seed);
 000005     f[98] = 1;
 000005     f[97:80] = ext;
 000005     return f;
          endfunction
        
          // engine e's record of an extended frame or a standard one with r0 recessive: the
          // first three units ({SOF, ID[10:4]}, ID[3:0], {SRR or RTR, IDE, ..}), then the status (D74)
 000011   task automatic expect_short(input int e, input logic [10:0] base, input bit ide, input logic [7:0] status, input string what);
 000011     rec_t r;
 000011     frame_t rf;
 000011     wait_recs(e, 1);
~000011     if ((e ? recs1.size() : recs0.size()) == 0) check(0, $sformatf("%s: engine %0d gave no record", what, e));
 000011     else begin
 000011       r = e ? recs1.pop_front() : recs0.pop_front();
 000011       rf = r[111:13];
~000011       check(r[4:0] == 5'd4 && r[12:5] == status && rf[79:69] == base && rf[98] == ide,
 000011             $sformatf("%s: engine %0d record of %0d bytes, status %02x, base ID %03x, IDE %0d; expected 4, %02x, %03x, %0d",
 000011                       what, e, r[4:0], r[12:5], rf[79:69], rf[98], status, base, ide));
            end
          endtask
        
 000001   task automatic scenario_extended();
 000001     frame_t f, fs_, fx;
 000001     int tec;
 000001     logic [7:0] st, rec_lo;
 000001     setup(96, 8'hF2);
 000001     ref_cfg(96 * CLK_NS);
 000001     ra.enabled = 1; rb.enabled = 0;   // the chip is the only node that can acknowledge
 000001     run_engines(2'b11);
 000001     wait_bits(24);
            // valid extended data and remote frames, and a standard frame with r0 recessive
 000004     for (int i = 0; i < 4; i++) begin
 000004       f = (i == 3) ? mkx(11'h2A5, 18'h3_1234, 1, 4'd2, i) : mkx(11'h155 + i, 18'h2_0F0F + i, 0, i == 0 ? 4'd0 : i == 1 ? 4'd3 : 4'd8, i);
 000004       ra.tx_q.push_back(f);
 000004       expect_short(0, f[79:69], 1, 8'h02, $sformatf("extended frame %0d", i));
 000004       expect_short(1, f[79:69], 1, 8'h02, $sformatf("extended frame %0d (engine 1)", i));
            end
 000001     ra.r0_bit = 1;
 000001     f = mkf(11'h0C3, 0, 4'd5, 9);
 000001     ra.tx_q.push_back(f);
 000001     expect_short(0, f[79:69], 0, 8'h02, "standard frame with r0 recessive");
 000001     expect_short(1, f[79:69], 0, 8'h02, "standard frame with r0 recessive (engine 1)");
 000001     ra.r0_bit = 0;
 000001     wait_bits(20);
~000001     check(ra.n_sent == 5 && ra.n_err_flags == 0 && ra.tec == 0,
 000001           $sformatf("extended: the reference sent %0d of 5, with %0d error flags, TEC %0d (every frame must be ACKed by the chip, no errors)",
 000001                     ra.n_sent, ra.n_err_flags, ra.tec));
 000001     read_tec(0, tec, st);
 000001     reg_read(7'h36, rec_lo);
~000001     check(tec == 0 && rec_lo == 0 && st[2:1] == 0, $sformatf("extended: engine 0 TEC %0d REC %0d state %b", tec, rec_lo, st[2:0]));
            // arbitration: a standard frame beats an extended one with the same base ID (SRR/IDE)
 000001     rb.enabled = 1;
 000001     rb.rx_frames.delete();
 000001     recs0.delete(); recs1.delete();
 000001     wait_bits(16);
 000001     fs_ = mkf(11'h123, 0, 4'd2, 20);
 000001     fx = mkx(11'h123, 18'h0_0001, 0, 4'd1, 21);
 000001     rb.tx_q.push_back(mkf(11'h040, 0, 4'd8, 22));   // a frame first, so both start together after it
 000001     wait_bits(10);
 000001     ra.tx_q.push_back(fx);
 000001     chip_send(0, fs_);
 000001     wait_flag_clear(0, "standard vs extended");
 000001     wait_bits(200);
 000001     expect_rec(0, mkf(11'h040, 0, 4'd8, 22), 8'h02, "standard vs extended: B's frame");
 000001     expect_rec(0, fs_, 8'h82, "standard vs extended: the standard frame (same base ID) wins");
 000001     expect_short(0, 11'h123, 1, 8'h02, "standard vs extended: then the extended frame");
 000001     ref_expect(1, fs_, "standard vs extended: B receives the standard frame first");
 000001     ref_expect(1, fx, "standard vs extended: then the extended one, intact (29-bit ID)");
 000001     check(ra.n_arb_lost == 1, $sformatf("standard vs extended: the extended sender lost arbitration %0d times, expected 1", ra.n_arb_lost));
 000001     $display("7: extended (CAN 2.0B) frames and r0 recessive: received passively, ACKed, no error frames; standard 0x123 beats extended 0x123");
          endtask
        
 000001   initial begin
 000001     string only;
 000005     repeat (5) @(posedge clk);
 000001     @(negedge clk) rst_n = 1;  // released between edges, not at one (BUG-102)
 000005     repeat (5) @(posedge clk);
~000001     if (!$value$plusargs("ONLY=%s", only)) only = "";
~000001     if (only == "" || only == "rates") scenario_rates();
~000001     if (only == "" || only == "arb") scenario_arbitration();
~000001     if (only == "" || only == "ack") scenario_ack();
~000001     if (only == "" || only == "inject") scenario_injected();
~000001     if (only == "" || only == "biterr") scenario_bit_error();
~000001     if (only == "" || only == "busoff") scenario_passive_busoff();
~000001     if (only == "" || only == "two") scenario_two_engines();
~000001     if (only == "" || only == "ext") scenario_extended();
 000001     if (errors == 0) begin
 000001       $display("PASS: CAN node");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
          initial begin
            #2s;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
