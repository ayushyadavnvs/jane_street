//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // BUG-058/059: preserve observable counterexamples to overly strong prose.
        // Default mode verifies existing behavior. The plusargs below deliberately fail
        // the original stronger expectations; RTL is never changed to make them pass.
        module tb_spec_boundaries;
~000141   logic clk = 0, rst_n = 0, restart = 0, pm_wr = 0;
 000281   always #5 clk = ~clk;
          logic [15:0] prog[128];
 000068   wire [6:0] pc;
~000001   wire [7:0] pins_out, pins_oe;
~000001   bit saw_prefetch64 = 0, saw_instruction64 = 0;
          pbe_engine dut (
            .clk, .rst_n, .run(1'b1), .restart,
            .clkdiv(16'd0), .pin_base(3'd0), .jmp_pin(3'd0),
            .out_msb_first(1'b0), .in_msb_first(1'b0), .start_pc(7'd0),
            .crc_poly(16'd0), .crc_cfg(8'd0), .timeout(16'd0), .line_cfg(8'd0),
            .coder_cfg(8'd0),.coder_cfg2(8'd0), .sync(8'd0), .crc_good(16'd0),
            .host_crc_init(1'b0), .host_tmo_clr(1'b0), .host_ovf_clr(1'b0), .host_lerr_clr(1'b0),.host_arb_clr(1'b0),.host_berr_clr(1'b0),.host_sent_clr(1'b0),
            .status(), .crc_now(),.can_tec(),.can_rec(),.can_state(), .pc, .pc_copy(), .instr(prog[pc]), .pm_wr,
            .pins_in(8'd0), .pins_out, .pins_oe,
            .tx_data(8'd0), .tx_empty(1'b1), .tx_pop(),.tx_mark(),.tx_rewind(),
            .rx_data(), .rx_full(1'b0), .rx_push(),
            .flags(4'd0), .flag_set(), .flag_clr(), .irq()
          );
          // Match top-level PM write ordering: RAM and engine sample pre-edge state.
 000141   always @(posedge clk) if (pm_wr) prog[0] <= 16'h0000; // replacement DRV0
 000139   task automatic sample_clock;
 000139     @(posedge clk); #1;
          endtask
 000002   task automatic reset_at_start;
 000002     @(negedge clk); restart = 1;
 000002     sample_clock();
 000002     @(negedge clk); restart = 0;
 000002     sample_clock(); // target fetch; current instruction is now word 0
          endtask
 000001   initial begin
 000128     for (int i = 0; i < 128; i++) prog[i] = 16'hd800;
 000003     repeat (3) sample_clock();
 000001     @(negedge clk); rst_n = 1;
 000001     reset_at_start();
 000130     for (int i = 0; i < 130; i++) begin
~000129       if (dut.exec && pc == 7'd64) begin
 000001         saw_prefetch64 = 1;
 000001         $display("BUG-058 prefetch pc=64 while instruction 63 executes");
 000001         if ($test$plusargs("EXPECT_WINDOW_FENCE"))
                  $fatal(1, "original requested pc<=start_pc+63 property fails");
              end
~000129       if (dut.exec && pc == 7'd65) begin
 000001         saw_instruction64 = 1;
 000001         $display("BUG-058 actual instruction 64 executes outside offset window");
 000001         if ($test$plusargs("EXPECT_INSTRUCTION_WINDOW_FENCE"))
                  $fatal(1, "sequential executed-instruction window property fails");
              end
 000130       sample_clock();
            end
~000001     if (!saw_prefetch64 || !saw_instruction64) $fatal(1, "window counterexamples absent");
 000001     @(negedge clk); prog[0] = 16'h0080; // old DRV1
 000001     reset_at_start();
 000001     @(negedge clk); pm_wr = 1;
~000001     if (!dut.exec || dut.instr_q !== 16'h0080) $fatal(1, "ready old instruction setup failed");
 000001     sample_clock();
 000001     $display("BUG-059 PM write edge: out=%02x oe=%02x RAM[0]=%04x iv=%0d next_pc=%0d",
 000001              pins_out, pins_oe, prog[0], dut.iv, pc);
 000001     if ($test$plusargs("EXPECT_WRITE_CANCELLATION") && pins_out[0])
              $fatal(1, "old ready instruction executes on same PM-write edge");
~000001     if (pins_out !== 8'd1 || pins_oe !== 8'd1 || prog[0] !== 16'h0000 || dut.iv || pc != 1)
              $fatal(1, "documented ready-instruction/write behavior changed");
 000001     @(negedge clk); pm_wr = 0;
 000001     sample_clock();
~000001     if (!dut.iv || pc != 2) $fatal(1, "successor refill failed");
 000001     $display("PASS: BUG-058/059 original claims have explicit preserved counterexamples");
 000001     $finish;
          end
          initial begin
            #20us;
            $fatal(1, "time limit");
          end
        endmodule
        
