//      // verilator_coverage annotation
        `timescale 1ns / 1ps
        // Unit test of the line coder (pbe_line) against reference encoders and decoders written
        // here, independently of the RTL.
        //
        //  A  USB transmit: NRZI, a 0 stuffed after six 1s, pair drive. Checked: 2-bit gap, SYNC
        //     KJKJKJKK, every bit exactly one period, the stuffed bits (also one right before EOP),
        //     EOP = SE0 SE0 J, then the line is released.
        //  B  USB receive from a reference encoder at +1.5 % and -1.5 % clock error (the USB limit for
        //     a low-speed device), then a packet with seven 1s in a row: a stuff error.
        //  C  Two coders back to back, CAN style (NRZ, stuff after 5 equal bits, single bits) and
        //     HDLC style (NRZI, stuff after 5 ones, bytes): what goes in comes out, and the line never
        //     holds more than the allowed run.
        //  D  LINE2 (D65) on pbe_line: the four sample points, falling-edge-only resync, and the
        //     bus-idle wait before a frame (11 idle bits, or 3 after a received frame end).
        //  E  The bit-synchronous (CAN) coder, pbe_bsync (D66), on a wired-AND bus with a 4-clock
        //     transceiver loop delay, against a CAN bit-stream encoder written here: integration
        //     and the 11-bit idle wait, readback of its own frame with no resync on its own edges
        //     (every bit exactly P clocks), the tail with an ACK, arbitration lost to a lower ID
        //     (stops driving at once, keeps receiving), the error flag in the bit after a stuff error,
        //     a bit error and LINECTL "error now", the four sample points with falling-edge-only resync.
        module tb_line;
          localparam int P = 32;  // clocks per bit (USB low speed at 48 MHz)
 057485   logic clk = 0, rst_n = 0;
 114970   always #10 clk = ~clk;  // 20 ns clock (the period only scales time here)
 000001   int errors = 0;
 000189   task automatic check(input bit ok, input string msg);
~000189     if (!ok) begin
%000000       errors++;
%000000       $display("  FAIL: %s", msg);
            end
          endtask
        
          // ---- coder under test (u) and a second one for the loopback tests (v) ----
~000003   logic [7:0] cfg2_u = 0;
~000002   logic [7:0] cfg_u = 0, cfg_v = 0, sync_u = 0, sync_v = 0;
 000086   logic       a_in = 1, b_in = 0, use_loop = 0;
~000207   logic       put_u = 0, end_u = 0, take_u = 0, put_v = 0, end_v = 0, take_v = 0;
 000010   logic [7:0] data_u = 0, data_v = 0;
 000207   wire        drive_u, ao_u, bo_u, ready_u, rv_u, fe_u, err_u;
~000050   wire        drive_v, ao_v, bo_v, ready_v, rv_v, fe_v, err_v;
~000032   wire [7:0]  rd_u, rd_v;
 054127   wire        line_v = drive_v ? ao_v : 1'b1;  // v transmits into u in the loopback tests
        
          pbe_line u (
              .clk, .rst_n, .clear(1'b0), .cfg(cfg_u), .cfg2(cfg2_u), .sync(sync_u), .period_m1(16'(P - 1)),
              .out_msb_first(1'b0), .in_msb_first(1'b0),
              .a_in(use_loop ? line_v : a_in), .b_in(use_loop ? 1'b0 : b_in),
              .drive(drive_u), .a_out(ao_u), .b_out(bo_u),
              .tx_put(put_u), .tx_end(end_u), .tx_data(data_u), .tx_ready(ready_u),
              .rx_valid(rv_u), .rx_data(rd_u), .rx_take(take_u), .frame_end(fe_u), .err(err_u)
          );
          pbe_line v (
              .clk, .rst_n, .clear(1'b0), .cfg(cfg_v), .cfg2(8'h00), .sync(sync_v), .period_m1(16'(P - 1)),
              .out_msb_first(1'b0), .in_msb_first(1'b0),
              .a_in(1'b1), .b_in(1'b0),
              .drive(drive_v), .a_out(ao_v), .b_out(bo_v),
              .tx_put(put_v), .tx_end(end_v), .tx_data(data_v), .tx_ready(ready_v),
              .rx_valid(rv_v), .rx_data(rd_v), .rx_take(take_v), .frame_end(fe_v), .err(err_v)
          );
        
 000001   int n_err_u = 0, n_fe_u = 0;
 057485   always @(posedge clk) begin
 057481     if (err_u) n_err_u++;
 057467     if (fe_u) n_fe_u++;
          end
        
          // feed one coder: queue a byte (or bit) when it is ready, like the engine does
 000012   task automatic send_u(input logic [7:0] d, input bit is_end);
 000012     @(negedge clk);  // between edges, so tx_ready already shows the last put (BUG-027)
 002532     while (!ready_u) @(negedge clk);
 000012     data_u = d; put_u = !is_end; end_u = is_end;
 000012     @(negedge clk);
 000012     put_u = 0; end_u = 0;
          endtask
 000049   task automatic send_v(input logic [7:0] d, input bit is_end);
 000049     @(negedge clk);  // between edges, so tx_ready already shows the last put (BUG-027)
 003080     while (!ready_v) @(negedge clk);
 000049     data_v = d; put_v = !is_end; end_v = is_end;
 000049     @(negedge clk);
 000049     put_v = 0; end_v = 0;
          endtask
        
          // collect everything u receives
          logic [7:0] got[$];
 057485   always @(posedge clk) begin
 057485     take_u <= 0;
 057278     if (rv_u && !take_u) begin
 000207       got.push_back(rd_u);
 000207       take_u <= 1;
            end
          end
        
          // ---- A: watch u's line while it transmits a USB packet ----
          // Line states sampled every clock while driven: 0 = SE0, 1 = J (a high), 2 = K (a low).
          int st_q[$];
 000001   bit watch = 0;
          // clk_n: the number of rising edges before the current one. It is updated with a
          // nonblocking assignment, so every process that reads it at a rising edge sees the same
          // value whatever order the simulator runs them in (BUG-102); testbench threads act and read
          // only after a falling edge, when every rising-edge update is done.
 000001   int t_first = -1, t_put = -1, clk_n = 0;
 057485   always @(posedge clk) begin
 057485     clk_n <= clk_n + 1;
 055181     if (watch && drive_u) begin
 002303       if (t_first < 0) t_first = clk_n;
 002304       st_q.push_back(!ao_u && !bo_u ? 0 : ao_u && !bo_u ? 1 : !ao_u && bo_u ? 2 : 3);
            end
          end
        
          // reference USB encoder: bytes (LSB first) -> line states, one per bit, SYNC first, then EOP
          int ref_st[$];
          logic [7:0] enc_in[$];  // the bytes to encode (a queue argument crashes Icarus 12)
 000004   task automatic usb_encode(input bit bad_stuff);
 000004     int lvl, ones;
 000004     bit b;
 000004     logic [7:0] x, all[$];
 000004     ref_st.delete();
 000004     all.delete();  // (BUG-103) release 5.020 of Verilator keeps an automatic task's local queue between calls
 000004     all.push_back(8'h80);
 000034     foreach (enc_in[i]) all.push_back(enc_in[i]);
 000004     lvl = 1;  // J
 000004     ones = 0;
 000038     foreach (all[i])
 000304       for (int k = 0; k < 8; k++) begin
 000304         x = all[i];  // Icarus 12 cannot bit-select a queue element
 000304         b = x[k];
 000153         if (!b) lvl = 3 - lvl;  // NRZI: 0 changes J <-> K (1 <-> 2)
 000304         ref_st.push_back(lvl);
 000304         ones = b ? ones + 1 : 0;
~000301         if (ones == 6 && !bad_stuff) begin
 000013           lvl = 3 - lvl;
 000013           ref_st.push_back(lvl);
 000013           ones = 0;
                end
              end
 000004     ref_st.push_back(0);
 000004     ref_st.push_back(0);
 000004     ref_st.push_back(1);
          endtask
        
          // drive the line from ref_st with bits stretched by (1 + ppm / 1e6)
          // Starts at a falling edge: with bits of 20 * P * (1 +- 0.015) ns every level change then
          // falls between clock edges, never on a rising edge where the coder samples (BUG-102).
 000003   task automatic usb_drive(input real ppm);
 000003     real t_bit = 20.0 * P * (1.0 + ppm / 1.0e6);
 000003     @(negedge clk);
 000257     foreach (ref_st[i]) begin
 000257       a_in = ref_st[i] == 1;
 000257       b_in = ref_st[i] == 2;
 000257       #(t_bit);
            end
 000003     a_in = 1;
 000003     b_in = 0;
          endtask
        
 000001   initial begin
 000001     logic [7:0] pkt[$], seq[$];
 000003     repeat (3) @(negedge clk);
 000001     rst_n = 1;
 000003     repeat (3) @(negedge clk);
        
            // ===== A: USB transmit =====
 000001     cfg_u = 8'b0011_0110;  // bytes, pair, stuff after 6 ones, NRZI
 000001     sync_u = 8'h80;
 000001     pkt = '{8'hC3, 8'hFF, 8'h3F, 8'h00, 8'h7E, 8'hFF, 8'hFC};  // runs of ones, ends in six 1s
 000001     enc_in = pkt;
 000001     usb_encode(0);
 000001     watch = 1;
 000001     t_put = clk_n + 1;
~000007     foreach (pkt[i]) send_u(pkt[i], 0);
 000001     send_u(8'h00, 1);
 000383     while (drive_u) @(negedge clk);
 000005     repeat (5) @(negedge clk);
 000001     watch = 0;
~000001     check(t_first - t_put >= 2 * P && t_first - t_put <= 2 * P + 4,
 000001           $sformatf("USB TX: gap before the packet is %0d clocks, expected 2 bits (%0d)", t_first - t_put, 2 * P));
 000001     check(st_q.size() == ref_st.size() * P,
 000001           $sformatf("USB TX: driven for %0d clocks, expected %0d bits x %0d", st_q.size(), ref_st.size(), P));
 000072     for (int i = 0; i < ref_st.size() && i * P < st_q.size(); i++)
 002304       for (int c = 0; c < P; c++)
~002304         if (i * P + c < st_q.size() && st_q[i*P+c] != ref_st[i]) begin
%000000           check(0, $sformatf("USB TX: bit %0d clock %0d is state %0d, reference %0d", i, c, st_q[i*P+c], ref_st[i]));
%000000           c = P;
%000000           i = ref_st.size();
                end
~000001     check(!drive_u && n_err_u == 0, "USB TX: line not released, or an error");
 000001     $display("A: USB transmit of %0d bytes: %0d line bits match the reference encoder", pkt.size(), ref_st.size());
        
            // ===== B: USB receive at +-1.5 % =====
 000003     for (int r = 0; r < 3; r++) begin
 000003       real ppm;
 000003       ppm = r == 0 ? 15000.0 : -15000.0;
 000003       got.delete();
 000003       n_err_u = 0;
 000003       n_fe_u = 0;
 000003       pkt = '{8'h2D, 8'h00, 8'h10, 8'hFF, 8'hFF, 8'h01, 8'h80, 8'h7F, 8'hFE};
 000003       enc_in = pkt;
 000003       usb_encode(r == 2);
 000003       usb_drive(ppm);
 000384       repeat (4 * P) @(negedge clk);
 000002       if (r < 2) begin
 000002         check(got.size() == pkt.size(), $sformatf("USB RX %0.1f %%: %0d bytes, sent %0d", ppm / 1e4, got.size(), pkt.size()));
~000018         foreach (pkt[i])
~000018           if (i < got.size()) check(got[i] === pkt[i], $sformatf("USB RX %0.1f %%: byte %0d %02x, sent %02x", ppm / 1e4, i, got[i], pkt[i]));
 000002         check(n_fe_u == 1, $sformatf("USB RX: %0d frame ends", n_fe_u));
 000002         check(n_err_u == 0, $sformatf("USB RX: %0d errors on a good packet", n_err_u));
 000002         $display("B: USB receive at %0.1f %% clock error: %0d bytes, one frame end", ppm / 1e4, got.size());
 000001       end else begin
 000001         check(n_err_u > 0, "USB RX: seven 1s in a row not reported");
 000001         $display("B: seven 1s in a row (no stuff bit) reported as a stuff error");
              end
            end
        
            // ===== C1: CAN style, NRZ, stuff after 5 equal bits, single bits =====
 000001     begin
 000001       int run, lvl_prev, maxrun;
 000001       cfg_u = 8'b0000_1101;  // bits, stuff 5 equal, NRZ
 000001       cfg_v = 8'b0000_1101;
 000001       sync_u = 0;
 000001       sync_v = 0;
 000001       use_loop = 1;
 000001       got.delete();
 000001       n_err_u = 0;
 000001       seq.delete();
 000001       seq.push_back(0);  // a start bit
 000040       for (int i = 0; i < 40; i++) seq.push_back(i < 12 ? 0 : i < 20 ? 1 : (i * 7 % 3 == 0));
 000001       fork
 000001         begin
~000041           foreach (seq[i]) send_v(seq[i], 0);
 000001           send_v(0, 1);
                end
 000001         begin  // the line never holds one level for more than 5 bits
 000001           run = 0;
 000001           maxrun = 0;
 000001           lvl_prev = -1;
 000001           @(posedge drive_v);
 000016           repeat (P / 2) @(negedge clk);
 000044           while (drive_v) begin
 000044             run = (ao_v == lvl_prev) ? run + 1 : 1;
 000044             lvl_prev = ao_v;
 000039             if (run > maxrun) maxrun = run;
 001408             repeat (P) @(negedge clk);
                  end
                end
              join
 000384       repeat (12 * P) @(negedge clk);
 000001       check(maxrun == 5, $sformatf("CAN-style TX: longest run on the line %0d bits, expected 5", maxrun));
 000001       check(got.size() >= seq.size(), $sformatf("CAN-style RX: %0d bits, sent %0d", got.size(), seq.size()));
~000041       foreach (seq[i])
~000041         if (i < got.size()) check(got[i] === seq[i], $sformatf("CAN-style bit %0d: %0d, sent %0d", i, got[i], seq[i]));
 000001       check(n_err_u == 0, "CAN-style RX: stuff error on a good frame");
 000001       $display("C: CAN style (NRZ, stuff after 5 equal, bits): %0d bits round trip, longest run %0d", seq.size(), maxrun);
            end
        
            // ===== C2: HDLC style, NRZI, stuff after 5 ones, bytes, sync 0x7E =====
 000001     cfg_u = 8'b0010_1010;  // bytes, stuff 5 ones, NRZI
 000001     cfg_v = 8'b0010_1010;
 000001     sync_u = 8'h7E;
 000001     sync_v = 8'h7E;
 000640     repeat (20 * P) @(negedge clk);
 000001     got.delete();
 000001     n_err_u = 0;
 000001     pkt = '{8'hFF, 8'h1F, 8'hF8, 8'h00, 8'hAA, 8'hFF};
~000006     foreach (pkt[i]) send_v(pkt[i], 0);
 000001     send_v(0, 1);
 000287     while (drive_v) @(negedge clk);
 000384     repeat (12 * P) @(negedge clk);
 000001     check(got.size() == pkt.size(), $sformatf("HDLC-style RX: %0d bytes, sent %0d", got.size(), pkt.size()));
~000006     foreach (pkt[i])
~000006       if (i < got.size()) check(got[i] === pkt[i], $sformatf("HDLC-style byte %0d: %02x, sent %02x", i, got[i], pkt[i]));
 000001     check(n_err_u == 0, "HDLC-style RX: stuff error on a good frame");
 000001     $display("C: HDLC style (NRZI, stuff after 5 ones, bytes): %0d bytes round trip", got.size());
        
 000001     run_line2_tests();
 000001     run_bsync_tests();
 000001     if (errors == 0) begin
 000001       $display("PASS: line coder");
 000001       $finish;
            end else $fatal(1, "FAILED with %0d error(s)", errors);
          end
        
          `include "tb_line_can.svh"
        
          initial begin
            #80ms;
            $fatal(1, "FAILED: timeout");
          end
        endmodule
        
