"""PBE register/FIFO/pin reference, specification: tt_um_pbe header + D50.

The model has separate old-state evaluation and edge commit: host transactions,
engine side effects, synchronizers and FIFO accepts all see pre-edge values.
No RTL is read at runtime. Unwritten memory is deliberately None (unspecified).
Program memory (D82): each engine has its own 256 words; ``program`` holds both, engine e's
word w at index e*256 + w. The host pointer is {PM_ADDR_H[1:0], PM_ADDR} = {engine, word, byte}.
The default build is the SRAM (``sram=True``): a write refetches its engine at the write and
one clock later, and both engines refetch once after reset (pm_wr_q, BUG-074).
Cycle priorities beyond the original register map are implementation-informed
and explicitly inventoried in verify/golden-model/ROUND2_MODEL_AUDIT.md. Direct write()
commits storage only; edge() is required for bus events/flush/restart behavior.
"""
from .pbe_model import EngineModel


class FIFO:
    def __init__(self):
        self.mem = [None] * 16
        self.rptr = self.wptr = 0
        self.mark = None   # the held read position (D70), None while no mark is held

    @property
    def count(self): return (self.wptr-self.rptr) & 31
    @property
    def empty(self): return self.count == 0
    @property
    def full(self):
        # while a mark is held, the bytes from the mark on cannot be overwritten
        return ((self.wptr - (self.rptr if self.mark is None else self.mark)) & 31) == 16
    @property
    def data(self): return self.mem[self.rptr & 15]
    @property
    def contents(self): return [self.mem[(self.rptr+i) & 15] for i in range(self.count)]

    def edge(self, push=False, data=0, pop=False, flush=False, mark=False, rewind=False):
        # Boundary acceptance uses occupancy before this edge, including simultaneous operations.
        accept_push, accept_pop = push and not self.full, pop and not self.empty
        if accept_push: self.mem[self.wptr & 15] = data
        if flush:
            self.rptr = self.wptr = 0
            self.mark = None
        else:
            if accept_push: self.wptr = (self.wptr+1) & 31
            old_rptr = self.rptr
            if rewind:
                # back to the held position; with no mark held this reads nothing again
                if self.mark is not None: self.rptr = self.mark
            elif accept_pop: self.rptr = (self.rptr+1) & 31
            if mark and not rewind: self.mark = old_rptr


class HostSPI:
    """Mode-0 byte framing. Pulses are consumed by the register bus on the next edge.

    Read staging is explicitly two clocks after byte completion (D43 FIFO-pop
    pipeline), and the first following falling edge does not shift a fresh byte.
    """
    def __init__(self):
        self.addr = self.tx = self.rx = self.bits = self.load = self.prev_sck = 0
        self.command = self.write = False
        self.wr = self.rd = None
        self.tx_unknown = 0
        self.quad = self.quad_exit = False
        self.idle_edges = 0

    @property
    def miso(self):
        index = 4 if self.quad else 7
        return None if self.tx_unknown & (1 << index) else (self.tx >> index) & 1

    @property
    def output_nibble(self): return self.tx >> 4

    def edge(self, pins, rd_data, quad_req=0):
        sck, cs, mosi = pins & 1, (pins >> 1) & 1, (pins >> 2) & 1
        rising, falling = sck and not self.prev_sck, self.prev_sck and not sck
        self.prev_sck = sck
        self.wr = self.rd = None
        self.quad_exit = False
        if cs:
            self.quad = bool(quad_req)
            if rising:
                self.quad_exit = self.idle_edges == 7
                self.idle_edges = min(7, self.idle_edges + 1)
            self.bits = self.load = self.tx = self.tx_unknown = 0
            self.command = False
            return
        self.idle_edges = 0
        stride = 4 if self.quad else 1
        old_bits, old_load = self.bits, self.load
        self.load = (old_load << 1) & 3
        if old_load & 2:
            self.tx = 0 if rd_data is None else rd_data
            self.tx_unknown = 255 if rd_data is None else 0
        if rising:
            incoming = (pins >> 2) & (15 if self.quad else 1)
            self.rx = ((self.rx << stride) | incoming) & 255
            self.bits = (old_bits+stride) & 7
            if old_bits + stride == 8:
                if not self.command:
                    self.command = True
                    self.write = bool(self.rx & 128)
                    self.addr = self.rx & 127
                    if not self.write: self.load = 1
                else:
                    if self.write: self.wr = (self.addr, self.rx)
                    else:
                        self.rd = self.addr
                        self.load = 1
                    if self.addr not in (7, 0x16, 0x26): self.addr = (self.addr+1) & 127
        if falling and old_bits:
            self.tx = (self.tx << stride) & 255
            self.tx_unknown = (self.tx_unknown << stride) & 255


WORDS = 256   # each engine's program memory (D82)


class PBEModel:
    def __init__(self, sram=True):
        self.sram = sram
        self.program = [None] * (2 * WORDS)
        self._pm_partial = {}
        self.reset()

    def reset(self):
        retained = [list(f.mem) for f in self.tx+self.rx] if hasattr(self,'tx') else None
        self.engines = [EngineModel(), EngineModel()]
        self.tx, self.rx = [FIFO(), FIFO()], [FIFO(), FIFO()]
        if retained:
            for fifo, memory in zip(self.tx+self.rx,retained): fifo.mem=memory
        self.config = [dict(clkdiv=0,pin_base=0,jmp_pin=0,out_msb_first=0,in_msb_first=0,
                            start_pc=0,crc_poly=0,crc_cfg=0,timeout=0,line_cfg=0,
                            coder_cfg=0,coder_cfg2=0,sync=0,crc_good=0,crc_wide=0) for _ in range(2)]
        self.flag_base = [0, 4]
        self.run = self.flags = self.irq = self.pin_own = self.pm_ptr = 0
        self.pm_wr_q = [self.sram, self.sram]   # the SRAM's reset refetch
        self.host1 = self.host2 = 2
        self.pins1 = self.pins2 = 0
        self.pins_n0 = self.pins_n1 = self.pins_n2 = 0
        self.host = HostSPI()
        self.hostcfg = 0
        self.cycle = 0

    @property
    def outputs(self):
        a,b = self.engines
        out = (a.pins_out & ~self.pin_own) | (b.pins_out & self.pin_own)
        oe = (a.pins_oe & ~self.pin_own) | (b.pins_oe & self.pin_own)
        uo = (self.tx[1].full << 7) | (self.tx[0].full << 6) | (not self.rx[1].empty) << 5
        uo |= (not self.rx[0].empty) << 4 | self.run << 2 | bool(self.irq) << 1 | (self.host.miso or 0)
        if self.host.quad and not self.host2 & 2:
            uo = (uo & 0xf0) | self.host.output_nibble
        return out & 255, oe & 255, uo

    @property
    def unknown_outputs(self):
        if self.host.quad and not self.host2 & 2:
            return self.host.tx_unknown >> 4
        bit = 4 if self.host.quad else 7
        return (self.host.tx_unknown >> bit) & 1

    def read(self, addr):
        if addr == 0: return self.run
        if addr == 1:
            return sum((f.empty << (e*4+2) | f.full << (e*4+3) |
                        self.rx[e].empty << (e*4) | self.rx[e].full << (e*4+1))
                       for e,f in enumerate(self.tx))
        fixed = {2:self.irq,3:self.pin_own,4:self.flags,5:self.pins2,6:self.pm_ptr & 255,
                 15:self.pm_ptr >> 8,0x50:self.hostcfg,
                 10:self.rx[0].count,11:self.rx[1].count,12:self.tx[0].count,13:self.tx[1].count}
        if addr in fixed: return fixed[addr]
        page, reg = addr >> 4, addr & 15
        if page in (1,2):
            e = page-1; c = self.config[e]; m = self.engines[e]
            values = {0:c['clkdiv'] & 255,1:c['clkdiv'] >> 8,2:c['pin_base'],3:c['jmp_pin'],
                      4:c['out_msb_first'] | c['in_msb_first'] << 1,5:c['start_pc'],
                      6:self.rx[e].data,8:self.flag_base[e],9:m.crc_now & 255,10:(m.crc_now >> 8) & 255,
                      11:c['crc_cfg'],12:c['timeout'] & 255,13:c['timeout'] >> 8,
                      14:c['line_cfg'],15:m.status}
            return values.get(reg,0)
        if page in (3,4):
            c = self.config[page-3]
            return {0:c['coder_cfg'],1:c['sync'],4:c['coder_cfg2'],2:c['crc_good'] & 255,3:(c['crc_good'] >> 8) & 255,
                    8:(self.engines[page-3].crc_now >> 16)&255,
                    9:(self.engines[page-3].crc_now >> 24)&255,
                    10:(c['crc_good'] >> 16)&255,11:(c['crc_good'] >> 24)&255,
                    12:c['crc_wide']}.get(reg,0)
        return 0

    def write(self, addr, data):
        """Commit register state only; edge() handles event ordering and FIFOs."""
        if addr == 0: self.run = data & 3
        elif addr == 2: self.irq &= ~(data & 3)
        elif addr == 3: self.pin_own = data
        elif addr == 4: self.flags = data
        elif addr == 0x50: self.hostcfg = data & 1
        elif addr == 6: self.pm_ptr = (self.pm_ptr & 0x300) | data
        elif addr == 15: self.pm_ptr = (self.pm_ptr & 0xff) | (data & 3) << 8
        elif addr == 7:
            word = (self.pm_ptr >> 9) * WORDS + (self.pm_ptr >> 1 & 255)
            old = self.program[word]
            shift = 0 if self.pm_ptr & 1 else 8
            if old is None:
                # RAM has no reset. Retain each known byte, but do not invent a
                # zero value for its unwritten neighbour. Partial words remain
                # outside the deterministic engine oracle until both are known.
                value, known = self._pm_partial.get(word, (0, 0))
                value = (value & ~(255 << shift)) | data << shift
                known |= 1 << (shift // 8)
                if known == 3:
                    self.program[word] = value
                    self._pm_partial.pop(word, None)
                else:
                    self._pm_partial[word] = value, known
            else:
                self.program[word] = (old & ~(255 << shift)) | data << shift
                self._pm_partial.pop(word, None)
            # {word, byte} advances and wraps within the engine; the engine bit stays
            self.pm_ptr = (self.pm_ptr & 0x200) | ((self.pm_ptr+1) & 0x1ff)
        page, reg = addr >> 4, addr & 15
        if page in (1,2):
            e=page-1; c=self.config[e]
            halves={0:('clkdiv',0),1:('clkdiv',8),9:('crc_poly',0),10:('crc_poly',8),
                    12:('timeout',0),13:('timeout',8)}
            if reg in halves:
                key,shift=halves[reg]; c[key]=(c[key] & ~(255 << shift)) | data << shift
            elif reg in (2,3): c[{2:'pin_base',3:'jmp_pin'}[reg]]=data & 7
            elif reg == 4: c['out_msb_first'],c['in_msb_first']=data & 1,(data >> 1) & 1
            elif reg == 5: c['start_pc']=data
            elif reg == 8: self.flag_base[e]=data & 7
            elif reg in (11,14): c[{11:'crc_cfg',14:'line_cfg'}[reg]]=data
        if page in (3,4):
            c=self.config[page-3]
            if reg in (0,1,4): c[{0:'coder_cfg',1:'sync',4:'coder_cfg2'}[reg]]=data
            elif reg in (2,3,8,9,10,11):
                key = 'crc_poly' if reg in (8,9) else 'crc_good'
                shift = {2:0,3:8,8:16,9:24,10:16,11:24}[reg]
                c[key]=(c[key] & ~(255 << shift)) | data << shift
            elif reg == 12: c['crc_wide'] = data & 1

    def sample_falling(self, pins=0):
        """First stage of D90's negedge sampler, before two rising-edge stages."""
        self.pins_n0 = pins & 255

    def edge(self, ui=2, pins=0):
        previous_request, old_exit = self.hostcfg, self.host.quad_exit
        wr,rd=self.host.wr,self.host.rd
        wa,wd=wr if wr else (-1,0)
        rd_data=self.read(self.host.addr)
        signals=[]
        # Engines and FIFOs all observe old register values and old synchronized inputs.
        for e,m in enumerate(self.engines):
            m.configure(**self.config[e])
            f=sum(((self.flags >> ((self.flag_base[e]+n)&7)) & 1) << n for n in range(4))
            clear=wd if wa == 0x1f+16*e else 0
            pm_wr=wa == 7 and (self.pm_ptr >> 9) == e   # only the selected engine's memory
            base=e*WORDS
            signals.append(m.step(lambda a,base=base: self.program[base+a],pins_in=self.pins2,pins_in_n=self.pins_n2,flags=f,
                tx_data=self.tx[e].data,tx_empty=self.tx[e].empty,rx_full=self.rx[e].full,
                run=bool(self.run & (1 << e)),restart=bool(wa == 0 and wd & (16 << e)),
                pm_wr=pm_wr or self.pm_wr_q[e],host_crc_init=bool(clear & 1),host_tmo_clr=bool(clear & 2),
                host_ovf_clr=bool(clear & 4),host_lerr_clr=bool(clear & 8)))
            if self.sram: self.pm_wr_q[e]=pm_wr
        sets=wd if wa == 8 else 0; clears=wd if wa == 9 else 0
        for e,s in enumerate(signals):
            for n in range(4):
                sets |= bool(s['flag_set'] & 1 << n) << ((self.flag_base[e]+n)&7)
                clears |= bool(s['flag_clr'] & 1 << n) << ((self.flag_base[e]+n)&7)
            self.irq |= bool(s['irq']) << e
            flush=wa == 0 and bool(wd & (64 << e))
            self.tx[e].edge(push=wa == 0x16+16*e,data=wd,pop=s['tx_pop'],
                            mark=s.get('tx_mark',False),rewind=s.get('tx_rewind',False),
                            flush=flush or (wa == 14 and bool(wd & 1 << e)))
            self.rx[e].edge(push=s['rx_push'],data=s['rx_data'],pop=rd == 0x16+16*e,flush=flush)
        self.flags=(self.flags | sets) & ~clears & 255
        if wr: self.write(wa,wd)
        for e,m in enumerate(self.engines): m.configure(**self.config[e])
        # Mode requests and exit pulses, like register writes, observe old state.
        old_request = previous_request
        self.host.edge(self.host2,rd_data,quad_req=old_request)
        if old_exit: self.hostcfg = 0
        self.host2,self.host1=self.host1,ui & 63
        self.pins2,self.pins1=self.pins1,pins
        self.pins_n2,self.pins_n1=self.pins_n1,self.pins_n0
        self.cycle+=1
        return signals

    def state(self):
        return dict(cycle=self.cycle,run=self.run,flags=self.flags,irq=self.irq,
                    engines=[dict(pc=m.pc,instr=m.instr_q,x=m.x,osr=m.osr,isr=m.isr,status=m.status)
                             for m in self.engines],tx=[f.contents for f in self.tx],rx=[f.contents for f in self.rx])
