//      // verilator_coverage annotation
        `timescale 1ns/1ps
        // Directed closure: flag-edge WAIT completion and explicit RX-overflow clear.
        module tb_coverage_gaps;
~000021   logic clk=0,rst_n=0,restart=0,run=1,host_ovf_clr=0,rx_full=1;
~000001   logic [3:0] flags=0;
          logic [15:0] program_mem[128];
~000005   wire [6:0] pc;
~000001   wire [7:0] pins_out,pins_oe;
~000001   wire [7:0] status;
 000041   always #5 clk=~clk;
          pbe_engine dut(.clk,.rst_n,.run,.restart,.clkdiv(16'd0),.pin_base(3'd0),.jmp_pin(3'd0),
            .out_msb_first(1'b0),.in_msb_first(1'b0),.start_pc(7'd0),.crc_poly(16'd0),.crc_cfg(8'd0),
            .timeout(16'd0),.line_cfg(8'h40),.coder_cfg(8'd0),.coder_cfg2(8'd0),.sync(8'd0),.crc_good(16'd0),
            .host_crc_init(1'b0),.host_tmo_clr(1'b0),.host_ovf_clr,.host_lerr_clr(1'b0),.host_arb_clr(1'b0),.host_berr_clr(1'b0),.host_sent_clr(1'b0),.status,
            .crc_now(),.can_tec(),.can_rec(),.can_state(),.pc,.pc_copy(),.instr(program_mem[pc]),.pm_wr(1'b0),.pins_in(8'd0),.pins_out,.pins_oe,
            .tx_data(8'd0),.tx_empty(1'b1),.tx_pop(),.tx_mark(),.tx_rewind(),.rx_data(),.rx_full,.rx_push(),.flags,.flag_set(),.flag_clr(),.irq());
 000021   task automatic tick; @(posedge clk); #1; endtask
 000001   initial begin
 000128     for(int i=0;i<128;i++) program_mem[i]=16'hd800;
 000001     program_mem[0]=16'h4300; // WAIT FLAG0 RISE
 000001     program_mem[1]=16'h0080; // PIN0 DRV1
 000001     program_mem[2]=16'h4380; // WAIT FLAG0 FALL
 000001     program_mem[3]=16'h0000; // PIN0 DRV0
 000001     program_mem[4]=16'hb000; // PUSH, deliberately full
 000001     program_mem[5]=16'h6050; // JMP 5
 000003     repeat(3) tick(); @(negedge clk); rst_n=1; restart=1; tick();
 000005     @(negedge clk); restart=0; repeat(5) tick();
 000001     if(pins_oe[0]) $fatal(1,"RISE wait did not block");
 000001     @(negedge clk); flags=1;
 000004     repeat(4) tick();
~000001     if(!pins_oe[0] || !pins_out[0]) $fatal(1,"RISE flag wait did not complete");
 000001     @(negedge clk); flags=0;
 000004     repeat(4) tick();
 000001     if(pins_out[0]) $fatal(1,"FALL flag wait did not complete");
~000001     if(!status[3]) $fatal(1,"full PUSH failed to set overflow");
 000001     @(negedge clk); rx_full=0; host_ovf_clr=1; tick();
 000003     @(negedge clk); host_ovf_clr=0; repeat(3) tick();
 000001     if(status[3]) $fatal(1,"overflow host clear failed");
 000001     $display("PASS: directed flag RISE/FALL WAIT and RX-overflow clear");
 000001     $finish;
          end
          initial begin #10000; $fatal(1,"coverage closure watchdog"); end
        endmodule
        
