//      // verilator_coverage annotation
        // Line coder: an optional stage between an engine's shift registers and its line pin(s).
        //
        // It owns the bit timing (one bit every period_m1 + 1 clocks), because bits it inserts or
        // removes (stuffing) must not cost the program anything (v2 lesson, docs/USB_NOTES.md).
        //
        //   cfg[1:0]  mode       0 off, 1 NRZ (the bit is the level), 2 NRZI (0 = change level, 1 = keep)
        //   cfg[3:2]  stuffing   0 none, 1 after 6 ones (USB), 2 after 5 ones (HDLC), 3 after 5 equal (CAN)
        //   cfg[4]    pair       pin a carries the line, pin b its complement; both low (SE0) ends a frame
        //   cfg[5]    bytes      the engine transfers whole bytes (else single bits)
        //   cfg2      LINE2 (D65), every bit 0 = the behaviour described below:
        //     [2:0]   sample point: 0 the default, floor(period_m1/2)+1; 1, 2, 3 add N/8, N/4, 3N/8
        //             (N = period_m1 + 1, shifted copies, no multiplier): 62.5 %, 75 %, 87.5 % of the
        //             bit when N is a multiple of 8. 4-7 are reserved and act as 0.
        //     [3]     resynchronize the receive timer on falling edges only (else on every edge)
        //     [4]     the receive pin is pin_base+1 (handled by the engine; pair mode must be off)
        //     [5]     bit-synchronous (CAN) mode: pbe_bsync replaces this module's timing (engine)
        //     [6]     before a frame starts, wait until the line has been idle for 11 bit times, or
        //             for 3 after the end of a received frame (counted at the receive sample point)
        //     [7]     the CAN frame follower of pbe_bsync (D74); not used here
        //
        // Transmit: tx_put queues a byte (or a bit in tx_data[0]), tx_end queues "end of frame"; one
        // entry is buffered (tx_ready). A frame starts with 2 idle bit times (an inter-packet gap) and
        // then sends the sync byte (if not zero), the queued data, and on tx_end: in pair mode SE0, SE0,
        // one bit of idle level, then it lets go of the line; otherwise it lets go at once.
        // Receive: a frame starts when the line leaves the idle level (1). Sampling is mid-bit, and
        // every edge re-centres the bit timer, so clock errors do not add up over a frame. Decoded bits
        // are unstuffed (a stuff bit with the wrong value is an error) and, if sync is not zero,
        // dropped until the last 8 bits equal sync. Then bytes (or bits) are delivered in rx_data.
        // The frame ends on SE0 followed by the idle level (pair mode); otherwise after 8 bit times at
        // the idle level, or when a run at the idle level breaks the stuffing rule. frame_end pulses, and
        // a byte of that frame the engine has not taken is dropped.
        //
        // Cycle contract clarified by the round-2 model audit (existing behavior):
        // - clear/reset empties queues/state, releases drive, sets a_out/b_out=1/0 and previous
        //   level=1, and clears data/valid/event outputs. The engine asserts clear while mode=off;
        //   standalone callers must do so too. Mode 3 is reserved, with no promised behavior.
        // - Transfers observe tx_ready before the edge. A newly queued item is considered on a
        //   later edge; tx_end wins if asserted with tx_put. Producers must not enqueue while
        //   !tx_ready. END without an active frame is consumed without driving. The gap leaves
        //   drive low; after two bit periods, the following clock emits the first sync/data bit.
        // - TX/RX timers are 16 bits and compare the old count. TX boundaries use == period_m1;
        //   RX sample is old_count == floor(period_m1/2)+1. An input edge resets the NEXT count
        //   but does not cancel a sample already due on that edge. At period_m1=0 RX cannot
        //   sample (its count remains 0); there is no universal receive guarantee at that rate.
        // - Sync and payload share stuffing/run state across entry boundaries. Stuffed bits pass
        //   through NRZI too. Initial previous bit/level=1, run=0; inserted ones-style bits reset
        //   run to 0, inserted equal-style bits start a new run of length 1. A TX underrun pulses
        //   err at each empty bit boundary and holds the driven level until new data/end arrives.
        // - RX is suppressed throughout non-idle TX states, including gap and end sequence. A low
        //   level starts RX even without a new edge; SE0 takes priority. Initial NRZI previous
        //   sampled level=1. The sync window is zero-filled, so it can match before 8 received
        //   bits. Transfer bit order follows in_msb_first/out_msb_first, including sync.
        // - A receive stuff violation advances run/sample state; in single mode an idle-high
        //   violation ends the frame without err. Pair SE0 length is not checked: the first later
        //   sampled non-SE0 returns idle, and pulses frame_end only if a_in=1. Single mode's 8th
        //   idle-high sample can also deliver data. Arbitrary data with no sync or long idle runs
        //   is therefore not guaranteed to round-trip without framing restrictions.
        // - RX overrun replaces the unread unit and pulses err; coincident rx_take allows the
        //   replacement without err. frame_end/err are registered one-clock indications. On the
        //   NEXT edge, old frame_end clears rx_valid, winning over a new unit/take that edge.
        // - Release clears drive but keeps output latches. Configuration is read live; changing
        //   mode/period/width/shift direction mid-frame has no protocol-validity guarantee.
        module pbe_line (
 35282306     input  logic        clk,
~000024     input  logic        rst_n,
~000160     input  logic        clear,
~000096     input  logic [7:0]  cfg,
~000022     input  logic [7:0]  cfg2,
~000031     input  logic [7:0]  sync,
~000032     input  logic [15:0] period_m1,
~000073     input  logic        out_msb_first,
~000073     input  logic        in_msb_first,
            // line pins
~007166     input  logic        a_in,        // synchronized levels
~006936     input  logic        b_in,
~000903     output logic        drive,       // the coder owns the line pin(s)
~004419     output logic        a_out,
~004221     output logic        b_out,
            // transmit
~003536     input  logic        tx_put,
~001048     input  logic        tx_end,
~020161     input  logic [7:0]  tx_data,
~004584     output logic        tx_ready,
            // receive
~000595     output logic        rx_valid,
~000163     output logic [7:0]  rx_data,
~010131     input  logic        rx_take,
~000172     output logic        frame_end,   // pulse
~003595     output logic        err          // pulse: stuff error, receive overrun or transmit underrun
        );
~000141   wire       nrzi  = cfg[1:0] == 2'd2;
~35282308   wire       _unused = &{cfg[7:6], cfg2[7], cfg2[5:4], 1'b0};  // reserved; [5:4] are the engine's
~000022   wire [2:0] sp_sel = cfg2[2:0];
~000141   wire       fall_only = cfg2[3];
~000073   wire       idle_wait = cfg2[6];
~000024   wire [1:0] st    = cfg[3:2];
~000141   wire       pair  = cfg[4];
~000141   wire       bytes = cfg[5];
~000141   wire       ones  = st != 2'd3;                    // stuff after ones, else after equal bits
~35282308   wire [2:0] run_n = (st == 2'd1) ? 3'd6 : 3'd5;
~35282308   wire [3:0] width = bytes ? 4'd8 : 4'd1;
        
          // ---------------- transmit ----------------
          localparam logic [2:0] T_IDLE = 3'd0, T_GAP = 3'd1, T_RUN = 3'd2, T_SE0A = 3'd3, T_SE0B = 3'd4,
                                 T_J = 3'd5;
~001657   logic [2:0]  ts;
~059744   logic [15:0] tcnt;
~000910   logic        gap2, kick;           // second gap bit; emit a bit now (frame start)
~004584   logic        q_valid, q_end;
~002418   logic [7:0]  q_data, tsh;
~006558   logic [3:0]  tbits;                // bits left in tsh
~004330   logic        level;                // line level, 1 = idle (USB J)
~005049   logic [2:0]  trun;
~004306   logic        tlast, tstuff;        // stuff bit due in the next slot
        
~35282308   assign tx_ready = !q_valid;
~013252   wire boundary = tcnt == period_m1;
        
          // what the next bit slot sends
~35282308   wire        n_load = !tstuff && tbits == 4'd0 && q_valid && !q_end;
~35282308   wire [7:0]  q_bits = (!bytes && out_msb_first) ? {q_data[0], 7'b0} : q_data;
~35282308   wire [7:0]  n_src  = n_load ? q_bits : tsh;
~35282308   wire        n_bit  = tstuff ? (ones ? 1'b0 : !tlast) : (out_msb_first ? n_src[7] : n_src[0]);
~35282308   wire        n_have = tstuff || tbits != 4'd0 || n_load;
~35282308   wire        n_end  = !tstuff && tbits == 4'd0 && q_valid && q_end;
~35282308   wire [3:0]  n_left = n_load ? width - 4'd1 : tbits - 4'd1;
~35282308   wire [7:0]  n_rest = out_msb_first ? {n_src[6:0], 1'b0} : {1'b0, n_src[7:1]};
          // stuffing state after this bit
~005289   logic [2:0] n_run;
~004891   logic       n_last;
 35282308   always_comb begin
~002860     if (tstuff) begin
~002860       n_run  = ones ? 3'd0 : 3'd1;
~002860       n_last = n_bit;
~35282308     end else if (ones) begin
~35282308       n_run  = n_bit ? trun + 3'd1 : 3'd0;
 35282308       n_last = n_bit;
~2720592     end else begin
~2720592       n_run  = (n_bit == tlast) ? trun + 3'd1 : 3'd1;
~2720592       n_last = n_bit;
            end
          end
~35282308   wire n_stuff = !tstuff && st != 2'd0 && n_run == run_n;
~35282308   wire n_level = nrzi ? (n_bit ? level : !level) : n_bit;
        
          // ---------------- receive ----------------
          localparam logic [1:0] R_IDLE = 2'd0, R_RUN = 2'd1, R_SE0 = 2'd2;
~000550   logic [1:0]  rs;
~449839   logic [15:0] rcnt;
~003584   logic        a_d, rprev, rlast, rstuff, hunting;
~002400   logic [2:0]  rrun, ridle;
~000888   logic [7:0]  win, rsh;
~002380   logic [3:0]  rbits;
        
~35282308   wire        se0    = pair && !a_in && !b_in;
          // sample point (LINE2[2:0]); 0 is the original floor(period_m1/2)+1
~000064   wire [15:0] n_per  = period_m1 + 16'd1;
~35282308   wire        _unused_nper = &{n_per[1:0], 1'b0};
~000018   logic [15:0] sp_add;
 35282308   always_comb begin
 35282308     case (sp_sel)
~004929       3'd1:    sp_add = {3'b0, n_per[15:3]};
~2711088       3'd2:    sp_add = {2'b0, n_per[15:2]};
~005133       3'd3:    sp_add = {2'b0, n_per[15:2]} + {3'b0, n_per[15:3]};
 35282308       default: sp_add = 16'd0;
            endcase
          end
          // The default sample point is computed as before. The others come from a register,
          // updated every clock from CLKDIV and LINE2, so the adders are not on the counter's
          // compare path (timing review of D65); a change of either takes effect one clock later.
          // sp_ok: sp_q holds a computed value (from the first clock after reset); before it, sp_q's
          // reset 0 matched rcnt's and sample points 1-3 also sampled at the first clock (BUG-104).
~000064   wire [15:0] sp_base = {1'b0, period_m1[15:1]} + 16'd1;
~000064   logic [15:0] sp_q;
~000024   logic        sp_ok;
 35282306   always_ff @(posedge clk or negedge rst_n)
~35282296     if (!rst_n) begin
~000164       sp_q  <= '0;
~000164       sp_ok <= 1'b0;
 35282296     end else begin
 35282296       sp_q  <= sp_base + sp_add;
 35282296       sp_ok <= 1'b1;
            end
~35282308   wire        sp_dflt = sp_sel == 3'd0 || sp_sel[2];
~35282308   wire        sample = rcnt == (sp_dflt ? sp_base : sp_q) && (sp_dflt || sp_ok);
          // LINE2[6]: idle bit times seen at the sample point (saturating at 11), and whether the
          // last thing on the line was the end of a frame (then 3 idle bits are enough)
~000527   logic [3:0] icnt;
~000172   logic       after_end;
~35282308   wire        tx_ok = !idle_wait || icnt == 4'd11 || (after_end && icnt >= 4'd3);
~35282308   wire        r_bit  = nrzi ? (a_in == rprev) : a_in;
~35282308   wire        r_exp  = ones ? 1'b0 : !rlast;           // value a stuff bit must have
~009896   logic [2:0] r_run;
 35282308   always_comb begin
~003544     if (rstuff)    r_run = ones ? 3'd0 : 3'd1;
~35282308     else if (ones) r_run = r_bit ? rrun + 3'd1 : 3'd0;
~2720592     else           r_run = (r_bit == rlast) ? rrun + 3'd1 : 3'd1;
          end
~35282308   wire [7:0] win_n = in_msb_first ? {win[6:0], r_bit} : {r_bit, win[7:1]};
~35282308   wire [7:0] rsh_n = in_msb_first ? {rsh[6:0], r_bit} : {r_bit, rsh[7:1]};
        
 35282306   always_ff @(posedge clk or negedge rst_n) begin
~35282296     if (!rst_n) begin
~000164       ts <= T_IDLE; tcnt <= '0; gap2 <= 1'b0; kick <= 1'b0;
~000164       q_valid <= 1'b0; q_end <= 1'b0; q_data <= '0; tsh <= '0; tbits <= '0;
~000164       level <= 1'b1; trun <= '0; tlast <= 1'b1; tstuff <= 1'b0;
~000164       drive <= 1'b0; a_out <= 1'b1; b_out <= 1'b0;
~000164       rs <= R_IDLE; rcnt <= '0; a_d <= 1'b1; rprev <= 1'b1; rlast <= 1'b1; rstuff <= 1'b0;
~000164       hunting <= 1'b0; rrun <= '0; ridle <= '0; win <= '0; rsh <= '0; rbits <= '0;
~000164       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0;
~000164       icnt <= '0; after_end <= 1'b0;
~35282296     end else if (clear) begin
~35282296       ts <= T_IDLE; tcnt <= '0; gap2 <= 1'b0; kick <= 1'b0;
~35282296       q_valid <= 1'b0; q_end <= 1'b0; q_data <= '0; tsh <= '0; tbits <= '0;
~35282296       level <= 1'b1; trun <= '0; tlast <= 1'b1; tstuff <= 1'b0;
~35282296       drive <= 1'b0; a_out <= 1'b1; b_out <= 1'b0;
~35282296       rs <= R_IDLE; rcnt <= '0; a_d <= 1'b1; rprev <= 1'b1; rlast <= 1'b1; rstuff <= 1'b0;
~35282296       hunting <= 1'b0; rrun <= '0; ridle <= '0; win <= '0; rsh <= '0; rbits <= '0;
~35282296       rx_valid <= 1'b0; rx_data <= '0; frame_end <= 1'b0; err <= 1'b0;
~35282296       icnt <= '0; after_end <= 1'b0;
~901155     end else begin
~901155       frame_end <= 1'b0;
~901155       err       <= 1'b0;
        
              // ---- transmit ----
~900752       if (tx_put || tx_end) begin
~004584         q_valid <= 1'b1;
~004584         q_end   <= tx_end;
~004584         q_data  <= tx_data;
              end
~901155       tcnt <= (ts == T_IDLE || boundary || kick) ? 16'd0 : tcnt + 16'd1;
~901155       kick <= 1'b0;
~901155       case (ts)
~781568         T_IDLE:
~781469           if (q_valid) begin
~000253             if (q_end) q_valid <= 1'b0;  // end with no frame: nothing to do
~000915             else if (tx_ok) begin
~000915               ts   <= T_GAP;
~000915               gap2 <= 1'b0;
                    end
                  end
~007455         T_GAP:
~006138           if (boundary) begin
~001813             gap2 <= 1'b1;
~000910             if (gap2) begin             // the gap is over: start the frame
~000903               ts     <= T_RUN;
~000903               kick   <= 1'b1;
~000903               level  <= 1'b1;
~000903               trun   <= '0;
~000903               tlast  <= 1'b1;
~000903               tstuff <= 1'b0;
~000903               tsh    <= sync;
~000903               tbits  <= (sync != 8'd0) ? 4'd8 : 4'd0;
                    end
                  end
~103747         T_RUN:
~897322           if (boundary || kick) begin
~015437             if (n_have) begin
~015437               level  <= n_level;
~015437               a_out  <= n_level;
~015437               b_out  <= !n_level;
~015437               drive  <= 1'b1;
~015437               trun   <= n_run;
~015437               tlast  <= n_last;
~015437               tstuff <= n_stuff;
~015251               if (!tstuff) begin
~015251                 tsh   <= n_rest;
~015251                 tbits <= n_left;
                      end
~011981               if (n_load) q_valid <= 1'b0;
~008012             end else if (n_end) begin
~000777               q_valid <= 1'b0;
~000402               if (pair) begin
~000375                 ts    <= T_SE0A;
~000375                 a_out <= 1'b0;
~000375                 b_out <= 1'b0;
~000402               end else begin
~000402                 ts    <= T_IDLE;
~000402                 drive <= 1'b0;
                      end
~008012             end else err <= 1'b1;       // underrun: the line keeps its level
                  end
~003168         T_SE0A: if (boundary) ts <= T_SE0B;
~003168         T_SE0B:
~003069           if (boundary) begin
~000367             ts    <= T_J;
~000367             a_out <= 1'b1;
~000367             b_out <= 1'b0;
                  end
~003168         default:                        // T_J: one bit of idle level, then let go
~003069           if (boundary) begin
~000365             ts    <= T_IDLE;
~000365             drive <= 1'b0;
~000365             level <= 1'b1;
                  end
              endcase
        
              // ---- receive (off while transmitting: half duplex) ----
~901155       a_d <= a_in;
~900561       if (rx_take) rx_valid <= 1'b0;
~901155       rcnt <= ((fall_only ? (a_d && !a_in) : (a_in != a_d)) || rcnt == period_m1) ? 16'd0 : rcnt + 16'd1;
~872998       if (sample) begin
~025432         if (!a_in || ts != T_IDLE || rs != R_IDLE) icnt <= 4'd0;
~002684         else if (icnt != 4'd11) icnt <= icnt + 4'd1;
              end
~000172       if (frame_end) after_end <= 1'b1;
~880385       else if (sample && !a_in) after_end <= 1'b0;
~781568       if (ts != T_IDLE) rs <= R_IDLE;
~781568       else case (rs)
~093029         R_IDLE:
~000014           if (se0) rs <= R_SE0;
~093011           else if (!a_in) begin         // the line left the idle level: a frame starts
~000550             rs      <= R_RUN;
~000550             rprev   <= 1'b1;
~000550             rlast   <= 1'b1;
~000550             rrun    <= '0;
~000550             rstuff  <= 1'b0;
~000550             ridle   <= '0;
~000550             hunting <= sync != 8'd0;
~000550             win     <= '0;
~000550             rbits   <= '0;
                  end
~198703         R_RUN:
~192403           if (sample) begin
~006132             if (se0) rs <= R_SE0;
~006132             else begin
~006132               rprev <= a_in;
~006132               rlast <= rstuff ? r_exp : r_bit;
~006132               rrun  <= r_run;
                      // without SE0, a frame ends after 8 bit times at the idle level
~006132               ridle <= a_in ? ridle + 3'd1 : 3'd0;
~006132               if (!pair && a_in && ridle == 3'd7) begin
~000013                 rs        <= R_IDLE;
~000013                 frame_end <= 1'b1;
                      end
~006104               if (rstuff) begin
~000028                 rstuff <= 1'b0;
~000023                 if (r_bit != r_exp) begin
                          // Without SE0, a run too long for stuffing at the idle level is how a frame
                          // ends (HDLC flag or abort, CAN end of frame); anywhere else it is an error.
~000006                   if (!pair && a_in) begin
~000002                     rs        <= R_IDLE;
~000002                     frame_end <= 1'b1;
~000006                   end else err <= 1'b1;
                        end
~006104               end else begin
~006104                 rstuff <= st != 2'd0 && r_run == run_n;
~001344                 if (hunting) begin
~001344                   win <= win_n;
~001176                   if (win_n == sync) hunting <= 1'b0;
~004165                 end else if (rbits == width - 4'd1) begin
~000595                   rx_data  <= bytes ? rsh_n : {7'b0, r_bit};
~000595                   if (rx_valid && !rx_take) err <= 1'b1;  // the engine missed one
~000595                   rx_valid <= 1'b1;
~000595                   rbits    <= '0;
~000595                   rsh      <= rsh_n;
~004165                 end else begin
~004165                   rbits <= rbits + 4'd1;
~004165                   rsh   <= rsh_n;
                        end
                      end
                    end
                  end
~491858         default:                        // R_SE0: wait for the idle level
~757145           if (sample && !se0) begin
~000172             rs        <= R_IDLE;
~000172             frame_end <= a_in;
                  end
              endcase
              // A byte the engine has not taken when its frame ends belongs to that frame: drop it,
              // so it cannot be read as the start of the next frame (BUG-028).
~900983       if (frame_end) rx_valid <= 1'b0;
            end
          end
~35282306   always @(posedge clk) if (rst_n && !clear && (drive || rx_valid || ts != T_IDLE || rs != R_IDLE)) begin
~810149     pbe_cov_line_1_0_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_1_0_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_1_0_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_1_0_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_1_1_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_1_1_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_1_1_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_1_1_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_1_2_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_1_2_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_1_2_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_1_2_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_1_3_0_0: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_1_3_0_1: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_1_3_1_0: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_1_3_1_1: cover (cfg[1:0] == 1 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_2_0_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_2_0_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_2_0_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_2_0_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 0 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_2_1_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_2_1_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_2_1_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_2_1_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 1 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_2_2_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_2_2_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_2_2_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_2_2_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 2 && cfg[4] == 1 && cfg[5] == 1);
~810149     pbe_cov_line_2_3_0_0: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 0);
~810149     pbe_cov_line_2_3_0_1: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 0 && cfg[5] == 1);
~810149     pbe_cov_line_2_3_1_0: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 0);
~810149     pbe_cov_line_2_3_1_1: cover (cfg[1:0] == 2 && cfg[3:2] == 3 && cfg[4] == 1 && cfg[5] == 1);
          end
        
 000002   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
