//      // verilator_coverage annotation
        // General CRC unit, one per engine. Any polynomial up to 16 bits.
        //
        // One bit per step, shifted in at the bottom of a shift-left register (the polynomial's top
        // term is implied). Feed bits in the order they are on the wire. For CRCs sent LSB first
        // (Modbus CRC-16, 1-Wire CRC-8) read the result bit-reversed (out_rev); for CRCs sent MSB
        // first (CAN CRC-15) read it plain. A frame followed by its own correct CRC leaves the
        // register at zero for every CRC without a final inversion, and at a fixed residual for CRCs
        // sent inverted (USB CRC16: 0x800d). "CRC ok" means the register equals `good`.
        // Reset sets the register to zero regardless of init_ones. init wins over a coincident
        // step and loads zero/all width bits set; each step XORs bit_in with the old top bit,
        // shifts left with zero at bit 0, conditionally XORs poly, then masks to the width.
        // out_rev reverses only width bits and zero-extends; good compares the raw 16-bit state.
        // Live width/poly/good changes do not themselves initialize or mask the stored state.
        //
        //   Modbus CRC-16: poly 0x8005, 16 bits, init all ones, reversed output
        //   1-Wire CRC-8:  poly 0x31,    8 bits, init zero,     reversed output
        //   USB CRC16:     poly 0x8005, 16 bits, init all ones, reversed output, sent inverted, good 0x800d
        module pbe_crc (
 35282306     input  logic        clk,
~000024     input  logic        rst_n,
 000267     input  logic        init,       // load the initial value
~011548     input  logic        step,       // shift in bit_in
~023112     input  logic        bit_in,
~000022     input  logic [15:0] poly,
~000022     input  logic [3:0]  width_m1,   // CRC width - 1
~000141     input  logic        init_ones,
~000141     input  logic        out_rev,
~000002     input  logic [15:0] good,       // the register value that means "ok"
~002856     output logic [15:0] value,      // the CRC field, ready to send LSB first if out_rev
~000204     output logic        ok
        );
~002856   logic [15:0] crc, rev;
        
~000022   wire [15:0] top  = 16'h0001 << width_m1;
~000022   wire [15:0] mask = {top[14:0], 1'b0} - 1'b1;  // width 16: wraps to all ones
~023086   wire        fb   = bit_in ^ |(crc & top);
        
 35282306   always_ff @(posedge clk or negedge rst_n) begin
 35282296     if (!rst_n) crc <= '0;
~000267     else if (init) crc <= init_ones ? mask : '0;
~35282288     else if (step) crc <= ({crc[14:0], 1'b0} ^ (fb ? poly : 16'h0000)) & mask;
          end
        
 35282308   always_comb begin
~564516928     for (int i = 0; i < 16; i++) rev[i] = (4'(i) <= width_m1) ? crc[width_m1 - 4'(i)] : 1'b0;
          end
        
~35282308   assign value = out_rev ? rev : crc;
          assign ok    = (crc == good);
        
 000002   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
