//      // verilator_coverage annotation
        // Host register port: an SPI peripheral, mode 0 (sample on SCK rising, shift on falling), MSB first.
        //
        // Transaction: CS_n low, command byte, then any number of data bytes.
        //   command[7]   1 = write, 0 = read
        //   command[6:0] register address
        // The address auto-increments after every data byte, except for the streaming registers
        // (program memory data and the engine FIFOs), so a burst can stream many bytes into one.
        //
        // SCK, CS_n and MOSI arrive already synchronized to clk, so SCK must be at most clk/8.
        // Cycle contract (round-2 clarification): byte completion registers wr_en/rd_done;
        // the top-level bus consumes the pulse on the following clk edge. Read data stages into
        // MISO two clk edges after command/read-byte completion, after a FIFO pop has landed.
        // The first following SCK falling edge (bit count 0) does not shift this fresh byte.
        // Stream addresses are exactly 0x07, 0x16, 0x26; other addresses wrap modulo 128.
        // CS_n high abandons any partial byte, clears command framing, read-load pipeline and
        // transmit shifter/MISO, but preserves address/receive shifter and commits any previously
        // issued bus pulse. Reset zeros all host state. Write transactions have no promised MISO
        // payload; read prefetch may expose unspecified head data if an empty FIFO is selected.
        module pbe_host_spi (
 17641153     input  logic       clk,
~000012     input  logic       rst_n,
 916480     input  logic       sck,
 056261     input  logic       cs_n,
 067370     input  logic       mosi,
 154783     output logic       miso,
            // register bus
~042683     output logic [6:0] addr,     // current address; rd_data must be the register at addr
 040626     input  logic [7:0] rd_data,
 004602     output logic       wr_en,    // 1-cycle pulse
~000448     output logic [6:0] wr_addr,
 000950     output logic [7:0] wr_data,
 053698     output logic       rd_done,  // 1-cycle pulse: the byte read from rd_addr has been sent
~011113     output logic [6:0] rd_addr
        );
 916480   logic       sck_d;
 458240   logic [2:0] bitcnt;
 159850   logic [7:0] rx_sh, tx_sh;
 056260   logic       have_cmd, is_write;
 107396   logic [1:0] load_dly;  // load tx_sh two cycles after a byte so a FIFO pop has landed
        
 17510402   wire        sck_rise = sck & ~sck_d;
 17510402   wire        sck_fall = ~sck & sck_d;
 067370   wire  [7:0] rx_byte = {rx_sh[6:0], mosi};
~15085656   wire        no_incr = (addr == 7'h07) || (addr == 7'h16) || (addr == 7'h26);  // streaming registers
        
          assign miso = tx_sh[7];
          wire   _unused = rx_sh[7];  // the 8th bit of a byte comes straight from mosi
        
 17641153   always_ff @(posedge clk or negedge rst_n) begin
 17641148     if (!rst_n) begin
 000082       sck_d    <= 1'b0;
 000082       bitcnt   <= '0;
 000082       rx_sh    <= '0;
 000082       tx_sh    <= '0;
 000082       have_cmd <= 1'b0;
 000082       is_write <= 1'b0;
 000082       load_dly <= '0;
 000082       addr     <= '0;
 000082       wr_en    <= 1'b0;
 000082       wr_addr  <= '0;
 000082       wr_data  <= '0;
 000082       rd_done  <= 1'b0;
 000082       rd_addr  <= '0;
 17641148     end else begin
 17641148       sck_d   <= sck;
 17641148       wr_en   <= 1'b0;
 17641148       rd_done <= 1'b0;
        
 15563840       if (cs_n) begin
 14556465         bitcnt   <= '0;
 14556465         have_cmd <= 1'b0;
 14556465         load_dly <= '0;
 14556465         tx_sh    <= '0;
 15563840       end else begin
 15563840         load_dly <= {load_dly[0], 1'b0};
 15456444         if (load_dly[1]) tx_sh <= rd_data;
        
 14647360         if (sck_rise) begin
 916480           rx_sh  <= rx_byte;
 916480           bitcnt <= bitcnt + 1'b1;
 801920           if (bitcnt == 3'd7) begin
 058300             if (!have_cmd) begin
 056260               have_cmd <= 1'b1;
 056260               is_write <= rx_byte[7];
 056260               addr     <= rx_byte[6:0];
 053698               if (!rx_byte[7]) load_dly <= 2'b01;
 053698             end else if (is_write) begin
 004602               wr_en   <= 1'b1;
 004602               wr_addr <= addr;
 004602               wr_data <= rx_byte;
 003950               if (!no_incr) addr <= addr + 1'b1;
 053698             end else begin
 053698               rd_done  <= 1'b1;
 053698               rd_addr  <= addr;
 053698               load_dly <= 2'b01;
~051606               if (!no_incr) addr <= addr + 1'b1;
                    end
                  end
                end
        
                // The first bit of a freshly loaded byte is already on MISO, so skip the
                // falling edge that follows the last bit of the previous byte.
 14761920         if (sck_fall && bitcnt != 3'd0) tx_sh <= {tx_sh[6:0], 1'b0};
              end
            end
          end
        
 000001   final begin $c("VerilatedCov::write();"); end
        
        endmodule
        
