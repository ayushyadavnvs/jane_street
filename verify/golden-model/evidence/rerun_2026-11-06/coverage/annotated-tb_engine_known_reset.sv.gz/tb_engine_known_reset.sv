//      // verilator_coverage annotation
        `timescale 1ns/1ps
        // Four-state supplement: formal's two-state bit vectors cannot prove absence of X.
        module tb_engine_known_reset;
~000781   logic clk=0,rst_n=0,restart=0,run=0;
~000096   logic [7:0] coder_cfg=0, coder_cfg2=0;
~000002   logic [15:0] instr=16'hd800;
~000001   wire [7:0] pins_out,pins_oe,rx_data;
~000001   wire [7:0] status;
%000000   wire [8:0] can_tec;
%000000   wire [7:0] can_rec;
%000000   wire [1:0] can_state;
~000001   wire [15:0] crc_now;
~000338   wire [6:0] pc;
~000338   wire [20:0] pc_copy;
%000000   wire [3:0] flag_set,flag_clr;
%000000   wire tx_pop,rx_push,irq;
 001562   always #5 clk=~clk;
          pbe_engine dut(.clk,.rst_n,.run,.restart,.clkdiv(16'd3),
            .pin_base(3'd0),.jmp_pin(3'd0),.out_msb_first(1'b0),.in_msb_first(1'b0),
            .start_pc(7'd0),.crc_poly(16'h8005),.crc_cfg(8'h3f),.timeout(16'd0),
            .line_cfg(8'h40),.coder_cfg,.coder_cfg2,.sync(8'h80),.crc_good(16'd0),
            .host_crc_init(1'b0),.host_tmo_clr(1'b0),.host_ovf_clr(1'b0),.host_lerr_clr(1'b0),
            .host_arb_clr(1'b0),.host_berr_clr(1'b0),.host_sent_clr(1'b0),
            .status,.can_tec,.can_rec,.can_state,.crc_now,.pc,.pc_copy,.instr,.pm_wr(1'b0),
            .pins_in(8'h01),.pins_out,.pins_oe,.tx_data(8'ha5),.tx_empty(1'b1),
            .tx_pop,.tx_mark(),.tx_rewind(),.rx_data,.rx_full(1'b0),.rx_push,.flags(4'd0),.flag_set,.flag_clr,.irq);
 000771   task automatic known;
            // two checks: Icarus 12 misreports $isunknown on this concatenation once it is 106 bits wide
 000771     if ($isunknown({pins_out,pins_oe,flag_set,flag_clr,tx_pop,rx_push,irq,rx_data,status,crc_now,pc,pc_copy})
~000771         || $isunknown({can_tec,can_rec,can_state}))
              $fatal(1,"engine reset/restart has an unknown output cfg=%h cfg2=%h",coder_cfg,coder_cfg2);
          endtask
 000001   initial begin
 000003     repeat(3) begin @(posedge clk); #1; known(); end
 000001     @(negedge clk); rst_n=1; run=1; instr=16'h0080; // known drive-high word
 000010     repeat(10) @(negedge clk);
            // every LINE bit field, with LINE2 off, in bit-synchronous (CAN) mode, and all LINE2 bits
 000192     for (int c=0;c<192;c++) begin
 000192       coder_cfg=8'(c%64); coder_cfg2=c<64 ? 8'h00 : c<128 ? 8'h20 : 8'h7f; restart=1;
 000192       @(posedge clk); #1; known();
 000192       if(pins_oe!==0) $fatal(1,"restart must release enables cfg=%h",coder_cfg);
 000192       @(negedge clk); restart=0; instr=16'hd800;
 000576       repeat(3) begin @(posedge clk); #1; known(); @(negedge clk); end
            end
 000001     $display("PASS: four-state reset/restart outputs, all 64 coder bit-field combinations x LINE2 off, CAN mode, all LINE2 bits");
 000001     $finish;
          end
          initial begin #60000; $fatal(1,"known-output regression timeout"); end
        endmodule
        
