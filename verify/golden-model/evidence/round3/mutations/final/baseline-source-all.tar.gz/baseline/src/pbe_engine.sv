// One Programmable Bit Engine.
//
// Instruction word (16 bits):  [15:13] OP | [12:4] ARG | [3:0] DLY
// Each instruction issues on a tick and then idles DLY more ticks before the next one.
// A tick is one clock every (clkdiv + 1) clocks.
//
// Instruction fetch (D50): the instruction runs from a register (instr_q), not straight from
// the program memory, which cuts the clock's worst path in two. The memory is read at `pc`,
// the word after the current instruction, so the next word is always ready when the current
// one executes. A taken jump (JMP, JCRCBAD, JEQ, JNE, JLINE, the timeout) must fetch its target
// first: one clock with no instruction (a bubble). A tick that falls on a bubble is held for
// that clock, so it is late, never lost. Instruction times:
//   CLKDIV >= 1: (DLY + 1) * (CLKDIV + 1) clocks, exactly as without the register (the next
//                tick is at least 2 clocks away, and the bubble fits in between).
//   CLKDIV = 0, and the line coder (instructions run every clock): DLY + 1 clocks, plus 1 for
//                a taken jump. The first instruction after a restart starts 1 clock later.
// A host write to any word of this engine's program memory invalidates the next-to-run
// instruction (one bubble; two with the SRAM, whose port the write takes, BUG-074).
// It does not cancel an instruction already ready to execute on that same edge: that
// instruction uses the old registered word. If blocked/stopped, the current word is fetched
// again; after an executing instruction, its successor (or taken target) is fetched again.
// The memory write commits at the edge, so the subsequent refill sees the updated word.
//
//  OP   name        ARG
//  000  PIN p, act  [8:6] pin, [5:3] act: 0 DRV0, 1 DRV1, 2 REL, 3 TOG, 4 OUT, 5 OUTOD, 6 OUTPAR,
//                   7 END (line coder: end the frame); [0] NOCRC (OUT/OUTOD): leave this bit out
//                   of the CRC
//  001  IN p        [8:6] pin, [5] NOCRC       shift pin into ISR
//  010  WAIT        [8:6] pin (or flag in [7:6]), [5] 1 = flag, [4:3] 0 LOW, 1 HIGH, 2 RISE, 3 FALL
//  011  JMP         [8:6] cond, [5:0] addr    cond: 0 ALWAYS, 1 X-- != 0, 2 PIN_HI, 3 PIN_LO,
//                                             4 TX_EMPTY, 5 TX_READY, 6 FLAG0, 7 FLAG1
//  100  SET         [8] 0 = X, 1 = OSR; [7:0] value
//  101  PULL/PUSH   [8] 0 = PULL (TX FIFO -> OSR), 1 = PUSH (ISR -> RX FIFO, then clear ISR)
//                   PULL group [7:6] (D70): 0 PULL (waits while empty), 1 PULL NOWAIT (an empty
//                   FIFO gives OSR = 0xFF, no wait), 2 MARK (hold the TX FIFO's read position),
//                   3 REWIND (read the TX FIFO again from the held position)
//  110  FLAG        [8:7] 0 SET, 1 CLR, 2 IRQ, 3 MOV; [1:0] flag
//                   MOV: [5:4] destination, [3:2] source: 1 X, 2 OSR, 3 ISR (source 0: zero);
//                   destination 0 does nothing (0xD800 is the assembler's NOP)
//  111  EXT         [8:6] sub-op, [5:0] param
//                   0 CRCRST      load the CRC's initial value and clear the line error: a new
//                                 checked packet starts
//                   1 OSRCRC      OSR <= CRC byte {param[3], param[0]} (0 low, 1 high, 2 and 3
//                                 the upper bytes of a CRC wider than 16 bits, D91; for a CRC of
//                                 up to 16 bits param[3] is ignored, as before); param[1]:
//                                 inverted; param[2]: a CRC of up to 16 bits left-justified to
//                                 16 bits first, so CRC-15's high byte is bits 14..7 (D71)
//                   2 STAT        ISR <= {frame sent, bit error, arbitration lost, line error,
//                                 RX overflow, timeout happened, CRC ok, parity error} (bits 7..5
//                                 from the bit-synchronous coder, D71); then clears parity and
//                                 timeout (not the line error: a JCRCBAD after STAT must still see
//                                 it). CRCRST clears line error, arbitration lost, bit error and
//                                 frame sent: they describe one packet.
//                   3 JCRCBAD a   jump to a if the packet is bad: the CRC is not ok (not at its
//                                 good value) or the line coder saw an error since the last CRCRST
//                                 (in bit-synchronous mode every bus error, bit errors included,
//                                 is a line error)
//                   4 JEQ a       jump to a if ISR == OSR
//                   5 JNE a       jump to a if ISR != OSR
//                   6 JLINE a     jump to a if the line coder saw the end of a frame; clears it
//                   7 param[5]=0: LINECTL (D67), the bit-synchronous coder's controls
//                                 param[4]=0: unit width = param[2:0] + 1 bits for OUT and IN,
//                                             arbitration window = param[3]
//                                 param[4]=1: [0] stuffing off (ends the stuffed region: the
//                                             coder runs the CAN frame tail), [1] stuffing on,
//                                             [2] error now (an error flag from the next bit)
//                                 without bit-synchronous mode only param[4] = 1's [0] and
//                                 [1] act: pbe_line's stuffing off/on (D94); the rest does nothing
//                     param[5]=1: PAGE p (D83), p = param[1:0] ([4:2] reserved, 0): the next
//                                 instruction's jump target is in page p of the program
//                                 (a one-shot prefix; see "Program addresses" below)
//
// Parity: OUT/OUTOD bits since the last OSR load make the send parity; OUTPAR drives it
// (inverted for odd parity). IN bits since the last STAT make the receive parity; with the
// parity bit included it must come out 0 (even) or 1 (odd), otherwise STAT reports an error.
// With line_cfg[6] (no parity) OUTPAR sends 1 (a second stop bit) and no parity error is reported.
// RX overflow: a PUSH that finds the RX FIFO full sets a sticky status bit and raises IRQ.
// CRC: OUT/OUTOD and IN bits feed the CRC unit when enabled in crc_cfg, unless marked NOCRC.
// "CRC ok" means the register equals crc_good (0 for CRCs sent plain; the residual, e.g. USB's
// 0x800d, for CRCs sent inverted).
//
// Line coder (coder_cfg[1:0] != 0: NRZ, NRZI or Manchester, see pbe_line): it drives pin_base (and pin_base + 1 in pair
// mode) and sets the bit timing: clkdiv is then the bit time minus 1, and instructions run
// every clock. OUT/OUTOD hand the coder a byte (or one bit) and wait while it is busy; END ends
// the frame; IN takes a received byte (or bit) and waits for one, or for the end of the frame
// (then ISR is unchanged and JLINE jumps). In byte mode the 8 bits of each OUT/IN feed the CRC
// one per clock afterwards; the next instruction waits until they are in.
// Timeout: if WAIT, PULL or PUSH stays blocked for timeout ticks (0 = never), the engine
// abandons it, jumps to timeout_pc and sets the "timeout happened" status bit.
// Bit-synchronous (CAN) mode (LINE2[5], pbe_bsync, D66): OUT queues a unit of the current
// width from the top of OSR (OSR is not shifted), IN takes a unit into ISR right-justified,
// and the CRC is fed by the coder with every bit of the stuffed region as it is sampled (not
// by OUT or IN). A transfer (IN, OUT, OUTOD, END) issued while a frame-end or error event is
// pending is abandoned: the engine consumes the event, drops the queued unit and jumps to
// timeout_pc (the line-event vector) without setting "timeout happened". While the engine is
// stopped (run = 0) its bit-synchronous coder is held clear (counters kept): a node without a
// running program must not acknowledge or flag frames.
//
// WAIT, PULL and PUSH block until they can complete. While blocked the engine checks
// every clock (not every tick), and when it unblocks the tick divider restarts, so
// following instructions are timed from the moment the condition was met.
//
// Pin numbers are relative to pin_base (mod 8); the JMP pin is jmp_pin + pin_base.
// Program addresses are relative to start_pc: a program starts at its own word 0. Each engine
// has its own 256-word program memory (D82), so pc and start_pc address only it, and a program
// may use all of it: four 64-word pages, page n being program words 64n..64n+63 (D83).
// A jump (JMP, JCRCBAD, JEQ, JNE, JLINE) has a 6-bit target in a page: by default the page of
// the jump itself, so a program of up to 64 words works as before, or the page p of a PAGE p
// executed just before it. Its address is (start_pc + {page, target}) mod 256.
// PAGE p is a one-shot prefix: it applies to the next instruction that executes (whether it
// jumps or not) and is then gone; a restart, a timeout or line-event jump also clear it. A stop
// (run = 0) and a host write (refetch) keep it. PAGE is an ordinary instruction for timing
// ((DLY + 1) ticks); a taken jump costs one refetch clock at CLKDIV 0, into any page.
// The timeout and line-event vector is always in page 0: (start_pc + timeout_pc) mod 256.
// Sequential execution increments the full 8-bit PC: it crosses pages and wraps 255->0.
// With the flip-flop fallback (64 words, PBE_PMEM_FF) all four pages are the same 64 words.
//
// Cycle contract, clarified by the round-2 model audit (existing behavior, no RTL change):
// - All decisions use pre-edge inputs/state. Reset zeros engine state and CRC; restart
//   cancels execution, resets registers/counters/status/parity, releases all enables,
//   preserves the output latch and previous sampled pins/flags, and initializes CRC.
//   The 16-bit divider is due when count >= clkdiv; changing CLKDIV live can make a tick
//   immediately due. Delay counts are 4 bits, timeout and divider counts are 16 bits.
// - An empty fetch register fills even while stopped. run=0 freezes instruction/divider/
//   timeout execution, but previous pins/flags, host clears, line events, byte CRC feed,
//   and the line coder continue. A restart/disabled coder clears the line coder.
// - WAIT RISE/FALL compares this clock's synchronized value with the preceding clock,
//   including clocks while stopped or fetching; edges are not latched until a WAIT sees them.
// - X-- tests old X and decrements only if nonzero. OUTOD latches 0 and enables only for a
//   zero bit. REL preserves the latch. END with coder off and reserved EXT7 do nothing.
//   Byte-mode OUT/OUTOD do not shift OSR. Every OSR load resets transmit parity; MOV/PUSH
//   writes to ISR do not reset receive parity. An IN released by frame end keeps ISR but
//   still XORs the coder data bit into receive parity (CRC is not fed without valid data).
// - Timeout counts ticks after the first blocked issue, tests the old count every clock,
//   and can affect any not-ready instruction (including coder/CRC stalls). Ready completion
//   wins over timeout. A fetch bubble cannot time out. Bounds require run to stay set,
//   no restart/PM writes/config changes, and a permanently unmet condition.
// - RX-full IRQ pulses only on the first observed overflow until overflow is cleared.
//   Host overflow/line-error clears win over their corresponding new events. A new line
//   end wins over JLINE consumption. Without a host clear, CRCRST preserves a coincident
//   coder error; STAT reads
//   old status then clears parity/timeout. Host CRC init wins over CRC feed but does not
//   cancel an already pending byte-feed queue. Byte feeds advance while stopped.
// - Restart wins over PM invalidation; a taken branch/timeout retains its target on a PM
//   write. Other writes refetch pc-1 if valid and not executing, else pc. Delays survive
//   PM invalidation. Fetch validity describes a snapshot, not equality to live RAM after
//   a write; a host write does not suppress same-edge instruction/FIFO/flag side effects.
module pbe_engine #(
    parameter bit PC_COPIES = 1'b1  // register three copies of pc (only the flip-flop memory reads them)
) (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        run,
    input  logic        restart,  // 1-cycle pulse
    // configuration
    input  logic [15:0] clkdiv,
    input  logic [2:0]  pin_base,
    input  logic [2:0]  jmp_pin,
    input  logic        out_msb_first,
    input  logic        in_msb_first,
    input  logic [7:0]  start_pc,     // where this engine's program starts (its word 0)
    input  logic [31:0] crc_poly,
    input  logic [7:0]  crc_cfg,      // [3:0] width-1, [4] init ones, [5] reversed, [6] feed OUT, [7] feed IN
    input  logic        crc_wide,     // CRC_CFG2[0]: bit 4 of width-1 (CRCs of 17-32 bits, D91)
    input  logic [15:0] timeout,      // ticks a blocked instruction may wait (0 = forever)
    input  logic [7:0]  line_cfg,     // [5:0] timeout_pc, [6] no parity, [7] odd parity
    input  logic [7:0]  coder_cfg,    // line coder, see pbe_line (0 = off)
    input  logic [7:0]  coder_cfg2,   // LINE2 (D65): sample point, resync, pins, CAN mode, idle wait
    input  logic [7:0]  sync,         // line coder frame start pattern
    input  logic [31:0] crc_good,     // the CRC value that means "ok"
    input  logic        host_crc_init,
    input  logic        host_tmo_clr,
    input  logic        host_ovf_clr,
    input  logic        host_lerr_clr,
    input  logic        host_arb_clr,
    input  logic        host_berr_clr,
    input  logic        host_sent_clr,
    output logic [7:0]  status,       // {sent, bit error, arbitration lost, line error, RX overflow,
                                      //  timeout happened, CRC ok, parity error}
    output logic [8:0]  can_tec,      // bit-synchronous mode's error counters and state
    output logic [7:0]  can_rec,
    output logic [1:0]  can_state,    // {bus-off, error-passive}
    output logic [31:0] crc_now,      // the CRC unit's current value, for the host
    // program memory
    output logic [7:0]  pc,           // program memory read address (absolute): the next word
    output logic [23:0] pc_copy,      // three more copies of pc, to share out its fan-out
    output logic [7:0]  pc_d,         // the value pc takes at the next clock (the SRAM's address, D62)
    input  logic [15:0] instr,        // the program memory word at pc
    input  logic        pm_wr,        // the host is writing the program memory (any word)
    // pins
    input  logic [7:0]  pins_in,  // synchronized
    input  logic [7:0]  pins_in_n, // the same pins sampled half a clock earlier (falling edge, D90)
    output logic [7:0]  pins_out,
    output logic [7:0]  pins_oe,  // (the line coder's pins are merged in combinationally)
    // TX FIFO (host to engine)
    input  logic [7:0]  tx_data,
    input  logic        tx_empty,
    output logic        tx_pop,
    output logic        tx_mark,      // hold the TX FIFO's read position (D70)
    output logic        tx_rewind,    // read the TX FIFO again from it
    // RX FIFO (engine to host)
    output logic [7:0]  rx_data,
    input  logic        rx_full,
    output logic        rx_push,
    // shared flags
    input  logic [3:0]  flags,
    output logic [3:0]  flag_set,
    output logic [3:0]  flag_clr,
    output logic        irq
);
  localparam logic [2:0] OP_PIN = 3'd0, OP_IN = 3'd1, OP_WAIT = 3'd2, OP_JMP = 3'd3,
                         OP_SET = 3'd4, OP_FIFO = 3'd5, OP_FLAG = 3'd6, OP_EXT = 3'd7;
  localparam logic [2:0] E_CRCRST = 3'd0, E_OSRCRC = 3'd1, E_STAT = 3'd2, E_JCRCBAD = 3'd3,
                         E_JEQ = 3'd4, E_JNE = 3'd5, E_JLINE = 3'd6, E_LINECTL = 3'd7;

  logic [15:0] div_cnt;
  logic [3:0]  dly_cnt;
  logic        blocked;
  logic [7:0]  x, osr, isr;
  logic [7:0]  pins_prev;
  logic [3:0]  flags_prev;
  logic        par_out, par_in, tmo_seen, rx_ovf;
  logic [15:0] tmo_cnt;
  logic [7:0]  pout, poe;   // the pin unit's own drive; the line coder can take over its pins
  logic        line_ev, line_err, arb_st, berr_st, sent_st;
  logic [3:0]  cf_cnt;      // byte mode: CRC bits still to feed
  logic [7:0]  cf_sh;
  logic [15:0] instr_q;     // the current instruction
  logic        iv;          // instr_q holds the word at pc - 1 (else it is being fetched from pc)

  // ---- decode ----
  wire [2:0] op  = instr_q[15:13];
  wire [8:0] arg = instr_q[12:4];
  wire [3:0] dly = instr_q[3:0];

  wire [2:0] arg_pin  = arg[8:6];
  wire [2:0] pin_act  = arg[5:3];
  wire [1:0] wait_cnd = arg[4:3];
  wire [2:0] jmp_cnd  = arg[8:6];
  wire [1:0] flag_act = arg[8:7];
  wire       arg_hi   = arg[8];

  wire [2:0] pin_idx = pin_base + arg_pin;
  wire [2:0] jmp_idx = pin_base + jmp_pin;
  wire       pin_now = pins_in[pin_idx];
  wire       pin_was = pins_prev[pin_idx];

  wire       out_bit = out_msb_first ? osr[7] : osr[0];
  wire [7:0] osr_shifted = out_msb_first ? {osr[6:0], 1'b0} : {1'b0, osr[7:1]};
  wire [7:0] isr_shifted = in_msb_first ? {isr[6:0], pin_now} : {pin_now, isr[7:1]};

  wire [2:0] ext_op   = arg[8:6];
  wire       odd      = line_cfg[7];
  wire       no_par   = line_cfg[6];
  wire [5:0] tmo_pc   = line_cfg[5:0];
  wire       par_err  = !no_par && (par_in ^ odd);
  wire       par_bit  = no_par || (par_out ^ odd);  // what OUTPAR sends

  // ---- line coder ----
  wire       coder_on = coder_cfg[1:0] != 2'd0;
  wire       bsm = coder_on && coder_cfg2[5];            // bit-synchronous (CAN) mode, D66
  wire       coder_bytes = coder_cfg[5] && !bsm;         // byte transfers of pbe_line
  wire       coder_unit = coder_cfg[5] || bsm;           // OUT/IN move whole registers
  wire       coder_pair = coder_cfg[4] && !bsm;
  wire [2:0] base1 = pin_base + 3'd1;
  wire       rx_pin = coder_cfg2[4] ? pins_in[base1] : pins_in[pin_base];  // LINE2[4]: split pins
  wire       rx_pin_e = coder_cfg2[4] ? pins_in_n[base1] : pins_in_n[pin_base];
  wire       is_txop = coder_on && op == OP_PIN && (pin_act == 3'd4 || pin_act == 3'd5 || pin_act == 3'd7);
  logic       l_drive, l_a, l_b, l_ready, l_rxv, l_end, l_err;
  logic [7:0] l_rxd;
  // pbe_line's and pbe_bsync's own outputs; l_* is the one in use
  logic       p_drive, p_a, p_b, p_ready, p_rxv, p_end, p_err;
  logic [7:0] p_rxd;
  logic       s_drive, s_ready, s_rxv, s_end, s_err, s_crc_step, s_crc_bit, s_arb, s_berr, s_sent;
  logic [7:0] s_rxd;

  // ---- issue and readiness ----
  wire tick_due = coder_on || (div_cnt >= clkdiv);
  wire tick     = tick_due && iv;  // a tick that falls on a fetch bubble waits for it
  wire issue    = run && iv && (blocked || (tick && dly_cnt == 4'd0));

  wire now = arg[5] ? flags[arg[7:6]] : pin_now;
  wire was = arg[5] ? flags_prev[arg[7:6]] : pin_was;

  logic wait_ok;
  always_comb begin
    case (wait_cnd)
      2'd0:    wait_ok = !now;
      2'd1:    wait_ok = now;
      2'd2:    wait_ok = !was && now;
      default: wait_ok = was && !now;
    endcase
  end

  logic ready;
  always_comb begin
    case (op)
      OP_WAIT: ready = wait_ok;
      OP_FIFO: ready = arg_hi ? !rx_full : (arg[7:6] != 2'd0 || !tx_empty);  // only PULL blocks
      OP_PIN:  ready = !is_txop || l_ready;
      OP_IN:   ready = !coder_on || l_rxv || line_ev;
      default: ready = 1'b1;
    endcase
    if (cf_cnt != 4'd0) ready = 1'b0;  // byte-mode CRC feed still running
  end

  // Bit-synchronous mode (D66): a transfer (IN, OUT, OUTOD, END) issued after the end of a
  // frame or an error is abandoned, and the engine jumps to TIMEOUT_PC, the line-event vector.
  // The event is consumed and the queued unit dropped.
  wire lv_hit = bsm && issue && !restart && line_ev && (op == OP_IN || is_txop);

  // A restart in the same cycle cancels the instruction, so it has no side effects.
  wire exec = issue && ready && !restart && !lv_hit;

  // A blocked instruction that has waited `timeout` ticks is abandoned.
  wire tmo_hit = run && !restart && iv && blocked && !ready && timeout != 16'd0 && tmo_cnt >= timeout;

  // ---- CRC unit, fed by the bits the engine shifts ----
  wire is_out = exec && op == OP_PIN && (pin_act == 3'd4 || pin_act == 3'd5);
  wire is_in  = exec && op == OP_IN && (!coder_on || l_rxv);  // not an IN ended by end of frame
  // bit-synchronous mode feeds the CRC as bits are sampled, not when IN takes them
  wire in_bit = coder_on ? l_rxd[0] : pin_now;
  wire crc_out = is_out && !arg[0] && crc_cfg[6] && !bsm;
  wire crc_in  = is_in && !arg[5] && crc_cfg[7] && !bsm;
  wire crc_line = bsm && s_crc_step && crc_cfg[7];
  logic [31:0] crc_value;
  logic        crc_ok;
  wire  [4:0]  crc_wm1 = {crc_wide, crc_cfg[3:0]};

  // byte mode: the CRC takes the byte's bits in wire order, one per clock
  wire [7:0] cf_byte = crc_out ? osr : l_rxd;
  wire       cf_msb  = crc_out ? out_msb_first : in_msb_first;
  wire [7:0] cf_load = cf_msb ? {cf_byte[0], cf_byte[1], cf_byte[2], cf_byte[3],
                                 cf_byte[4], cf_byte[5], cf_byte[6], cf_byte[7]} : cf_byte;
  wire       cf_start = coder_on && coder_bytes && (crc_out || crc_in);

  pbe_crc u_crc (
      .clk, .rst_n,
      .init     (host_crc_init || restart || (exec && op == OP_EXT && ext_op == E_CRCRST)),
      .step     (cf_cnt != 4'd0 || (!cf_start && (crc_out || crc_in)) || crc_line),
      .bit_in   (cf_cnt != 4'd0 ? cf_sh[0] : crc_line ? s_crc_bit : is_out ? out_bit : in_bit),
      .poly     (crc_poly),
      .width_m1 (crc_wm1),
      .init_ones(crc_cfg[4]),
      .out_rev  (crc_cfg[5]),
      .good     (crc_good),
      .value    (crc_value),
      .ok       (crc_ok)
  );

  assign status  = {sent_st, berr_st, arb_st, line_err, rx_ovf, tmo_seen, crc_ok, par_err};
  assign crc_now = crc_value;

  wire lctl = exec && op == OP_EXT && ext_op == E_LINECTL && !arg[5];
  pbe_line u_line (
      .clk, .rst_n,
      .clear        (restart || !coder_on || bsm),
      .cfg          (coder_cfg),
      .cfg2         (coder_cfg2),
      .sync,
      .period_m1    (clkdiv),
      .out_msb_first,
      .in_msb_first,
      .a_in         (rx_pin),
      .a_early      (rx_pin_e),
      .b_in         (pins_in[base1]),
      .drive        (p_drive),
      .a_out        (p_a),
      .b_out        (p_b),
      .ctl          (lctl && !bsm),       // LINECTL STUFFOFF / STUFFON (D94)
      .ctl_param    (arg[4:0]),
      .tx_put       (exec && is_txop && pin_act != 3'd7 && !bsm),
      .tx_end       (exec && is_txop && pin_act == 3'd7 && !bsm),
      .tx_data      (coder_bytes ? osr : {7'b0, out_bit}),
      .tx_ready     (p_ready),
      .rx_valid     (p_rxv),
      .rx_data      (p_rxd),
      .rx_take      (exec && coder_on && op == OP_IN && l_rxv && !bsm),
      .frame_end    (p_end),
      .err          (p_err)
  );

  pbe_bsync u_bsync (
      .clk, .rst_n,
      .clear        (restart || !bsm || !run),  // a stopped CAN node stays off the bus
      .cfg          (coder_cfg),
      .cfg2         (coder_cfg2),
      .period_m1    (clkdiv),
      .out_msb_first,
      .in_msb_first,
      .a_in         (rx_pin),
      .drive        (s_drive),
      .tx_put       (exec && is_txop && pin_act != 3'd7 && bsm),
      .tx_data      (osr),
      .tx_ready     (s_ready),
      .rx_valid     (s_rxv),
      .rx_data      (s_rxd),
      .rx_take      (exec && op == OP_IN && l_rxv && bsm),
      .frame_end    (s_end),
      .err          (s_err),
      .ctl          (lctl && bsm),
      .ctl_param    (arg[4:0]),
      .drop         (lv_hit),
      .crc_ok,
      .crc_step     (s_crc_step),
      .crc_bit      (s_crc_bit),
      .arb_lost     (s_arb),
      .bit_err      (s_berr),
      .sent         (s_sent),
      .tec          (can_tec),
      .rec          (can_rec),
      .passive      (can_state[0]),
      .busoff       (can_state[1])
  );
  assign l_drive = bsm ? s_drive : p_drive;
  assign l_a     = bsm ? 1'b0 : p_a;       // bit-synchronous mode drives only dominant (low)
  assign l_b     = p_b;
  assign l_ready = bsm ? s_ready : p_ready;
  assign l_rxv   = bsm ? s_rxv : p_rxv;
  assign l_rxd   = bsm ? s_rxd : p_rxd;
  assign l_end   = bsm ? s_end : p_end;
  assign l_err   = bsm ? s_err : p_err;

  // the coder's pins override the pin unit while it drives them
  wire [7:0] l_mask = l_drive ? ((8'd1 << pin_base) | (coder_pair ? 8'd1 << base1 : 8'd0)) : 8'd0;
  wire [7:0] l_val  = ({7'd0, l_a} << pin_base) | ({7'd0, l_b} << base1);
  assign pins_out = (pout & ~l_mask) | (l_val & l_mask);
  assign pins_oe  = poe | l_mask;

  // A PUSH that finds the RX FIFO full: the host is not keeping up.
  wire ovf_now = run && !restart && issue && op == OP_FIFO && arg_hi && rx_full;

  logic jmp_take;
  always_comb begin
    case (jmp_cnd)
      3'd0:    jmp_take = 1'b1;
      3'd1:    jmp_take = (x != 8'd0);
      3'd2:    jmp_take = pins_in[jmp_idx];
      3'd3:    jmp_take = !pins_in[jmp_idx];
      3'd4:    jmp_take = tx_empty;
      3'd5:    jmp_take = !tx_empty;
      3'd6:    jmp_take = flags[0];
      default: jmp_take = flags[1];
    endcase
  end

  // MOV: FLAG action 3 with a destination
  wire       is_mov  = op == OP_FLAG && flag_act == 2'd3 && arg[5:4] != 2'd0;
  logic [7:0] mov_val;
  always_comb begin
    case (arg[3:2])
      2'd1:    mov_val = x;
      2'd2:    mov_val = osr;
      2'd3:    mov_val = isr;
      default: mov_val = 8'd0;
    endcase
  end
  wire jline_take = exec && op == OP_EXT && ext_op == E_JLINE && line_ev;

  // a jump the current instruction takes if it executes: the next word must be fetched again
  logic jump;
  always_comb begin
    case (op)
      OP_JMP: jump = jmp_take;
      OP_EXT:
        case (ext_op)
          E_JCRCBAD: jump = !crc_ok || line_err;
          E_JEQ:     jump = isr == osr;
          E_JNE:     jump = isr != osr;
          E_JLINE:   jump = line_ev;
          default:   jump = 1'b0;
        endcase
      default: jump = 1'b0;
    endcase
  end
  // PAGE (D83): a one-shot page for the next instruction's jump; otherwise the jump's own page,
  // the top two bits of its program address (pc - 1 - start_pc; exec implies iv, so instr_q is
  // the word at pc - 1)
  wire       page_op = op == OP_EXT && ext_op == E_LINECTL && arg[5];
  logic       pg_set;   // a PAGE has executed and its page applies to the next instruction
  logic [1:0] pg_num;
  wire  [7:0] cur_off = pc - 8'd1 - start_pc;
  wire  [1:0] j_page  = pg_set ? pg_num : cur_off[7:6];
  wire        _unused_cur_off = &{cur_off[5:0], 1'b0};  // only the page bits are used (BUG-114)
  wire  [7:0] jump_pc = start_pc + {j_page, arg[5:0]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pg_set <= 1'b0;
      pg_num <= 2'd0;
    end else if (restart || tmo_hit || lv_hit) begin
      pg_set <= 1'b0;
    end else if (exec) begin
      pg_set <= page_op;
      pg_num <= arg[1:0];
    end
  end
  // OSRCRC param[2]: the CRC left-justified to 16 bits (CRC-15: bits 14..7 in the high byte);
  // a CRC wider than 16 bits is not shifted. Byte {param[3], param[0]} of the result (D91);
  // param[3] counts only for a CRC wider than 16 bits, so for every narrower one each encoding
  // gives exactly the byte it gave before D91 (param[3] was ignored).
  wire [15:0] crc_left = crc_value[15:0] << (4'd15 - crc_wm1[3:0]);
  wire [31:0] crc_osr  = (arg[2] && !crc_wm1[4]) ? {16'b0, crc_left} : crc_value;
  logic [7:0] crc_byte;
  always_comb begin
    case ({arg[3] && crc_wm1[4], arg[0]})
      2'd0:    crc_byte = crc_osr[7:0];
      2'd1:    crc_byte = crc_osr[15:8];
      2'd2:    crc_byte = crc_osr[23:16];
      default: crc_byte = crc_osr[31:24];
    endcase
  end

  // ---- fetch address ----
  logic [7:0] pc_next;
  always_comb begin
    pc_next = pc;
    if (restart) pc_next = start_pc;
    else begin
      if (!iv) pc_next = pc + 1'b1;  // the fetch fills instr_q: read on
      if (exec) pc_next = jump ? jump_pc : pc + 1'b1;
      if (tmo_hit || lv_hit) pc_next = start_pc + {2'b0, tmo_pc};
      // A host write to the program memory may change the current or the next word: fetch the
      // instruction that runs next again (a jump fetches its target anyway). pm_wr appears only
      // in `if`s: the unit testbenches leave it unconnected, and z must read as no write.
      if (pm_wr && !(exec && jump) && !tmo_hit && !lv_hit) pc_next = (iv && !exec) ? pc - 1'b1 : pc;
    end
  end

  // The SRAM reads at pc_d, the address pc takes at the edge (D62), so its output is the word at pc.
  assign pc_d = pc_next;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pc <= '0;
    else pc <= pc_next;
  end

  // With the flip-flop program memory (PBE_PMEM_FF, D82), pc drives the read multiplexers of all
  // 16 bits: thousands of inputs, which place and route had to reach through long buffer chains
  // (D50). Four copies each read 4 bits. `keep` stops synthesis from merging them back into one
  // register. The SRAM has one 8-bit address input, so it needs no copies.
  if (PC_COPIES) begin : g_pc_copy
    (* keep *)
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) pc_copy <= '0;
      else pc_copy <= {3{pc_next}};
    end
  end else begin : g_no_pc_copy
    assign pc_copy = '0;
  end

  // ---- side-effect pulses (combinational, valid in the exec cycle) ----
  // PULL group, arg[7:6]: 0 PULL (blocks while empty), 1 PULL NOWAIT (an empty FIFO gives
  // 0xFF, the idle level of most lines), 2 MARK, 3 REWIND (D70)
  assign tx_pop    = exec && op == OP_FIFO && !arg_hi && arg[7] == 1'b0 && !tx_empty;
  assign tx_mark   = exec && op == OP_FIFO && !arg_hi && arg[7:6] == 2'd2;
  assign tx_rewind = exec && op == OP_FIFO && !arg_hi && arg[7:6] == 2'd3;
  assign rx_push  = exec && op == OP_FIFO && arg_hi;
  assign rx_data  = isr;
  assign flag_set = (exec && op == OP_FLAG && flag_act == 2'd0) ? (4'b0001 << arg[1:0]) : 4'b0000;
  assign flag_clr = (exec && op == OP_FLAG && flag_act == 2'd1) ? (4'b0001 << arg[1:0]) : 4'b0000;
  assign irq      = (exec && op == OP_FLAG && flag_act == 2'd2) || (ovf_now && !rx_ovf);

  // ---- state ----
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      instr_q    <= '0;
      iv         <= 1'b0;
      div_cnt    <= '0;
      dly_cnt    <= '0;
      blocked    <= 1'b0;
      x          <= '0;
      osr        <= '0;
      isr        <= '0;
      pout       <= '0;
      poe        <= '0;
      line_ev    <= 1'b0;
      line_err   <= 1'b0;
      arb_st     <= 1'b0;
      berr_st    <= 1'b0;
      sent_st    <= 1'b0;
      cf_cnt     <= '0;
      cf_sh      <= '0;
      pins_prev  <= '0;
      flags_prev <= '0;
      par_out    <= 1'b0;
      par_in     <= 1'b0;
      tmo_seen   <= 1'b0;
      tmo_cnt    <= '0;
      rx_ovf     <= 1'b0;
    end else if (restart) begin
      iv       <= 1'b0;
      div_cnt  <= '0;
      dly_cnt  <= '0;
      blocked  <= 1'b0;
      x        <= '0;
      osr      <= '0;
      isr      <= '0;
      poe      <= '0;  // release every pin; keep pout so a line held high cannot glitch low
      line_ev  <= 1'b0;
      line_err <= 1'b0;
      arb_st   <= 1'b0;
      berr_st  <= 1'b0;
      sent_st  <= 1'b0;
      cf_cnt   <= '0;
      par_out  <= 1'b0;
      par_in   <= 1'b0;
      tmo_seen <= 1'b0;
      tmo_cnt  <= '0;
      rx_ovf   <= 1'b0;
    end else begin
      pins_prev  <= pins_in;
      flags_prev <= flags;
      if (host_tmo_clr) tmo_seen <= 1'b0;
      if (host_ovf_clr) rx_ovf <= 1'b0;
      else if (ovf_now) rx_ovf <= 1'b1;
      line_ev <= (line_ev && !jline_take && !lv_hit) || l_end;
      if (host_lerr_clr) line_err <= 1'b0;
      else if (l_err) line_err <= 1'b1;
      if (host_arb_clr) arb_st <= 1'b0;
      else if (bsm && s_arb) arb_st <= 1'b1;
      if (host_berr_clr) berr_st <= 1'b0;
      else if (bsm && s_berr) berr_st <= 1'b1;
      if (host_sent_clr) sent_st <= 1'b0;
      else if (bsm && s_sent) sent_st <= 1'b1;
      if (cf_cnt != 4'd0) begin
        cf_cnt <= cf_cnt - 4'd1;
        cf_sh  <= {1'b0, cf_sh[7:1]};
      end else if (cf_start) begin
        cf_cnt <= 4'd8;
        cf_sh  <= cf_load;
      end

      // fetch: fill an empty instruction register (also while stopped)
      if (!iv) begin
        instr_q <= instr;
        iv      <= 1'b1;
      end

      if (run) begin
        // tick divider; restarts when a blocked instruction completes
        if ((exec && blocked) || tmo_hit) div_cnt <= '0;
        else if (tick) div_cnt <= '0;
        else if (!tick_due) div_cnt <= div_cnt + 1'b1;

        if (tick && dly_cnt != 4'd0 && !blocked) dly_cnt <= dly_cnt - 1'b1;

        if (issue && !ready) blocked <= 1'b1;

        // timeout counter: ticks spent blocked
        if (!blocked) tmo_cnt <= '0;
        else if (tick) tmo_cnt <= tmo_cnt + 1'b1;

        if (exec) begin
          blocked <= 1'b0;
          dly_cnt <= dly;
          if (jump) iv <= 1'b0;
          else instr_q <= instr;  // the next word, already read at pc

          case (op)
            OP_PIN: begin
              if (coder_on && is_txop) begin
                if (!coder_unit && pin_act != 3'd7) osr <= osr_shifted;  // bit mode shifts
              end else case (pin_act)
                3'd0: begin pout[pin_idx] <= 1'b0;                 poe[pin_idx] <= 1'b1;     end
                3'd1: begin pout[pin_idx] <= 1'b1;                 poe[pin_idx] <= 1'b1;     end
                3'd2: begin                                            poe[pin_idx] <= 1'b0;     end
                3'd3: begin pout[pin_idx] <= ~pout[pin_idx];   poe[pin_idx] <= 1'b1;     end
                3'd4: begin pout[pin_idx] <= out_bit;              poe[pin_idx] <= 1'b1;
                            osr <= osr_shifted;                                                      end
                3'd5: begin pout[pin_idx] <= 1'b0;                 poe[pin_idx] <= !out_bit;
                            osr <= osr_shifted;                                                      end
                3'd6: begin pout[pin_idx] <= par_bit;              poe[pin_idx] <= 1'b1;     end
                default: ;
              endcase
            end
            OP_IN: begin
              if (!coder_on) isr <= isr_shifted;
              else if (l_rxv) isr <= coder_unit ? l_rxd
                                                 : (in_msb_first ? {isr[6:0], l_rxd[0]} : {l_rxd[0], isr[7:1]});
              par_in <= par_in ^ in_bit;
            end
            OP_JMP: begin
              if (jmp_cnd == 3'd1 && x != 8'd0) x <= x - 1'b1;
            end
            OP_SET: begin
              if (arg_hi) begin
                osr     <= arg[7:0];
                par_out <= 1'b0;
              end else x <= arg[7:0];
            end
            OP_FLAG: if (is_mov)
              case (arg[5:4])
                2'd1: x <= mov_val;
                2'd2: begin
                  osr     <= mov_val;
                  par_out <= 1'b0;
                end
                default: isr <= mov_val;
              endcase
            OP_FIFO: begin
              if (arg_hi) isr <= '0;
              else if (arg[7] == 1'b0) begin
                osr     <= (arg[6] && tx_empty) ? 8'hFF : tx_data;
                par_out <= 1'b0;
              end
            end
            OP_EXT: begin
              case (ext_op)
                E_OSRCRC: begin
                  osr     <= crc_byte ^ {8{arg[1]}};
                  par_out <= 1'b0;
                end
                E_CRCRST: begin  // a new packet: its status starts again
                  if (!l_err) line_err <= 1'b0;  // an error in this very clock stays
                  if (!(bsm && s_arb)) arb_st <= 1'b0;
                  if (!(bsm && s_berr)) berr_st <= 1'b0;
                  if (!(bsm && s_sent)) sent_st <= 1'b0;
                end
                E_STAT: begin
                  isr      <= status;
                  par_in   <= 1'b0;
                  tmo_seen <= 1'b0;
                end
                default: ;  // the jumps are above
              endcase
            end
            default: ;
          endcase
          if (is_out) par_out <= par_out ^ out_bit;
        end

        // timeout: abandon the blocked instruction and jump to the timeout routine
        if (tmo_hit || lv_hit) begin
          iv       <= 1'b0;
          blocked  <= 1'b0;
          dly_cnt  <= '0;
          if (tmo_hit) tmo_seen <= 1'b1;
        end
      end

      if (pm_wr) iv <= 1'b0;  // see pc_next
    end
  end
endmodule
