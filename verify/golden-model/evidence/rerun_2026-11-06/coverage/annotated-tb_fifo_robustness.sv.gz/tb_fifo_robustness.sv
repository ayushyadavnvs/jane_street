//      // verilator_coverage annotation
        `timescale 1ns/1ps
        // FIFO boundary contract, independent of host/engine request gating.
        module tb_fifo_robustness;
~000082   logic clk=0, rst_n=0, flush=0, push=0, pop=0, mark=0, rewind=0;
 000017   logic [7:0] din=0;
~000019   wire [7:0] dout;
 000005   wire empty, full;
 000036   wire [4:0] count;
 000164   always #5 clk=~clk;
          pbe_fifo #(.ADDR_BITS(4)) dut(.*);
 000082   task automatic tick;
 000082     @(posedge clk); #1;
          endtask
 000080   task automatic require(input logic condition, input string message);
 000080     if (condition !== 1'b1) $fatal(1, "FIFO boundary: %s count=%0d empty=%b full=%b", message, count, empty, full);
          endtask
 000001   initial begin
 000001     tick(); @(negedge clk); rst_n=1; tick();
~000001     require(count==0 && empty && !full, "reset empties");
 000001     @(negedge clk); pop=1; tick();
~000001     require(count==0 && empty && !full, "empty pop must be ignored");
 000001     @(negedge clk); pop=0;
 000016     for (int i=0;i<16;i++) begin
 000016       push=1; din=8'(i+8'h40); tick();
 000016       require(count==i+1, "count after accepted push");
 000016       @(negedge clk);
            end
~000001     require(full && !empty, "sixteenth push fills");
 000001     din=8'hee; tick();
~000001     require(count==16 && full, "full push must be ignored");
 000001     @(negedge clk); push=0;
 000016     for (int i=0;i<16;i++) begin
 000016       require(dout==8'(i+8'h40), "FIFO data order / rejected push preserves oldest");
 000016       pop=1; tick();
 000016       require(count==15-i, "count after accepted pop");
 000016       @(negedge clk);
            end
 000001     tick();
~000001     require(count==0 && empty, "repeated empty pop must be ignored");
 000001     @(negedge clk); pop=0; push=1; din=8'h22; tick();
 000001     @(negedge clk); push=0; flush=1; tick();
~000001     require(count==0 && empty && !full, "flush empties");
            // mark and rewind (D66): a frame is read again after a rewind, and while the mark is held
            // the host cannot overwrite it
 000001     @(negedge clk); flush=0;
 000004     for (int i=0;i<4;i++) begin push=1; din=8'(i+8'h60); tick(); @(negedge clk); end
 000001     push=0; mark=1; tick(); @(negedge clk); mark=0;
 000003     for (int i=0;i<3;i++) begin
 000003       require(dout==8'(i+8'h60), "marked data order");
 000003       pop=1; tick(); @(negedge clk);
            end
 000001     pop=0;
 000001     require(count==1, "count after pops past the mark");
 000012     for (int i=0;i<12;i++) begin push=1; din=8'(i+8'h70); tick(); @(negedge clk); end
~000001     require(full && count==13, "full counts from the held mark (4 + 12 = 16)");
 000001     din=8'hee; tick(); @(negedge clk); push=0;
 000001     require(count==13, "a push into the held bytes must be ignored");
 000001     rewind=1; tick(); @(negedge clk); rewind=0;
~000001     require(count==16 && dout==8'h60, "rewind reads again from the mark");
 000016     for (int i=0;i<16;i++) begin
 000016       require(dout==(i<4 ? 8'(i+8'h60) : 8'(i-4+8'h70)), "data after rewind");
 000016       pop=1; tick(); @(negedge clk);
            end
 000001     pop=0;
~000001     require(empty && full, "all read again; the mark is still held");
 000001     mark=1; tick(); @(negedge clk); mark=0;
~000001     require(empty && !full, "a new mark releases the old bytes");
 000001     flush=1; tick(); @(negedge clk); flush=0;
 000001     push=1; din=8'h11; tick(); @(negedge clk); push=0; pop=1; tick(); @(negedge clk); pop=0;
 000001     rewind=1; tick(); @(negedge clk); rewind=0;
 000001     require(empty, "without a mark (after flush) rewind does nothing");
 000001     $display("PASS: FIFO boundary, rejection, order, flush, mark and rewind");
 000001     $finish;
          end
          initial begin #20000; $fatal(1,"FIFO boundary test timeout"); end
        endmodule
        
